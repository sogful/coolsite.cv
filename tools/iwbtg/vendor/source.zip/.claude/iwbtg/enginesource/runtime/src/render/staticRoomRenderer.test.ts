import { describe, expect, it, vi } from 'vitest';
import { renderStaticRoom, resolveBackgroundDraws, resolveTileDraws } from './staticRoomRenderer';
import { makeRoomDefinition } from '../test/packageFixtures';
import type { ObjectDefinition } from '../types';

describe('resolveBackgroundDraws', () => {
  it('returns visible background layers with their draw flags', () => {
    const room = makeRoomDefinition({
      backgrounds: [
        {
          visible_on_start: false,
          is_foreground: false,
          source_bg: 0,
          xoffset: 0,
          yoffset: 0,
          tile_horz: false,
          tile_vert: false,
          hspeed: 0,
          vspeed: 0,
          stretch: false
        },
        {
          visible_on_start: true,
          is_foreground: false,
          source_bg: 1,
          xoffset: 4,
          yoffset: 8,
          tile_horz: false,
          tile_vert: false,
          hspeed: 0,
          vspeed: 0,
          stretch: false
        }
      ]
    });

    const backgroundPaths = new Map([[1, '/pkg/resources/backgrounds/1.png']]);

    expect(resolveBackgroundDraws(room, backgroundPaths)).toEqual([
      {
        imagePath: '/pkg/resources/backgrounds/1.png',
        x: 4,
        y: 8,
        stretch: false,
        tileHorz: false,
        tileVert: false,
        isForeground: false
      }
    ]);
  });
});

describe('renderStaticRoom', () => {
  it('returns visible room tiles with background image paths', () => {
    const room = makeRoomDefinition({
      tiles: [
        {
          tile_id: 4,
          source_bg: 2,
          x: 10,
          y: 20,
          tile_x: 3,
          tile_y: 4,
          width: 32,
          height: 32,
          depth: 100,
          xscale: 1,
          yscale: 1,
          blend: 0xffffffff,
        }
      ]
    });

    const backgroundPaths = new Map([[2, '/pkg/resources/backgrounds/2.png']]);

    expect(resolveTileDraws(room, backgroundPaths)).toEqual([
      {
        imagePath: '/pkg/resources/backgrounds/2.png',
        x: 10,
        y: 20,
        tileX: 3,
        tileY: 4,
        width: 32,
        height: 32,
        depth: 100,
        xscale: 1,
        yscale: 1
      }
    ]);
  });

  it('draws stretched and tiled backgrounds', async () => {
    const clearRect = vi.fn();
    const fillRect = vi.fn();
    const drawImage = vi.fn();
    const context = {
      fillStyle: '',
      clearRect,
      fillRect,
      drawImage,
      save: vi.fn(),
      restore: vi.fn(),
      translate: vi.fn(),
      rotate: vi.fn(),
      scale: vi.fn()
    };

    const canvas = {
      width: 0,
      height: 0,
      getContext: vi.fn(() => context)
    } as unknown as HTMLCanvasElement;

    const room = makeRoomDefinition({
      width: 640,
      height: 480,
      background_colour: 0x00332211,
      backgrounds: [
        {
          visible_on_start: true,
          is_foreground: false,
          source_bg: 1,
          xoffset: 0,
          yoffset: 0,
          tile_horz: false,
          tile_vert: false,
          hspeed: 0,
          vspeed: 0,
          stretch: true
        },
        {
          visible_on_start: true,
          is_foreground: false,
          source_bg: 2,
          xoffset: 50,
          yoffset: 20,
          tile_horz: true,
          tile_vert: false,
          hspeed: 0,
          vspeed: 0,
          stretch: false
        }
      ]
    });

    const backgroundPaths = new Map([
      [1, '/pkg/resources/backgrounds/1.png'],
      [2, '/pkg/resources/backgrounds/2.png']
    ]);
    const spritePaths = new Map();

    const stretchedImage = { id: 'stretch', width: 64, height: 64 } as unknown as HTMLImageElement;
    const tiledImage = { id: 'tile', width: 100, height: 40 } as unknown as HTMLImageElement;
    const cache = {
      getImage: vi.fn(async (src: string) => {
        if (src.endsWith('/1.png')) {
          return stretchedImage;
        }
        return tiledImage;
      })
    };

    await renderStaticRoom(canvas, room, [], backgroundPaths, spritePaths, cache as never);

    expect(canvas.width).toBe(640);
    expect(canvas.height).toBe(480);
    expect(clearRect).toHaveBeenCalledWith(0, 0, 640, 480);
    expect(context.fillStyle).toBe('rgb(17, 34, 51)');
    expect(fillRect).toHaveBeenNthCalledWith(1, 0, 0, 640, 480);
    expect(drawImage).toHaveBeenNthCalledWith(1, stretchedImage, 0, 0, 640, 480);
    expect(drawImage).toHaveBeenNthCalledWith(2, tiledImage, -50, 20);
    expect(drawImage).toHaveBeenNthCalledWith(3, tiledImage, 50, 20);
    expect(drawImage).toHaveBeenNthCalledWith(4, tiledImage, 150, 20);
  });

  it('draws sprite instances with origin-aware transforms and skips invisible objects', async () => {
    const clearRect = vi.fn();
    const fillRect = vi.fn();
    const drawImage = vi.fn();
    const save = vi.fn();
    const restore = vi.fn();
    const translate = vi.fn();
    const rotate = vi.fn();
    const scale = vi.fn();
    const context = {
      fillStyle: '',
      clearRect,
      fillRect,
      drawImage,
      save,
      restore,
      translate,
      rotate,
      scale
    };

    const canvas = {
      width: 0,
      height: 0,
      getContext: vi.fn(() => context)
    } as unknown as HTMLCanvasElement;

    const room = makeRoomDefinition({
      instances: [
        {
          instance_id: 1,
          object_id: 0,
          x: 10,
          y: 20,
          xscale: 2,
          yscale: 3,
          angle: 90,
          blend: 0xffffffff,
          creation_block_id: null,
          is_solid: false,
          is_hazard: false,
          is_checkpoint: false
        },
        {
          instance_id: 2,
          object_id: 1,
          x: 50,
          y: 60,
          xscale: 1,
          yscale: 1,
          angle: 0,
          blend: 0xffffffff,
          creation_block_id: null,
          is_solid: false,
          is_hazard: false,
          is_checkpoint: false
        },
        {
          instance_id: 3,
          object_id: 2,
          x: 70,
          y: 80,
          xscale: 1,
          yscale: 1,
          angle: 0,
          blend: 0xffffffff,
          creation_block_id: null,
          is_solid: false,
          is_hazard: false,
          is_checkpoint: false
        }
      ]
    });

    const objects: ObjectDefinition[] = [
      {
        id: 0,
        name: 'Player',
        sprite_index: 0,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: null,
        is_checkpoint: null,
        is_player: true,
        events: []
      },
      {
        id: 1,
        name: 'Hidden',
        sprite_index: 1,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: false,
        solid: false,
        mask_index: -1,
        is_hazard: null,
        is_checkpoint: null,
        is_player: false,
        events: []
      },
      {
        id: 2,
        name: 'Missing',
        sprite_index: -1,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: null,
        is_checkpoint: null,
        is_player: false,
        events: []
      }
    ];

    const spritePaths = new Map([
      [
        0,
        {
          frames: [
            {
              imagePath: '/pkg/resources/sprites/0-0.png',
              originX: 5,
              originY: 6
            }
          ],
          originX: 5,
          originY: 6
        }
      ]
    ]);
    const spriteImage = { id: 'sprite', width: 30, height: 40 } as unknown as HTMLImageElement;
    const cache = {
      getImage: vi.fn(async () => spriteImage)
    };

    await renderStaticRoom(canvas, room, objects, new Map(), spritePaths, cache as never);

    expect(save).toHaveBeenCalledTimes(1);
    expect(translate).toHaveBeenCalledWith(10, 20);
    expect(rotate).toHaveBeenCalledWith(Math.PI / 2);
    expect(scale).toHaveBeenCalledWith(2, 3);
    expect(drawImage).toHaveBeenNthCalledWith(1, spriteImage, -5, -6);
    expect(restore).toHaveBeenCalledTimes(1);
    expect(fillRect).toHaveBeenNthCalledWith(2, 66, 76, 8, 8);
  });

  it('draws room tiles using background source rectangles', async () => {
    const clearRect = vi.fn();
    const fillRect = vi.fn();
    const drawImage = vi.fn();
    const context = {
      fillStyle: '',
      clearRect,
      fillRect,
      drawImage,
      save: vi.fn(),
      restore: vi.fn(),
      translate: vi.fn(),
      rotate: vi.fn(),
      scale: vi.fn()
    };

    const canvas = {
      width: 0,
      height: 0,
      getContext: vi.fn(() => context)
    } as unknown as HTMLCanvasElement;

    const room = makeRoomDefinition({
      tiles: [
        {
          tile_id: 5,
          source_bg: 1,
          x: 16,
          y: 24,
          tile_x: 4,
          tile_y: 8,
          width: 32,
          height: 32,
          depth: 100,
          xscale: 2,
          yscale: 1.5,
          blend: 0xffffffff,
        }
      ]
    });

    const image = { id: 'tile-sheet', width: 128, height: 128 } as unknown as HTMLImageElement;
    const cache = {
      getImage: vi.fn(async () => image)
    };

    await renderStaticRoom(
      canvas,
      room,
      [],
      new Map([[1, '/pkg/resources/backgrounds/1.png']]),
      new Map(),
      cache as never
    );

    expect(drawImage).toHaveBeenNthCalledWith(1, image, 4, 8, 32, 32, 16, 24, 64, 48);
  });
});
