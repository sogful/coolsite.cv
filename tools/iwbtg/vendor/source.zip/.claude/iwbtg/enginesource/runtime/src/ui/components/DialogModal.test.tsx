import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { DialogModal } from "./DialogModal";

describe("DialogModal", () => {
  afterEach(() => {
    cleanup();
  });
  it("renders question choices and maps keyboard answers", () => {
    const onRespond = vi.fn();
    render(
      <DialogModal
        dialog={{ kind: "question", text: "Save this game?", site: "test" }}
        onRespond={onRespond}
      />,
    );

    expect(screen.getByRole("dialog")).toHaveTextContent("Save this game?");
    expect(screen.getByRole("button", { name: "是" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "否" })).toBeInTheDocument();

    fireEvent.keyDown(screen.getByRole("dialog"), { key: "Escape" });
    expect(onRespond).toHaveBeenCalledWith("no");
  });

  it("uses accepted for a message dialog", () => {
    const onRespond = vi.fn();
    render(
      <DialogModal
        dialog={{ kind: "message", text: "Done", site: "test" }}
        onRespond={onRespond}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "确定" }));
    expect(onRespond).toHaveBeenCalledWith("accepted");
  });

  it("converts GM8 # markers to newlines and honors \\# escapes", () => {
    render(
      <DialogModal
        dialog={{
          kind: "message",
          text: "Save exists.#Overwrite?",
          site: "test",
        }}
        onRespond={vi.fn()}
      />,
    );

    expect(document.querySelector("p.runtime-dialog-text")?.textContent).toBe(
      "Save exists.\nOverwrite?",
    );
  });

  it("renders a literal # for the GM8 escape \\#", () => {
    render(
      <DialogModal
        dialog={{ kind: "message", text: "C:\\#hash", site: "test" }}
        onRespond={vi.fn()}
      />,
    );

    expect(document.querySelector("p.runtime-dialog-text")?.textContent).toBe(
      "C:#hash",
    );
  });

  it("re-enables buttons when the response fails", async () => {
    const onRespond = vi.fn().mockRejectedValueOnce(new Error("bridge gone"));
    render(
      <DialogModal
        dialog={{ kind: "message", text: "Done", site: "test" }}
        onRespond={onRespond}
      />,
    );

    const ok = screen.getByRole("button", { name: "确定" });
    fireEvent.click(ok);
    await waitFor(() => expect(ok).toBeEnabled());
    fireEvent.click(ok);
    expect(onRespond).toHaveBeenCalledTimes(2);
  });
});
