import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import type { WasmRuntimeBridgeSnapshot } from "../../runtime/wasmBridge";
import "./DialogModal.css";

// GM8 uses `#` as a newline marker inside message text; `\#` is a literal `#`.
// Converted at the presentation boundary — lowering keeps the raw marker.
function renderGm8Text(raw: string): string {
  const escaped = raw.replace(/\\#/g, "\u0000");
  return escaped
    .split("#")
    .map((line) => line.replaceAll("\u0000", "#"))
    .join("\n");
}

type DialogModalProps = {
  dialog: NonNullable<WasmRuntimeBridgeSnapshot["pendingDialog"]>;
  onRespond: (answer: "accepted" | "yes" | "no") => void | Promise<void>;
};

export function DialogModal({
  dialog,
  onRespond,
}: DialogModalProps): JSX.Element {
  const firstButtonRef = useRef<HTMLButtonElement | null>(null);
  const [responding, setResponding] = useState(false);

  useEffect(() => {
    firstButtonRef.current?.focus();
  }, [dialog.site, dialog.text]);

  function submit(answer: "accepted" | "yes" | "no"): void {
    if (responding) {
      return;
    }
    setResponding(true);
    try {
      const result = onRespond(answer);
      void Promise.resolve(result).catch(() => {
        setResponding(false);
      });
    } catch {
      setResponding(false);
    }
  }

  function stopGameplayInput(event: KeyboardEvent<HTMLDivElement>): void {
    event.preventDefault();
    event.stopPropagation();
    if (event.key === "Enter") {
      submit(dialog.kind === "question" ? "yes" : "accepted");
    } else if (event.key === "Escape" && dialog.kind === "question") {
      submit("no");
    }
  }

  return (
    <div
      className="runtime-dialog-backdrop"
      role="presentation"
      onKeyDown={stopGameplayInput}
      onKeyUp={stopGameplayInput}
    >
      <section
        className="runtime-dialog"
        role="dialog"
        aria-modal="true"
        aria-label={dialog.kind === "question" ? "游戏问题" : "游戏提示"}
      >
        <p className="runtime-dialog-text">{renderGm8Text(dialog.text)}</p>
        <div className="runtime-dialog-actions">
          <button
            ref={firstButtonRef}
            type="button"
            onClick={() =>
              submit(dialog.kind === "question" ? "yes" : "accepted")
            }
            disabled={responding}
          >
            {dialog.kind === "question" ? "是" : "确定"}
          </button>
          {dialog.kind === "question" ? (
            <button
              type="button"
              onClick={() => submit("no")}
              disabled={responding}
            >
              否
            </button>
          ) : null}
        </div>
      </section>
    </div>
  );
}
