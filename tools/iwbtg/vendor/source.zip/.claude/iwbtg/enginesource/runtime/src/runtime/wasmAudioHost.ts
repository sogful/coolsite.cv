import type { RuntimePackage } from '../types';

export type WasmSoundMode = 'once' | 'loop';

export type WasmAudioHost = {
  configurePackage: (pkg: RuntimePackage, basePath: string) => void;
  playSound: (soundId: number, mode: WasmSoundMode) => Promise<void> | void;
  stopSound: (soundId: number) => void;
  stopAllSounds: () => void;
  isSoundPlaying: (soundId: number) => boolean;
};

type WebAudioHostOptions = {
  audioContext?: AudioContext;
  fetch?: typeof fetch;
};

export function createWebAudioHost(options: WebAudioHostOptions = {}): WasmAudioHost {
  const context = options.audioContext ?? defaultAudioContext();
  const fetchSound = options.fetch ?? fetch.bind(globalThis);
  const buffers = new Map<number, Promise<AudioBuffer>>();
  const activeLoops = new Map<number, AudioBufferSourceNode>();
  const activeOneShots = new Map<number, Set<AudioBufferSourceNode>>();
  const loadingLoops = new Map<number, symbol>();
  const playingSounds = new Set<number>();
  let packageBasePath = '';
  let packageSounds = new Map<number, string>();
  let packageSoundKinds = new Map<number, string>();
  let activeBackgroundMusic: { soundId: number; source: AudioBufferSourceNode } | undefined;

  const resumeContext = () => {
    if (context?.state === 'suspended') {
      void context.resume().catch(() => undefined);
    }
  };
  globalThis.addEventListener?.('pointerdown', resumeContext, { once: true });
  globalThis.addEventListener?.('keydown', resumeContext, { once: true });

  async function loadBuffer(soundId: number): Promise<AudioBuffer | null> {
    const path = packageSounds.get(soundId);
    if (!path || !context) {
      return null;
    }

    const cached = buffers.get(soundId);
    if (cached) {
      return cached;
    }

    const loaded = fetchSound(`${packageBasePath}/${path}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Failed to load sound ${soundId}: ${response.status}`);
        }
        return response.arrayBuffer();
      })
      .then((bytes) => context.decodeAudioData(bytes));
    buffers.set(soundId, loaded);
    return loaded;
  }

  function startSource(soundId: number, buffer: AudioBuffer, mode: WasmSoundMode): void {
    if (!context) {
      return;
    }
    if (mode === 'loop') {
      stopSource(activeLoops.get(soundId));
    }
    if (isExclusiveMusicKind(packageSoundKinds.get(soundId))) {
      if (activeBackgroundMusic?.soundId !== soundId) {
        stopSource(activeBackgroundMusic?.source);
        if (activeBackgroundMusic) {
          activeLoops.delete(activeBackgroundMusic.soundId);
          discardOneShot(activeBackgroundMusic.soundId, activeBackgroundMusic.source);
          playingSounds.delete(activeBackgroundMusic.soundId);
        }
      }
    }

    const source = context.createBufferSource();
    source.buffer = buffer;
    source.loop = mode === 'loop';
    source.onended = () => {
      if (mode !== 'loop') {
        discardOneShot(soundId, source);
        if (!activeOneShots.has(soundId) && !activeLoops.has(soundId)) {
          playingSounds.delete(soundId);
        }
      }
    };
    source.connect(context.destination);
    playingSounds.add(soundId);
    source.start();
    if (mode === 'loop') {
      activeLoops.set(soundId, source);
    } else {
      let sources = activeOneShots.get(soundId);
      if (!sources) {
        sources = new Set();
        activeOneShots.set(soundId, sources);
      }
      sources.add(source);
    }
    if (isExclusiveMusicKind(packageSoundKinds.get(soundId))) {
      activeBackgroundMusic = { soundId, source };
    }
  }

  function stopSource(source: AudioBufferSourceNode | undefined): void {
    try {
      source?.stop();
    } catch (error) {
      if (!(error instanceof DOMException) || error.name !== 'InvalidStateError') {
        throw error;
      }
    }
  }

  function discardOneShot(soundId: number, source: AudioBufferSourceNode): void {
    const sources = activeOneShots.get(soundId);
    if (!sources) {
      return;
    }
    sources.delete(source);
    if (sources.size === 0) {
      activeOneShots.delete(soundId);
    }
  }

  function stopOneShots(soundId: number): void {
    for (const source of activeOneShots.get(soundId) ?? []) {
      stopSource(source);
    }
    activeOneShots.delete(soundId);
  }

  function stopAllOneShots(): void {
    for (const sources of activeOneShots.values()) {
      for (const source of sources) {
        stopSource(source);
      }
    }
    activeOneShots.clear();
  }

  return {
    configurePackage(pkg, basePath) {
      for (const source of activeLoops.values()) {
        stopSource(source);
      }
      stopAllOneShots();
      packageBasePath = basePath.replace(/\/$/, '');
      packageSounds = new Map(pkg.resources.sounds.map((sound) => [sound.id, sound.file_path]));
      packageSoundKinds = new Map(pkg.resources.sounds.map((sound) => [sound.id, sound.kind ?? 'normal']));
      buffers.clear();
      activeLoops.clear();
      loadingLoops.clear();
      playingSounds.clear();
      activeBackgroundMusic = undefined;
    },
    async playSound(soundId, mode) {
      resumeContext();
      const loopToken = mode === 'loop' ? Symbol() : undefined;
      if (loopToken) {
        if (loadingLoops.has(soundId)) {
          return;
        }
        loadingLoops.set(soundId, loopToken);
        playingSounds.add(soundId);
      }
      try {
        const buffer = await loadBuffer(soundId);
        if (loopToken) {
          if (loadingLoops.get(soundId) !== loopToken) {
            return;
          }
          loadingLoops.delete(soundId);
        }
        if (buffer) {
          startSource(soundId, buffer, mode);
        } else if (loopToken) {
          playingSounds.delete(soundId);
        }
      } catch {
        if (loopToken && loadingLoops.get(soundId) === loopToken) {
          loadingLoops.delete(soundId);
          playingSounds.delete(soundId);
        }
      }
    },
    stopSound(soundId) {
      stopSource(activeLoops.get(soundId));
      stopOneShots(soundId);
      activeLoops.delete(soundId);
      loadingLoops.delete(soundId);
      playingSounds.delete(soundId);
      if (activeBackgroundMusic?.soundId === soundId) {
        activeBackgroundMusic = undefined;
      }
    },
    stopAllSounds() {
      for (const source of activeLoops.values()) {
        stopSource(source);
      }
      stopAllOneShots();
      activeLoops.clear();
      loadingLoops.clear();
      playingSounds.clear();
      activeBackgroundMusic = undefined;
    },
    isSoundPlaying(soundId) {
      return playingSounds.has(soundId);
    }
  };
}

function isExclusiveMusicKind(kind: string | undefined): boolean {
  return kind === 'background-music' || kind === 'multimedia';
}

function defaultAudioContext(): AudioContext | undefined {
  const AudioContextCtor =
    globalThis.AudioContext
    ?? (globalThis as typeof globalThis & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  return AudioContextCtor ? new AudioContextCtor() : undefined;
}
