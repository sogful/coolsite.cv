use iwm_runtime_host::RuntimeDrawCommand;
use iwm_runtime_model::{
    FontGlyphResource, FontResource, ObjectDefinition, ObjectEventEntry, RoomInstancePlacement,
    RuntimeDisplaySource,
};

use crate::{LoweredLogicExpr, LoweredLogicStatement, RuntimeCore};

use super::support::{add_step_block, append_lowered_entry, host, sample_package};
#[cfg(feature = "local-sample-tests")]
use super::support::{local_sample_package, real_sample_package};

#[test]
fn runtime_core_emits_browser_consumable_draw_commands() {
    let package = sample_package();
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert_eq!(frame.room_id, Some(7));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawBackground {
            background_id: 0,
            ..
        }
    )));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawTile {
            background_id: 0,
            width: 32,
            height: 32,
            ..
        }
    )));
    assert!(frame
        .commands
        .iter()
        .any(|command| matches!(command, RuntimeDrawCommand::DrawSprite { sprite_id: 0, .. })));
    assert!(frame
        .commands
        .iter()
        .any(|command| matches!(command, RuntimeDrawCommand::DrawSprite { sprite_id: 1, .. })));
}

#[test]
fn runtime_core_orders_tiles_and_instance_sprites_by_gm_depth() {
    let mut package = sample_package();
    package
        .objects
        .iter_mut()
        .find(|object| object.id == 0)
        .unwrap()
        .depth = 0;
    package
        .objects
        .iter_mut()
        .find(|object| object.id == 705)
        .unwrap()
        .depth = 200;
    package.rooms[0].tiles[0].depth = 100;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let render_order = host
        .renderer
        .submitted_frames
        .last()
        .unwrap()
        .commands
        .iter()
        .filter_map(|command| match command {
            RuntimeDrawCommand::DrawTile { .. } => Some("tile"),
            RuntimeDrawCommand::DrawSprite { sprite_id: 1, .. } => Some("high-sprite"),
            RuntimeDrawCommand::DrawSprite { sprite_id: 0, .. } => Some("low-sprite"),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(render_order, vec!["high-sprite", "tile", "low-sprite"]);
}

#[test]
fn runtime_core_mirrors_player_sprite_when_facing_left() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    let mut host = host();
    let room = core.current_room.as_mut().unwrap();
    let player = room
        .instances
        .iter_mut()
        .find(|instance| instance.player_candidate)
        .unwrap();
    player.facing_left = true;

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 0,
            xscale,
            ..
        } if *xscale < 0.0
    )));
}

#[test]
fn runtime_core_skips_dead_instances_when_rendering_sprites() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    let mut host = host();
    let room = core.current_room.as_mut().unwrap();
    let sparse_sprite = room
        .instances
        .iter_mut()
        .find(|instance| instance.object_id == 705)
        .unwrap();
    sparse_sprite.alive = false;

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(!frame
        .commands
        .iter()
        .any(|command| matches!(command, RuntimeDrawCommand::DrawSprite { sprite_id: 1, .. })));
}

#[test]
fn runtime_core_uses_instance_visible_flag_when_rendering_sprites() {
    let mut package = sample_package();
    package.objects[1].sprite_index = 1;
    package.objects[1].visible = false;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let marker = core
        .current_room
        .as_mut()
        .unwrap()
        .instances
        .iter_mut()
        .find(|instance| instance.object_id == 1)
        .unwrap();
    marker.visible = true;

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 1,
            x: 48,
            y: 64,
            ..
        }
    )));
}

#[test]
fn runtime_core_uses_instance_sprite_and_image_index_when_rendering_sprites() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    let mut host = host();
    let marker = core
        .current_room
        .as_mut()
        .unwrap()
        .instances
        .iter_mut()
        .find(|instance| instance.object_id == 1)
        .unwrap();
    marker
        .vars
        .insert("sprite_index".into(), crate::RuntimeValue::Number(1.0));
    marker
        .vars
        .insert("image_index".into(), crate::RuntimeValue::Number(2.0));

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 1,
            frame_index: 2,
            ..
        }
    )));
}

#[test]
fn runtime_core_uses_instance_image_alpha_when_rendering_sprites() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    let mut host = host();
    let marker = core
        .current_room
        .as_mut()
        .unwrap()
        .instances
        .iter_mut()
        .find(|instance| instance.object_id == 1)
        .unwrap();
    marker
        .vars
        .insert("sprite_index".into(), crate::RuntimeValue::Number(1.0));
    marker
        .vars
        .insert("image_alpha".into(), crate::RuntimeValue::Number(0.7));

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 1,
            alpha,
            ..
        } if (*alpha - 0.7).abs() < f64::EPSILON
    )));
}

#[test]
fn runtime_core_uses_floored_image_index_when_rendering_sprites() {
    let mut package = sample_package();
    package.resources.sprites[1].frame_paths = vec![
        "resources/sprites/1-0.png".into(),
        "resources/sprites/1-1.png".into(),
        "resources/sprites/1-2.png".into(),
    ];
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let marker = core
        .current_room
        .as_mut()
        .unwrap()
        .instances
        .iter_mut()
        .find(|instance| instance.object_id == 1)
        .unwrap();
    marker
        .vars
        .insert("sprite_index".into(), crate::RuntimeValue::Number(1.0));
    marker
        .vars
        .insert("image_index".into(), crate::RuntimeValue::Number(1.9));

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 1,
            frame_index: 1,
            ..
        }
    )));
}

#[test]
fn runtime_core_does_not_render_custom_death_feedback_after_direct_hazard_death() {
    let mut package = sample_package();
    package.rooms[0].instances.push(RoomInstancePlacement {
        instance_id: 99,
        object_id: 1,
        x: 12,
        y: 24,
        xscale: 1.0,
        yscale: 1.0,
        angle: 0.0,
        blend: 0x00ff_ffff,
        creation_block_id: None,
        is_solid: false,
        is_hazard: true,
        is_checkpoint: false,
    });
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.tick(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(!frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::FillRect {
            colour,
            ..
        } if colour.r >= 160 && colour.g <= 40 && colour.b <= 40
    )));
    assert!(!frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawText {
            text,
            ..
        } if text == "GAME OVER"
    )));
}

#[test]
fn runtime_core_renders_visible_view_as_canvas_frame() {
    let mut package = sample_package();
    package.rooms[0].width = 2400;
    package.rooms[0].height = 1824;
    package.rooms[0].views_enabled = true;
    package.rooms[0].views[0].visible = true;
    package.rooms[0].views[0].source_x = 800;
    package.rooms[0].views[0].source_y = 608;
    package.rooms[0].views[0].source_w = 800;
    package.rooms[0].views[0].source_h = 600;
    package.rooms[0].views[0].port_x = 0;
    package.rooms[0].views[0].port_y = 0;
    package.rooms[0].views[0].port_w = 800;
    package.rooms[0].views[0].port_h = 600;
    package.rooms[0].tiles[0].x = 832;
    package.rooms[0].tiles[0].y = 640;
    package.rooms[0].instances[0].x = 812;
    package.rooms[0].instances[0].y = 624;
    for instance in &mut package.rooms[0].instances {
        instance.is_checkpoint = false;
    }
    package.rooms[0]
        .instances
        .push(iwm_runtime_model::RoomInstancePlacement {
            instance_id: 99,
            object_id: 0,
            x: 64,
            y: 64,
            xscale: 1.0,
            yscale: 1.0,
            angle: 0.0,
            blend: 0x00ff_ffff,
            creation_block_id: None,
            is_solid: false,
            is_hazard: false,
            is_checkpoint: false,
        });

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert_eq!(frame.width, 800);
    assert_eq!(frame.height, 600);
    assert!(frame
        .commands
        .iter()
        .any(|command| matches!(command, RuntimeDrawCommand::DrawTile { x: 32, y: 32, .. })));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 0,
            x,
            y,
            ..
        } if *x >= 0 && *x <= 32 && *y >= 0 && *y <= 32
    )));
    assert!(!frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 0,
            x: -736,
            y: -544,
            ..
        }
    )));
}

#[test]
fn runtime_core_uses_exe_display_size_for_room_without_active_view() {
    let mut package = sample_package();
    package.manifest.display_source = Some(RuntimeDisplaySource::ExeResolution);
    package.manifest.display_width = Some(640);
    package.manifest.display_height = Some(480);
    package.rooms[0].width = 320;
    package.rooms[0].height = 240;
    package.rooms[0].views_enabled = false;

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert_eq!((frame.width, frame.height), (640, 480));
}

#[test]
fn runtime_core_clears_with_the_gm_room_background_colour() {
    let mut package = sample_package();
    package.rooms[0].background_colour = 0x0033_2211;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::Clear { colour }
            if (colour.r, colour.g, colour.b, colour.a) == (0x11, 0x22, 0x33, 0xff)
    )));
}

#[test]
fn runtime_core_measures_text_with_the_current_gm_font() {
    let mut package = sample_package();
    package.manifest.zero_uninitialized_vars = true;
    package.resources.fonts.push(FontResource {
        id: 4,
        name: "font12".into(),
        system_name: "Arial".into(),
        size: 12,
        bold: false,
        italic: false,
        range_start: 0,
        range_end: 255,
        map_width: 128,
        map_height: 128,
        image_path: "resources/fonts/4.png".into(),
        glyphs: (0..256)
            .map(|code| FontGlyphResource {
                code,
                x: 0,
                y: 0,
                width: 8,
                height: 12,
                offset: 0,
                advance: 8,
            })
            .collect(),
    });
    package.objects.push(ObjectDefinition {
        id: 8,
        name: "obj_label".into(),
        sprite_index: -1,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: Some(false),
        is_checkpoint: Some(false),
        is_player: false,
        events: vec![ObjectEventEntry {
            event_type: 8,
            sub_event: 0,
            event_tag: "draw".into(),
            block_id: "object:8:event:8:0".into(),
            action_count: 0,
        }],
    });
    package.rooms[0].instances.push(RoomInstancePlacement {
        instance_id: 99,
        object_id: 8,
        x: 0,
        y: 0,
        xscale: 1.0,
        yscale: 1.0,
        angle: 0.0,
        blend: 0x00ff_ffff,
        creation_block_id: None,
        is_solid: false,
        is_hazard: false,
        is_checkpoint: false,
    });
    let measure = |name: &str| LoweredLogicExpr::Call {
        name: name.into(),
        args: vec![LoweredLogicExpr::LiteralText("Medium".into())],
    };
    append_lowered_entry(
        &mut package,
        "object:8:event:8:0".into(),
        vec![
            LoweredLogicStatement::FunctionCall {
                name: "draw_set_font".into(),
                args: vec![LoweredLogicExpr::Identifier("font12".into())],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_text".into(),
                args: vec![
                    LoweredLogicExpr::BinaryExpr {
                        op: "-".into(),
                        left: Box::new(LoweredLogicExpr::LiteralNumber(100.0)),
                        right: Box::new(LoweredLogicExpr::BinaryExpr {
                            op: "/".into(),
                            left: Box::new(measure("string_width")),
                            right: Box::new(LoweredLogicExpr::LiteralNumber(2.0)),
                        }),
                    },
                    LoweredLogicExpr::BinaryExpr {
                        op: "-".into(),
                        left: Box::new(LoweredLogicExpr::LiteralNumber(50.0)),
                        right: Box::new(measure("string_height")),
                    },
                    LoweredLogicExpr::LiteralText("Medium".into()),
                ],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_text".into(),
                args: vec![
                    LoweredLogicExpr::LiteralNumber(0.0),
                    LoweredLogicExpr::LiteralNumber(0.0),
                    LoweredLogicExpr::Call {
                        name: "string".into(),
                        args: vec![LoweredLogicExpr::IndexAccess {
                            target: Box::new(LoweredLogicExpr::Identifier("menuDeath".into())),
                            index: Box::new(LoweredLogicExpr::LiteralNumber(1.0)),
                        }],
                    },
                ],
            },
        ],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawText { text, x: 76, y: 38, .. } if text == "Medium"
    )));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawText { text, .. } if text == "0"
    )));
}

#[test]
fn runtime_core_executes_draw_events_for_text_commands() {
    let mut package = sample_package();
    package.objects.push(ObjectDefinition {
        id: 8,
        name: "obj_label".into(),
        sprite_index: -1,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: Some(false),
        is_checkpoint: Some(false),
        is_player: false,
        events: vec![ObjectEventEntry {
            event_type: 8,
            sub_event: 0,
            event_tag: "draw".into(),
            block_id: "object:8:event:8:0".into(),
            action_count: 0,
        }],
    });
    package.rooms[0].instances.push(RoomInstancePlacement {
        instance_id: 99,
        object_id: 8,
        x: 40,
        y: 50,
        xscale: 1.0,
        yscale: 1.0,
        angle: 0.0,
        blend: 0x00ff_ffff,
        creation_block_id: None,
        is_solid: false,
        is_hazard: false,
        is_checkpoint: false,
    });
    append_lowered_entry(
        &mut package,
        "object:8:event:8:0".into(),
        vec![
            LoweredLogicStatement::FunctionCall {
                name: "draw_text".into(),
                args: vec![
                    LoweredLogicExpr::LiteralNumber(0.0),
                    LoweredLogicExpr::LiteralNumber(0.0),
                    LoweredLogicExpr::LiteralText("Default".into()),
                ],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_set_color".into(),
                args: vec![LoweredLogicExpr::Identifier("c_red".into())],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_set_halign".into(),
                args: vec![LoweredLogicExpr::Identifier("fa_center".into())],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_set_font".into(),
                args: vec![LoweredLogicExpr::Identifier("font40".into())],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_text".into(),
                args: vec![
                    LoweredLogicExpr::Identifier("x".into()),
                    LoweredLogicExpr::Identifier("y".into()),
                    LoweredLogicExpr::LiteralText("Data1".into()),
                ],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_rectangle".into(),
                args: vec![
                    LoweredLogicExpr::LiteralNumber(30.0),
                    LoweredLogicExpr::LiteralNumber(40.0),
                    LoweredLogicExpr::LiteralNumber(10.0),
                    LoweredLogicExpr::LiteralNumber(20.0),
                    LoweredLogicExpr::LiteralNumber(0.0),
                ],
            },
            LoweredLogicStatement::FunctionCall {
                name: "draw_sprite".into(),
                args: vec![
                    LoweredLogicExpr::Identifier("spr_sparse".into()),
                    LoweredLogicExpr::LiteralNumber(0.0),
                    LoweredLogicExpr::LiteralNumber(64.0),
                    LoweredLogicExpr::LiteralNumber(72.0),
                ],
            },
        ],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawText { text, colour, .. }
            if text == "Default"
                && colour.r == 0
                && colour.g == 0
                && colour.b == 0
                && colour.a == 255
    )));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawText {
            text,
            x: 40,
            y: 50,
            size: 40,
            colour,
            align,
            ..
        } if text == "Data1"
            && colour.r == 255
            && colour.g == 0
            && colour.b == 0
            && colour.a == 255
            && align == "center"
    )));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::FillRect {
            x: 10,
            y: 20,
            width: 20,
            height: 20,
            colour,
        } if colour.r == 255 && colour.g == 0 && colour.b == 0 && colour.a == 255
    )));
    assert!(frame.commands.iter().any(|command| matches!(
        command,
        RuntimeDrawCommand::DrawSprite {
            sprite_id: 1,
            x: 64,
            y: 72,
            ..
        }
    )));
}

#[cfg(feature = "local-sample-tests")]
fn menu_frame_texts_and_sprites(
    package: crate::RuntimePackage,
) -> (Vec<String>, Vec<usize>, Option<usize>) {
    let menu_room_id = package
        .rooms
        .iter()
        .find(|room| room.name.eq_ignore_ascii_case("rMenu"))
        .map(|room| room.id)
        .expect("sample package should include rMenu");
    let cursor_sprite_id = package
        .resources
        .sprites
        .iter()
        .find(|sprite| sprite.name.eq_ignore_ascii_case("sprPlayerRunning"))
        .map(|sprite| sprite.id);
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.reload_room(menu_room_id).unwrap();
    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    let texts = frame
        .commands
        .iter()
        .filter_map(|command| match command {
            RuntimeDrawCommand::DrawText { text, .. } => Some(text.clone()),
            _ => None,
        })
        .collect::<Vec<_>>();
    let sprites = frame
        .commands
        .iter()
        .filter_map(|command| match command {
            RuntimeDrawCommand::DrawSprite { sprite_id, .. } => Some(*sprite_id),
            _ => None,
        })
        .collect::<Vec<_>>();
    (texts, sprites, cursor_sprite_id)
}

#[test]
#[cfg(feature = "local-sample-tests")]
fn real_sample_menu_draws_slot_text_and_cursor_sprite() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let (texts, sprites, cursor_sprite_id) = menu_frame_texts_and_sprites(package);
    let cursor_sprite_id = cursor_sprite_id.expect("Dife package should include sprPlayerRunning");

    for expected in ["Data1", "Data2", "Data3"] {
        assert!(
            texts.iter().any(|text| text == expected),
            "rMenu texts: {texts:?}"
        );
    }
    assert!(
        sprites.contains(&cursor_sprite_id),
        "Dife rMenu should draw cursor sprite {cursor_sprite_id}, drawn sprites: {sprites:?}"
    );
}

#[test]
#[cfg(feature = "local-sample-tests")]
fn crimson_menu_draws_slot_text() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let (texts, sprites, _) = menu_frame_texts_and_sprites(package);

    for expected in ["Data1", "Data2", "Data3", "Death", "Time", "0", "0:00:00"] {
        assert!(
            texts.iter().any(|text| text == expected),
            "rMenu texts: {texts:?}"
        );
    }
    assert!(
        !sprites.is_empty(),
        "Crimson rMenu should draw its slot sprites"
    );
}

#[test]
#[cfg(feature = "local-sample-tests")]
fn crimson_difficulty_room_draws_labels() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let room_id = package
        .rooms
        .iter()
        .find(|room| room.name.eq_ignore_ascii_case("rSelectStage"))
        .expect("sample package should include rSelectStage")
        .id;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.reload_room(room_id).unwrap();
    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    let texts = frame
        .commands
        .iter()
        .filter_map(|command| match command {
            RuntimeDrawCommand::DrawText { text, .. } => Some(text.as_str()),
            _ => None,
        })
        .collect::<Vec<_>>();
    for label in ["Medium", "Hard", "VeryHard", "Impossible", "LoadGame"] {
        assert!(texts.contains(&label), "rSelectStage texts: {texts:?}");
    }
}

#[test]
fn runtime_core_prefers_active_view_over_exe_display_size() {
    let mut package = sample_package();
    package.manifest.display_source = Some(RuntimeDisplaySource::ExeResolution);
    package.manifest.display_width = Some(640);
    package.manifest.display_height = Some(480);
    package.rooms[0].views_enabled = true;
    package.rooms[0].views[0].visible = true;
    package.rooms[0].views[0].port_w = 800;
    package.rooms[0].views[0].port_h = 600;

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert_eq!((frame.width, frame.height), (800, 600));
}

#[test]
fn runtime_core_does_not_render_new_room_pre_step_transients_after_room_goto() {
    let mut package = sample_package();
    package.objects.push(ObjectDefinition {
        id: 8,
        name: "obj_transient".into(),
        sprite_index: 1,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: Some(false),
        is_checkpoint: Some(false),
        is_player: false,
        events: vec![ObjectEventEntry {
            event_type: 3,
            sub_event: 0,
            event_tag: "step".into(),
            block_id: "object:8:event:3:0".into(),
            action_count: 0,
        }],
    });
    package.rooms[1].instances.push(RoomInstancePlacement {
        instance_id: 99,
        object_id: 8,
        x: 32,
        y: 32,
        xscale: 1.0,
        yscale: 1.0,
        angle: 0.0,
        blend: 0x00ff_ffff,
        creation_block_id: None,
        is_solid: false,
        is_hazard: false,
        is_checkpoint: false,
    });
    add_step_block(
        &mut package,
        vec![LoweredLogicStatement::FunctionCall {
            name: "room_goto".into(),
            args: vec![LoweredLogicExpr::LiteralNumber(9.0)],
        }],
    );
    append_lowered_entry(
        &mut package,
        "object:8:event:3:0".into(),
        vec![LoweredLogicStatement::FunctionCall {
            name: "instance_destroy".into(),
            args: vec![],
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.tick(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    assert_eq!(frame.room_id, Some(9));
    assert!(!frame
        .commands
        .iter()
        .any(|command| matches!(command, RuntimeDrawCommand::DrawSprite { sprite_id: 1, .. })));
}
