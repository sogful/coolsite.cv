use std::collections::HashMap;
use std::path::Path;

use iwm_runtime_host::{
    Rgba8, RuntimeDialogAnswer, RuntimeDialogKind, RuntimeDialogRequest, RuntimeDrawCommand,
    RuntimeHost, RuntimeHostErrorKind, RuntimeSoundMode,
};
use iwm_runtime_model::{
    FontResource, ObjectDefinition, PathResource, RoomDefinition, SpriteResource,
};

use super::assignment::{assign_runtime_value, next_room_id, runtime_value_to_room_id};
use super::calls::{
    dispatch_legacy_audio_call, dispatch_motion_add, dispatch_move_bounce_solid,
    dispatch_move_contact_solid, dispatch_move_towards_point, dispatch_move_wrap,
    dispatch_runtime_sound_call, evaluate_file_bin_byte, evaluate_file_bin_handle,
    resolve_runtime_sound_id, runtime_value_to_i32,
};
use super::context::{
    RuntimeBinaryFileState, RuntimeEvalContext, RuntimeExecutionScope,
    RuntimeInstanceCreateRequest, RuntimeTextFileState,
};
use super::control_flow::{
    env_has_pending_scene_change, merged_statement_overlay, sync_instance_from_updates,
    write_with_target_indices,
};
use super::diagnostics::{
    record_unsupported_expr_functions, record_unsupported_function, record_unsupported_statement,
    trace_message,
};
use super::eval::{assignable_key, is_truthy};
use super::eval_functions::{
    evaluate_collision_line_with_scratch, evaluate_collision_rectangle_with_scratch,
    evaluate_distance_to_object_with_scratch, evaluate_instance_number_with_scratch,
    evaluate_irandom_call,
};
use super::eval_variables::{
    evaluate_expr_with_resource_constants, instance_member_access, runtime_value_to_path_id,
};
use super::instances::{
    assign_runtime_member_reference, pending_create_member_value,
    pending_create_member_value_by_object_target, runtime_instance_create_request,
};
use super::overlay::RuntimeSparseInstanceOverlay;
use crate::event_dispatch::{
    event_owner_id_for_block_id, inherited_event_block_id, RuntimeEventSelector,
};
use crate::helpers::{as_number, collides_at, record_host_diagnostic};
use crate::path::start_path;
use crate::room_builder::{object_is_hazard, sprite_metrics_for_object};
use crate::tick_context::RuntimeObjectQueryScratch;
use crate::{
    LoweredLogicEntry, LoweredLogicExpr, LoweredLogicStatement, RuntimeInstance, RuntimeValue,
};

#[derive(Debug, Clone)]
pub(crate) struct RuntimeExecutionTrace {
    pub(crate) room_id: usize,
    pub(crate) tick: u64,
    pub(crate) block_id: String,
    pub(crate) object_name: String,
    pub(crate) event_tag: String,
}

pub(crate) struct RuntimeStatementEnvironment<'a, H: RuntimeHost> {
    pub(crate) script_entries: &'a HashMap<String, LoweredLogicEntry>,
    pub(crate) create_event_entries: &'a HashMap<usize, Vec<LoweredLogicEntry>>,
    pub(crate) sound_index: &'a HashMap<String, i32>,
    pub(crate) globals: &'a mut HashMap<String, RuntimeValue>,
    pub(crate) room_speed: &'a mut u32,
    pub(crate) pending_room_transition: &'a mut Option<usize>,
    pub(crate) pending_room_reset: &'a mut bool,
    pub(crate) pending_game_restart: &'a mut bool,
    pub(crate) pending_dialog: &'a mut Option<RuntimeDialogRequest>,
    pub(crate) dialog_response: &'a mut Option<RuntimeDialogAnswer>,
    pub(crate) active_one_shot_sounds: &'a mut std::collections::HashSet<i32>,
    pub(crate) binary_files: &'a mut RuntimeBinaryFileState,
    pub(crate) text_files: &'a mut RuntimeTextFileState,
    /// Nesting depth of `execute_file()` / `execute_string()`, to bound recursion
    /// through save files the runtime does not control.
    pub(crate) execute_source_depth: &'a mut u32,
    pub(crate) host: &'a mut H,
    pub(crate) diagnostics: &'a mut Vec<iwm_runtime_host::RuntimeDiagnostic>,
    pub(crate) last_player_event: &'a mut Option<String>,
    pub(crate) object_query_scratch: Option<&'a mut RuntimeObjectQueryScratch>,
    pub(crate) with_target_indices: &'a mut Vec<usize>,
    pub(crate) room_instance_updates: &'a mut RuntimeSparseInstanceOverlay,
    pub(crate) room_instance_creates: &'a mut Vec<RuntimeInstanceCreateRequest>,
    pub(crate) objects: &'a [ObjectDefinition],
    pub(crate) rooms: &'a [RoomDefinition],
    pub(crate) sprites: &'a [SpriteResource],
    pub(crate) paths: &'a [PathResource],
    pub(crate) sprite_index: &'a HashMap<usize, usize>,
    pub(crate) sprite_ids_by_name: &'a HashMap<String, usize>,
    pub(crate) path_ids_by_name: &'a HashMap<String, usize>,
    pub(crate) fonts: &'a [FontResource],
    pub(crate) font_index_by_name: &'a HashMap<String, usize>,
    pub(crate) zero_uninitialized_vars: bool,
    pub(crate) lowered_entries: &'a [LoweredLogicEntry],
    pub(crate) event_selector: Option<RuntimeEventSelector>,
    pub(crate) event_owner_id: Option<usize>,
    pub(crate) draw: Option<&'a mut RuntimeDrawContext>,
    pub(crate) trace: RuntimeExecutionTrace,
}

#[derive(Debug)]
pub(crate) struct RuntimeDrawContext {
    colour: Rgba8,
    align: String,
    size: u32,
    font_name: Option<String>,
    font_bold: bool,
    font_italic: bool,
    commands: Vec<RuntimeDrawCommand>,
}

struct DrawFont {
    name: Option<String>,
    size: u32,
    bold: bool,
    italic: bool,
}

impl RuntimeDrawContext {
    pub(crate) fn finish(self) -> Vec<RuntimeDrawCommand> {
        self.commands
    }
}

impl Default for RuntimeDrawContext {
    fn default() -> Self {
        Self {
            colour: Rgba8 {
                r: 0,
                g: 0,
                b: 0,
                a: 255,
            },
            align: "left".into(),
            size: 16,
            font_name: None,
            font_bold: false,
            font_italic: false,
            commands: Vec::new(),
        }
    }
}

fn schedule_room_transition<H: RuntimeHost>(
    value: &RuntimeValue,
    instance: &RuntimeInstance,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> bool {
    let Some(room_id) = runtime_value_to_room_id(value).filter(|room_id| {
        eval_context
            .map(|context| context.room_order.contains(room_id))
            .unwrap_or(true)
    }) else {
        return false;
    };

    record_host_diagnostic(
        env.host,
        env.diagnostics,
        iwm_runtime_host::RuntimeDiagnosticLevel::Info,
        "runtime-room-transition-requested",
        format!(
            "{} target_room={} pos=({},{}) prev=({},{})",
            trace_message(&env.trace, instance),
            room_id,
            instance.x,
            instance.y,
            instance.previous_x,
            instance.previous_y,
        ),
    );
    *env.pending_game_restart = false;
    *env.pending_room_reset = false;
    *env.pending_room_transition = Some(room_id);
    true
}

fn assign_runtime_value_or_room_transition<H: RuntimeHost>(
    target: &LoweredLogicExpr,
    key: String,
    value: RuntimeValue,
    instance: &mut RuntimeInstance,
    scope: &mut RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    if matches!(target, LoweredLogicExpr::Identifier(name) if name.eq_ignore_ascii_case("room") && !scope.is_local_key(name))
    {
        if !schedule_room_transition(&value, instance, eval_context, env) {
            record_host_diagnostic(
                env.host,
                env.diagnostics,
                iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                "runtime-step-room-assignment-unresolved",
                format!(
                    "could not resolve room assignment target for {}",
                    instance.object_name
                ),
            );
        }
        return;
    }

    assign_runtime_value(
        key,
        value,
        instance,
        env.globals,
        scope,
        Some(&mut *env.room_speed),
        env.sprites,
        env.sprite_index,
    );
}

pub(crate) fn apply_runtime_statement<H: RuntimeHost>(
    statement: &LoweredLogicStatement,
    instance: &mut RuntimeInstance,
    instance_index: usize,
    scope: &mut RuntimeExecutionScope,
    destroy_event_entries: &HashMap<usize, Vec<LoweredLogicEntry>>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> Option<RuntimeValue> {
    match statement {
        LoweredLogicStatement::Assignment { target, value } => {
            if let Some(value) = evaluate_with_diagnostics(
                value,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            ) {
                if assign_runtime_member_reference(
                    target,
                    value.clone(),
                    instance,
                    instance_index,
                    scope,
                    eval_context,
                    env,
                ) {
                    return None;
                }
                if let Some(key) = assignable_key(
                    target,
                    Some(instance),
                    env.globals,
                    Some(scope),
                    eval_context,
                ) {
                    assign_runtime_value_or_room_transition(
                        target,
                        key,
                        value,
                        instance,
                        scope,
                        eval_context,
                        env,
                    );
                }
            }
        }
        LoweredLogicStatement::Conditional {
            condition,
            then_branch,
            else_branch,
        } => {
            let condition_value = evaluate_with_diagnostics(
                condition,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            );
            if env_has_pending_scene_change(env) {
                return None;
            }
            let branch = if is_truthy(condition_value) {
                then_branch
            } else {
                else_branch
            };
            for nested in branch {
                if let Some(value) = apply_runtime_statement(
                    nested,
                    instance,
                    instance_index,
                    scope,
                    destroy_event_entries,
                    eval_context,
                    env,
                ) {
                    return Some(value);
                }
            }
        }
        LoweredLogicStatement::ConditionalChain {
            branches,
            else_branch,
        } => {
            // A dialog-suspending condition must stop the whole chain before
            // any later condition, the else body, or a matched branch body
            // can run on this tick.
            let mut selected: Option<&[LoweredLogicStatement]> = None;
            for branch in branches {
                let value = evaluate_with_diagnostics(
                    &branch.condition,
                    Some(instance),
                    Some(scope),
                    eval_context,
                    env,
                    instance,
                );
                if env_has_pending_scene_change(env) {
                    return None;
                }
                if is_truthy(value) {
                    selected = Some(branch.body.as_slice());
                    break;
                }
            }
            let branch = selected.unwrap_or(else_branch);
            for nested in branch {
                if let Some(value) = apply_runtime_statement(
                    nested,
                    instance,
                    instance_index,
                    scope,
                    destroy_event_entries,
                    eval_context,
                    env,
                ) {
                    return Some(value);
                }
            }
        }
        LoweredLogicStatement::Switch { expression, cases } => {
            let value = evaluate_with_diagnostics(
                expression,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )?;
            let mut default_index = None;
            let mut start_index = None;
            for (index, switch_case) in cases.iter().enumerate() {
                let Some(case_value) = switch_case.value.as_ref() else {
                    default_index.get_or_insert(index);
                    continue;
                };
                if evaluate_with_diagnostics(
                    case_value,
                    Some(instance),
                    Some(scope),
                    eval_context,
                    env,
                    instance,
                )
                .is_some_and(|case_value| runtime_values_equal(&value, &case_value))
                {
                    start_index = Some(index);
                    break;
                }
                if env_has_pending_scene_change(env) {
                    // A dialog-suspending case expression must stop case
                    // matching; falling through would select a wrong branch.
                    return None;
                }
            }

            if let Some(start_index) = start_index.or(default_index) {
                for switch_case in &cases[start_index..] {
                    for nested in &switch_case.body {
                        if let Some(value) = apply_runtime_statement(
                            nested,
                            instance,
                            instance_index,
                            scope,
                            destroy_event_entries,
                            eval_context,
                            env,
                        ) {
                            return Some(value);
                        }
                    }
                    if switch_case.break_after {
                        break;
                    }
                }
            }
        }
        LoweredLogicStatement::VariableDeclaration { names } => {
            for name in names {
                scope.declare(name);
            }
        }
        LoweredLogicStatement::Return { value } => {
            return Some(
                value
                    .as_ref()
                    .and_then(|value| {
                        evaluate_with_diagnostics(
                            value,
                            Some(instance),
                            Some(scope),
                            eval_context,
                            env,
                            instance,
                        )
                    })
                    .unwrap_or(RuntimeValue::Number(0.0)),
            );
        }
        LoweredLogicStatement::FunctionCall { name, args } => {
            if dispatch_legacy_audio_call(env, name, args, instance, scope, eval_context).is_some()
            {
                return None;
            }
            match name.as_str() {
                "room_goto" => {
                    let transition_scheduled = args
                        .first()
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .map(|value| schedule_room_transition(&value, instance, eval_context, env))
                        .unwrap_or(false);
                    if !transition_scheduled {
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                            "runtime-step-room-goto-unresolved",
                            format!(
                                "could not resolve room_goto target for {}",
                                instance.object_name
                            ),
                        );
                    }
                }
                "room_goto_next" => {
                    if let Some(room_id) = next_room_id(instance, env.globals, eval_context) {
                        *env.pending_game_restart = false;
                        *env.pending_room_reset = false;
                        *env.pending_room_transition = Some(room_id);
                    } else {
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                            "runtime-step-room-goto-next-unresolved",
                            format!(
                                "could not resolve room_goto_next target for {}",
                                instance.object_name
                            ),
                        );
                    }
                }
                "game_restart" => {
                    *env.pending_room_transition = None;
                    *env.pending_room_reset = false;
                    *env.pending_game_restart = true;
                }
                "draw_set_color" => {
                    let colour = args.first().and_then(draw_colour_arg)?;
                    if let Some(draw) = env.draw.as_deref_mut() {
                        draw.colour = colour;
                    }
                }
                "draw_set_halign" => {
                    let align = args.first().and_then(draw_align_arg)?;
                    if let Some(draw) = env.draw.as_deref_mut() {
                        draw.align = align;
                    }
                }
                "draw_set_font" => {
                    let font = args.first().and_then(|arg| draw_font_arg(arg, env))?;
                    if let Some(draw) = env.draw.as_deref_mut() {
                        draw.size = font.size;
                        draw.font_name = font.name;
                        draw.font_bold = font.bold;
                        draw.font_italic = font.italic;
                    }
                }
                "draw_text" => {
                    dispatch_draw_text(args, instance, scope, eval_context, env);
                }
                "draw_rectangle" => {
                    dispatch_draw_rectangle(args, instance, scope, eval_context, env);
                }
                "draw_sprite" => {
                    dispatch_draw_sprite(args, instance, scope, eval_context, env);
                }
                "show_message" => {
                    let text = args
                        .first()
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .map(|value| runtime_value_to_string_text(&value))
                        .unwrap_or_default();
                    let _ =
                        dispatch_runtime_dialog(env, RuntimeDialogKind::Message, text, instance);
                }
                "message_text_font" | "message_text_color" | "message_text_align"
                | "message_button" | "message_position" | "message_size" | "message_alpha"
                | "message_caption" | "message_background" => {}
                "get_integer" => {}
                "event_inherited" => {
                    dispatch_event_inherited(
                        instance,
                        instance_index,
                        scope,
                        destroy_event_entries,
                        eval_context,
                        env,
                    );
                }
                "sound_play" => {
                    dispatch_runtime_sound_call(
                        env,
                        name,
                        args,
                        Some(RuntimeSoundMode::Once),
                        instance,
                        scope,
                        eval_context,
                    );
                }
                "sound_loop" => {
                    dispatch_runtime_sound_call(
                        env,
                        name,
                        args,
                        Some(RuntimeSoundMode::Loop),
                        instance,
                        scope,
                        eval_context,
                    );
                }
                "sound_stop" => {
                    dispatch_runtime_sound_call(
                        env,
                        name,
                        args,
                        None,
                        instance,
                        scope,
                        eval_context,
                    );
                }
                "sound_stop_all" => {
                    env.active_one_shot_sounds.clear();
                    if let Err(error) = env.host.stop_all_sounds() {
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                            "runtime-audio-host-error",
                            format!(
                                "{} function=sound_stop_all error={}",
                                trace_message(&env.trace, instance),
                                error
                            ),
                        );
                    }
                }
                "keyboard_set_numlock" => {
                    if let Some(value) = args.first().and_then(|arg| {
                        evaluate_with_diagnostics(
                            arg,
                            Some(instance),
                            Some(scope),
                            eval_context,
                            env,
                            instance,
                        )
                    }) {
                        env.host.set_keyboard_numlock(is_truthy(Some(value)));
                    }
                }
                "move_contact_solid" => {
                    dispatch_move_contact_solid(env, args, instance, scope, eval_context);
                }
                "move_towards_point" => {
                    dispatch_move_towards_point(env, args, instance, scope, eval_context);
                }
                "motion_add" => {
                    dispatch_motion_add(env, args, instance, scope, eval_context);
                }
                "move_wrap" => {
                    dispatch_move_wrap(env, args, instance, scope, eval_context);
                }
                "move_bounce_solid" | "move_bounce" => {
                    dispatch_move_bounce_solid(env, args, instance, scope, eval_context);
                }
                "path_start" => {
                    if let Some((path, speed, end_action, absolute)) =
                        evaluate_path_start_args(args, instance, scope, eval_context, env)
                    {
                        start_path(instance, &path, speed, end_action, absolute);
                    }
                }
                "path_end" => {
                    instance
                        .vars
                        .insert("path_index".into(), RuntimeValue::Number(-1.0));
                }
                "__iwm_action_move" => {
                    let Some(LoweredLogicExpr::LiteralText(options)) = args.first() else {
                        return None;
                    };
                    let directions = options
                        .bytes()
                        .take(9)
                        .enumerate()
                        .filter_map(|(index, selected)| {
                            (selected == b'1').then_some((
                                index,
                                [225.0_f64, 270.0, 315.0, 180.0, 0.0, 0.0, 135.0, 90.0, 45.0]
                                    [index],
                            ))
                        })
                        .collect::<Vec<_>>();
                    if directions.is_empty() {
                        return None;
                    }
                    let chosen = if directions.len() == 1 {
                        0
                    } else {
                        evaluate_irandom_call(
                            &[LoweredLogicExpr::LiteralNumber(
                                (directions.len() - 1) as f64,
                            )],
                            Some(instance),
                            env.globals,
                            Some(scope),
                            eval_context,
                        )
                        .and_then(|value| as_number(&value))
                        .unwrap_or(0.0) as usize
                    };
                    let (direction_index, direction) = directions[chosen.min(directions.len() - 1)];
                    let speed = args
                        .get(1)
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .and_then(|value| as_number(&value))
                        .unwrap_or(0.0);
                    let relative = args
                        .get(2)
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .map(|value| is_truthy(Some(value)))
                        .unwrap_or(false);
                    if direction_index == 4 {
                        if !relative {
                            instance.set_speed(0.0);
                        }
                    } else if relative {
                        let radians = direction.to_radians();
                        instance.set_hvspeed(
                            instance.hspeed + radians.cos() * speed,
                            instance.vspeed - radians.sin() * speed,
                        );
                    } else {
                        instance.set_direction(direction);
                        instance.set_speed(speed);
                    }
                }
                "file_bin_write_byte" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    let byte =
                        evaluate_file_bin_byte(args.get(1), instance, scope, eval_context, env)?;
                    env.binary_files.write_byte(handle, byte);
                }
                "file_bin_seek" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    let cursor = args
                        .get(1)
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .and_then(|value| runtime_value_to_i32(&value))
                        .filter(|cursor| *cursor >= 0)? as usize;
                    env.binary_files.seek(handle, cursor);
                }
                "file_delete" => {
                    let Some(RuntimeValue::Text(path)) = args.first().and_then(|arg| {
                        evaluate_runtime_expr(
                            arg,
                            Some(instance),
                            Some(scope),
                            eval_context,
                            env,
                            instance,
                        )
                    }) else {
                        return None;
                    };
                    if let Err(error) = env.host.remove_temp(Path::new(&path)) {
                        if error.kind() != RuntimeHostErrorKind::NotFound {
                            record_host_diagnostic(
                                env.host,
                                env.diagnostics,
                                iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                                "runtime-file-host-error",
                                format!(
                                    "{} function=file_delete path={} error={}",
                                    trace_message(&env.trace, instance),
                                    path,
                                    error
                                ),
                            );
                        }
                    }
                }
                "file_bin_close" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    if let Err(error) = env.binary_files.close(env.host, handle) {
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                            "runtime-file-host-error",
                            format!(
                                "{} function=file_bin_close handle={} error={}",
                                trace_message(&env.trace, instance),
                                handle,
                                error
                            ),
                        );
                    }
                }
                "file_text_write_string" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    let value = args.get(1).and_then(|arg| {
                        evaluate_with_diagnostics(
                            arg,
                            Some(instance),
                            Some(scope),
                            eval_context,
                            env,
                            instance,
                        )
                    })?;
                    env.text_files
                        .write_string(handle, &runtime_value_to_string_text(&value));
                }
                "file_text_write_real" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    let value = args.get(1).and_then(|arg| {
                        evaluate_with_diagnostics(
                            arg,
                            Some(instance),
                            Some(scope),
                            eval_context,
                            env,
                            instance,
                        )
                    })?;
                    env.text_files
                        .write_string(handle, &runtime_value_to_string_text(&value));
                }
                "file_text_writeln" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    env.text_files.writeln(handle);
                }
                "file_text_readln" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    env.text_files.readln(handle);
                }
                "file_text_close" => {
                    let handle =
                        evaluate_file_bin_handle(args.first(), instance, scope, eval_context, env)?;
                    if let Err(error) = env.text_files.close(env.host, handle) {
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                            "runtime-file-host-error",
                            format!(
                                "{} function=file_text_close handle={} error={}",
                                trace_message(&env.trace, instance),
                                handle,
                                error
                            ),
                        );
                    }
                }
                "execute_file" | "execute_string" => {
                    execute_runtime_source(
                        name,
                        args,
                        instance,
                        instance_index,
                        scope,
                        destroy_event_entries,
                        eval_context,
                        env,
                    );
                }
                "__iwm_action_wrap" => {
                    let context = eval_context?;
                    let mode = args
                        .first()
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .and_then(|value| as_number(&value))
                        .map(|value| value.round() as i32)
                        .unwrap_or(2);
                    let image_xscale = instance
                        .vars
                        .get("image_xscale")
                        .and_then(as_number)
                        .unwrap_or(1.0);
                    let image_yscale = instance
                        .vars
                        .get("image_yscale")
                        .and_then(as_number)
                        .unwrap_or(1.0);
                    let sprite_width = instance.width as f64 * image_xscale;
                    let sprite_height = instance.height as f64 * image_yscale;
                    if mode != 1 {
                        let room_width = context.room_width as f64;
                        if instance.hspeed > 0.0 && instance.x > room_width {
                            instance.x -= room_width + sprite_width;
                        } else if instance.hspeed < 0.0 && instance.x < 0.0 {
                            instance.x += room_width + sprite_width;
                        }
                    }
                    if mode != 0 {
                        let room_height = context.room_height as f64;
                        if instance.vspeed > 0.0 && instance.y > room_height {
                            instance.y -= room_height + sprite_height;
                        } else if instance.vspeed < 0.0 && instance.y < 0.0 {
                            instance.y += room_height + sprite_height;
                        }
                    }
                }
                "instance_deactivate_object" => {
                    let (Some(context), Some(target)) = (eval_context, args.first()) else {
                        return None;
                    };
                    write_with_target_indices(
                        target,
                        instance_index,
                        instance,
                        scope,
                        context,
                        env.globals,
                        env.with_target_indices,
                    );
                    let mut target_indices = std::mem::take(env.with_target_indices);
                    for target_index in target_indices.iter().copied() {
                        if target_index == instance_index {
                            instance.active = false;
                            continue;
                        }
                        let Some(mut target_instance) = env
                            .room_instance_updates
                            .get(target_index)
                            .cloned()
                            .or_else(|| context.room_instance(target_index).cloned())
                        else {
                            continue;
                        };
                        target_instance.active = false;
                        env.room_instance_updates.set(target_index, target_instance);
                    }
                    target_indices.clear();
                    *env.with_target_indices = target_indices;
                }
                "instance_destroy" => {
                    if instance.alive {
                        if instance.player_candidate {
                            let message = format!(
                                "{} function=instance_destroy",
                                trace_message(&env.trace, instance)
                            );
                            let same_tick_kill =
                                env.last_player_event.as_deref().is_some_and(|previous| {
                                    previous.contains(&format!("tick={}", env.trace.tick))
                                        && previous.contains("function=killPlayer")
                                });
                            if !same_tick_kill {
                                *env.last_player_event = Some(message);
                            }
                        }
                        let entries = destroy_event_entries
                            .get(&instance.object_id)
                            .cloned()
                            .unwrap_or_default();
                        execute_lifecycle_event(
                            &entries,
                            RuntimeEventSelector::Destroy,
                            "destroy",
                            instance,
                            instance_index,
                            eval_context,
                            env,
                        );
                        instance.alive = false;
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Info,
                            "runtime-instance-destroyed",
                            format!(
                                "{} object={} runtime_id={}",
                                trace_message(&env.trace, instance),
                                instance.object_name,
                                instance.runtime_id
                            ),
                        );
                    }
                }
                "instance_change" => {
                    let Some(context) = eval_context else {
                        return None;
                    };
                    let Some(object_id) = args.first().and_then(|arg| {
                        if let LoweredLogicExpr::Identifier(name) = arg {
                            if let Some(object_id) = context
                                .place_target_ids_by_name
                                .get(&name.to_ascii_lowercase())
                                .and_then(|ids| ids.first().copied())
                            {
                                return Some(object_id);
                            }
                        }
                        evaluate_with_diagnostics(
                            arg,
                            Some(instance),
                            Some(scope),
                            eval_context,
                            env,
                            instance,
                        )
                        .and_then(|value| as_number(&value))
                        .filter(|value| value.is_finite() && *value >= 0.0)
                        .map(|value| value.round() as usize)
                    }) else {
                        return None;
                    };
                    let run_events = args
                        .get(1)
                        .and_then(|arg| {
                            evaluate_with_diagnostics(
                                arg,
                                Some(instance),
                                Some(scope),
                                eval_context,
                                env,
                                instance,
                            )
                        })
                        .map(|value| is_truthy(Some(value)))
                        .unwrap_or(false);
                    let Some(object) = env
                        .objects
                        .iter()
                        .find(|object| object.id == object_id)
                        .cloned()
                    else {
                        return None;
                    };

                    if run_events {
                        let entries = destroy_event_entries
                            .get(&instance.object_id)
                            .cloned()
                            .unwrap_or_default();
                        execute_lifecycle_event(
                            &entries,
                            RuntimeEventSelector::Destroy,
                            "destroy",
                            instance,
                            instance_index,
                            eval_context,
                            env,
                        );
                    }

                    let metrics = sprite_metrics_for_object(&object, env.sprites);
                    instance.object_id = object.id;
                    instance.object_name.clone_from(&object.name);
                    instance.width = metrics.width;
                    instance.height = metrics.height;
                    instance.origin_x = metrics.origin_x;
                    instance.origin_y = metrics.origin_y;
                    instance.bbox_left = metrics.bbox_left;
                    instance.bbox_right = metrics.bbox_right;
                    instance.bbox_top = metrics.bbox_top;
                    instance.bbox_bottom = metrics.bbox_bottom;
                    instance.collision_masks = metrics.collision_masks;
                    instance.per_frame_collision_masks = metrics.per_frame_collision_masks;
                    instance.visible = object.visible;
                    instance.persistent = object.persistent;
                    instance.solid = object.solid;
                    instance.hazard = object_is_hazard(env.objects, object.id);
                    instance.checkpoint = object.is_checkpoint.unwrap_or(false);
                    instance.player_candidate = object.is_player;
                    instance.vars.insert(
                        "sprite_index".into(),
                        RuntimeValue::Number(object.sprite_index as f64),
                    );
                    instance
                        .vars
                        .insert("depth".into(), RuntimeValue::Number(object.depth as f64));
                    instance
                        .vars
                        .insert("visible".into(), RuntimeValue::Bool(object.visible));

                    if run_events {
                        let entries = env
                            .create_event_entries
                            .get(&object_id)
                            .cloned()
                            .unwrap_or_default();
                        execute_lifecycle_event(
                            &entries,
                            RuntimeEventSelector::Create,
                            "create",
                            instance,
                            instance_index,
                            eval_context,
                            env,
                        );
                    }
                }
                "instance_create" => {
                    if let Some(create) = runtime_instance_create_request(
                        args,
                        instance,
                        env.globals,
                        scope,
                        eval_context,
                        env.room_instance_creates.len(),
                    ) {
                        env.room_instance_creates.push(create);
                    }
                }
                _ => {
                    if name == "killPlayer" {
                        let shadowed = kill_player_is_shadowed_by_solid(
                            env.event_selector.as_ref(),
                            instance,
                            eval_context,
                        );
                        let other = eval_context
                            .and_then(RuntimeEvalContext::other_instance)
                            .map(|other| {
                                format!(
                                    " other={}#{} other_pos=({},{}) other_prev=({},{}) other_hazard={}",
                                    other.object_name,
                                    other.runtime_id,
                                    other.x,
                                    other.y,
                                    other.previous_x,
                                    other.previous_y,
                                    other.hazard,
                                )
                            })
                            .unwrap_or_default();
                        let message = format!(
                            "{} function=killPlayer shadowed={} event={} pos=({},{}) prev=({},{}){}",
                            trace_message(&env.trace, instance),
                            shadowed,
                            runtime_event_selector_label(env.event_selector.as_ref()),
                            instance.x,
                            instance.y,
                            instance.previous_x,
                            instance.previous_y,
                            other,
                        );
                        if shadowed {
                            return None;
                        }
                        *env.last_player_event = Some(message.clone());
                        record_host_diagnostic(
                            env.host,
                            env.diagnostics,
                            iwm_runtime_host::RuntimeDiagnosticLevel::Info,
                            "runtime-kill-player-requested",
                            message,
                        );
                    }
                    if execute_runtime_script(
                        name,
                        args,
                        instance,
                        instance_index,
                        scope,
                        destroy_event_entries,
                        eval_context,
                        env,
                    )
                    .is_none()
                    {
                        record_unsupported_function(env, name, instance);
                    }
                }
            }
        }
        LoweredLogicStatement::With { target, body } => {
            let context = eval_context?;
            write_with_target_indices(
                target,
                instance_index,
                instance,
                scope,
                context,
                env.globals,
                env.with_target_indices,
            );
            let target_indices = std::mem::take(env.with_target_indices);
            let other_snapshot = instance.clone();
            for &target_index in &target_indices {
                if target_index == instance_index {
                    for nested in body {
                        let overlay = merged_statement_overlay(
                            &context.room_instance_overlay,
                            env.room_instance_updates,
                            instance_index,
                            instance,
                        );
                        let with_context = context.with_other_and_overlay(&other_snapshot, overlay);
                        if let Some(value) = apply_runtime_statement(
                            nested,
                            instance,
                            instance_index,
                            scope,
                            destroy_event_entries,
                            Some(&with_context),
                            env,
                        ) {
                            sync_instance_from_updates(
                                instance_index,
                                instance,
                                env.room_instance_updates,
                            );
                            *env.with_target_indices = target_indices;
                            return Some(value);
                        }
                        sync_instance_from_updates(
                            instance_index,
                            instance,
                            env.room_instance_updates,
                        );
                        if env_has_pending_scene_change(env) {
                            break;
                        }
                    }
                    if env_has_pending_scene_change(env) {
                        break;
                    }
                    continue;
                }

                let Some(mut target_instance) = context.room_instance(target_index).cloned() else {
                    continue;
                };
                sync_instance_from_updates(
                    target_index,
                    &mut target_instance,
                    env.room_instance_updates,
                );
                if !target_instance.is_active() {
                    continue;
                }
                for nested in body {
                    let overlay = merged_statement_overlay(
                        &context.room_instance_overlay,
                        env.room_instance_updates,
                        target_index,
                        &target_instance,
                    );
                    let with_context = context.with_other_and_overlay(&other_snapshot, overlay);
                    if let Some(value) = apply_runtime_statement(
                        nested,
                        &mut target_instance,
                        target_index,
                        scope,
                        destroy_event_entries,
                        Some(&with_context),
                        env,
                    ) {
                        env.room_instance_updates.set(target_index, target_instance);
                        *env.with_target_indices = target_indices;
                        return Some(value);
                    }
                    sync_instance_from_updates(
                        target_index,
                        &mut target_instance,
                        env.room_instance_updates,
                    );
                    if env_has_pending_scene_change(env) {
                        break;
                    }
                }
                env.room_instance_updates.set(target_index, target_instance);
                if env_has_pending_scene_change(env) {
                    break;
                }
            }
            *env.with_target_indices = target_indices;
        }
        LoweredLogicStatement::For {
            init,
            condition,
            step,
            body,
        } => {
            execute_assignment_expression(init, instance, scope, eval_context, env);
            let mut iteration_count = 0usize;
            let mut condition_value = evaluate_with_diagnostics(
                condition,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            );
            if env_has_pending_scene_change(env) {
                // # ponytail: a suspending loop condition replays the whole
                // loop from scratch on resume, re-running earlier iterations;
                // a resumption stack is not worth it while no sample hits it.
                return None;
            }
            while is_truthy(condition_value) {
                for nested in body {
                    if let Some(value) = apply_runtime_statement(
                        nested,
                        instance,
                        instance_index,
                        scope,
                        destroy_event_entries,
                        eval_context,
                        env,
                    ) {
                        return Some(value);
                    }
                    if env_has_pending_scene_change(env) {
                        break;
                    }
                }
                if env_has_pending_scene_change(env) {
                    break;
                }
                execute_assignment_expression(step, instance, scope, eval_context, env);
                condition_value = evaluate_with_diagnostics(
                    condition,
                    Some(instance),
                    Some(scope),
                    eval_context,
                    env,
                    instance,
                );
                if env_has_pending_scene_change(env) {
                    return None;
                }
                iteration_count += 1;
                if iteration_count >= 10_000 {
                    record_host_diagnostic(
                        env.host,
                        env.diagnostics,
                        iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                        "runtime-for-iteration-limit",
                        format!(
                            "{} iteration_limit=10000",
                            trace_message(&env.trace, instance)
                        ),
                    );
                    break;
                }
            }
        }
        LoweredLogicStatement::Repeat { count, body } => {
            let repeat_count = evaluate_with_diagnostics(
                count,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
            .and_then(|value| as_number(&value))
            .filter(|value| value.is_finite() && *value > 0.0)
            .map(|value| value.floor() as usize)
            .unwrap_or(0);
            if env_has_pending_scene_change(env) {
                return None;
            }
            let capped_count = repeat_count.min(10_000);
            for _ in 0..capped_count {
                for nested in body {
                    if let Some(value) = apply_runtime_statement(
                        nested,
                        instance,
                        instance_index,
                        scope,
                        destroy_event_entries,
                        eval_context,
                        env,
                    ) {
                        return Some(value);
                    }
                    if env_has_pending_scene_change(env) {
                        break;
                    }
                }
                if env_has_pending_scene_change(env) {
                    break;
                }
            }
            if repeat_count > capped_count {
                record_host_diagnostic(
                    env.host,
                    env.diagnostics,
                    iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                    "runtime-repeat-iteration-limit",
                    format!(
                        "{} iteration_limit=10000",
                        trace_message(&env.trace, instance)
                    ),
                );
            }
        }
        LoweredLogicStatement::While { condition, body } => {
            let mut iteration_count = 0usize;
            let mut condition_value = evaluate_with_diagnostics(
                condition,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            );
            if env_has_pending_scene_change(env) {
                // # ponytail: a suspending loop condition replays the whole
                // loop from scratch on resume, re-running earlier iterations;
                // a resumption stack is not worth it while no sample hits it.
                return None;
            }
            while is_truthy(condition_value) {
                for nested in body {
                    if let Some(value) = apply_runtime_statement(
                        nested,
                        instance,
                        instance_index,
                        scope,
                        destroy_event_entries,
                        eval_context,
                        env,
                    ) {
                        return Some(value);
                    }
                    if env_has_pending_scene_change(env) {
                        break;
                    }
                }
                if env_has_pending_scene_change(env) {
                    break;
                }
                iteration_count += 1;
                if iteration_count >= 10_000 {
                    record_host_diagnostic(
                        env.host,
                        env.diagnostics,
                        iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                        "runtime-while-iteration-limit",
                        format!(
                            "{} iteration_limit=10000",
                            trace_message(&env.trace, instance)
                        ),
                    );
                    break;
                }
                condition_value = evaluate_with_diagnostics(
                    condition,
                    Some(instance),
                    Some(scope),
                    eval_context,
                    env,
                    instance,
                );
                if env_has_pending_scene_change(env) {
                    return None;
                }
            }
        }
        _ => {
            record_unsupported_statement(env, statement, instance);
        }
    }
    None
}

fn dispatch_runtime_dialog<H: RuntimeHost>(
    env: &mut RuntimeStatementEnvironment<'_, H>,
    kind: RuntimeDialogKind,
    text: String,
    instance: &RuntimeInstance,
) -> Option<RuntimeDialogAnswer> {
    let site = format!("{}:{}", env.trace.block_id, text);

    if let Some(request) = env.pending_dialog.as_ref() {
        if request.site != site || request.kind != kind || request.text != text {
            return None;
        }
        let Some(answer) = env.dialog_response.take() else {
            return None;
        };
        let request_text = request.text.clone();
        *env.pending_dialog = None;
        record_host_diagnostic(
            env.host,
            env.diagnostics,
            iwm_runtime_host::RuntimeDiagnosticLevel::Info,
            "runtime-dialog-answered",
            format!(
                "{} kind={:?} answer={:?} text={}",
                trace_message(&env.trace, instance),
                kind,
                answer,
                request_text
            ),
        );
        return Some(answer);
    }

    *env.pending_dialog = Some(RuntimeDialogRequest {
        kind,
        text: text.clone(),
        site,
    });
    record_host_diagnostic(
        env.host,
        env.diagnostics,
        iwm_runtime_host::RuntimeDiagnosticLevel::Info,
        "runtime-dialog-requested",
        format!(
            "{} kind={:?} text={}",
            trace_message(&env.trace, instance),
            kind,
            text
        ),
    );
    None
}

fn runtime_event_selector_label(selector: Option<&RuntimeEventSelector>) -> &'static str {
    match selector {
        Some(RuntimeEventSelector::Collision { .. }) => "collision",
        Some(RuntimeEventSelector::OtherOutside) => "other:outside",
        Some(RuntimeEventSelector::OtherBoundary) => "other:boundary",
        Some(RuntimeEventSelector::Step) => "step",
        Some(RuntimeEventSelector::StepBegin) => "step:begin",
        Some(RuntimeEventSelector::StepEnd) => "step:end",
        Some(RuntimeEventSelector::Alarm(_)) => "alarm",
        _ => "other",
    }
}

fn kill_player_is_shadowed_by_solid(
    event_selector: Option<&RuntimeEventSelector>,
    instance: &RuntimeInstance,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> bool {
    let Some(context) = eval_context else {
        return false;
    };
    let Some(event_selector) = event_selector else {
        return false;
    };
    if !instance.player_candidate
        || !matches!(
            event_selector,
            RuntimeEventSelector::Collision { .. }
                | RuntimeEventSelector::OtherOutside
                | RuntimeEventSelector::OtherBoundary
        )
    {
        return false;
    }

    let hazards = match event_selector {
        RuntimeEventSelector::Collision { .. } => context
            .other_instance()
            .filter(|other| other.hazard)
            .map(|hazard| vec![hazard.clone()]),
        RuntimeEventSelector::OtherOutside | RuntimeEventSelector::OtherBoundary => Some(
            context
                .room_instances_iter()
                .filter(|(_, other)| other.is_active() && other.hazard)
                .map(|(_, other)| other.clone())
                .collect::<Vec<_>>(),
        ),
        _ => None,
    };
    let Some(hazards) = hazards.filter(|hazards| {
        !hazards.is_empty()
            && collides_at(
                instance,
                instance.x,
                instance.y,
                hazards,
                Some(instance.runtime_id),
            )
    }) else {
        return false;
    };
    let solids = context
        .room_instances_iter()
        .filter(|(_, other)| other.is_active() && other.solid)
        .map(|(_, other)| other.clone())
        .collect::<Vec<_>>();
    crate::movement::final_solid_contact_shadows_hazard(instance, &hazards, &solids)
}

#[expect(
    clippy::too_many_arguments,
    reason = "shared runtime statement context"
)]
fn execute_runtime_script<H: RuntimeHost>(
    name: &str,
    args: &[LoweredLogicExpr],
    instance: &mut RuntimeInstance,
    instance_index: usize,
    caller_scope: &RuntimeExecutionScope,
    destroy_event_entries: &HashMap<usize, Vec<LoweredLogicEntry>>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> Option<RuntimeValue> {
    let entry = env.script_entries.get(name)?.clone();
    let values = args
        .iter()
        .map(|arg| {
            evaluate_with_diagnostics(
                arg,
                Some(instance),
                Some(caller_scope),
                eval_context,
                env,
                instance,
            )
            .unwrap_or(RuntimeValue::Number(0.0))
        })
        .collect::<Vec<_>>();
    let mut script_scope = RuntimeExecutionScope::default();
    script_scope.bind("argument_count", RuntimeValue::Number(values.len() as f64));
    for index in 0..16 {
        script_scope.bind(
            format!("argument{index}"),
            values
                .get(index)
                .cloned()
                .unwrap_or(RuntimeValue::Number(0.0)),
        );
    }

    let previous_trace = env.trace.clone();
    env.trace.block_id.clone_from(&entry.block_id);
    env.trace.event_tag = "script".into();
    let mut result = RuntimeValue::Number(0.0);
    for nested in &entry.statements {
        if let Some(value) = apply_runtime_statement(
            nested,
            instance,
            instance_index,
            &mut script_scope,
            destroy_event_entries,
            eval_context,
            env,
        ) {
            result = value;
            break;
        }
    }
    env.trace = previous_trace;
    Some(result)
}

/// GM8 file mode for the `file_text_open_*` family, or `None` for other names.
fn file_text_open_mode(name: &str) -> Option<i32> {
    match name {
        "file_text_open_read" => Some(0),
        "file_text_open_write" => Some(1),
        "file_text_open_append" => Some(2),
        _ => None,
    }
}

/// Bound on `execute_file` / `execute_string` nesting.
///
/// The source these run comes from the save store, which the runtime does not
/// author, so a save that re-executes itself must not blow the stack.
const MAX_EXECUTE_SOURCE_DEPTH: u32 = 8;

/// Runs `execute_file(path)` / `execute_string(source)`.
///
/// GM8 executes the source as an anonymous script: `self` stays the calling
/// instance, so bare assignments land on the caller, while `player.x = ...`
/// routes through the normal member-assignment path. A missing file is a no-op,
/// matching GM8.
#[expect(
    clippy::too_many_arguments,
    reason = "shared runtime statement context"
)]
fn execute_runtime_source<H: RuntimeHost>(
    name: &str,
    args: &[LoweredLogicExpr],
    instance: &mut RuntimeInstance,
    instance_index: usize,
    caller_scope: &RuntimeExecutionScope,
    destroy_event_entries: &HashMap<usize, Vec<LoweredLogicEntry>>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> Option<()> {
    let argument = args.first().and_then(|arg| {
        evaluate_with_diagnostics(
            arg,
            Some(instance),
            Some(caller_scope),
            eval_context,
            env,
            instance,
        )
    })?;
    let argument = runtime_value_to_string_text(&argument);

    let (label, source) = if name == "execute_string" {
        ("<string>".to_string(), argument)
    } else {
        let Ok(bytes) = env.host.read(Path::new(&argument)) else {
            return None;
        };
        (argument, String::from_utf8_lossy(&bytes).into_owned())
    };

    if *env.execute_source_depth >= MAX_EXECUTE_SOURCE_DEPTH {
        record_host_diagnostic(
            env.host,
            env.diagnostics,
            iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
            "runtime-execute-source-depth-limit",
            format!(
                "{} function={} source={}",
                trace_message(&env.trace, instance),
                name,
                label
            ),
        );
        return None;
    }

    let statements = iwm_gml_lowering::lower_source(&source);
    record_host_diagnostic(
        env.host,
        env.diagnostics,
        iwm_runtime_host::RuntimeDiagnosticLevel::Info,
        "runtime-execute-source",
        format!(
            "{} function={} source={} statements={}",
            trace_message(&env.trace, instance),
            name,
            label,
            statements.len()
        ),
    );

    let previous_trace = env.trace.clone();
    env.trace.block_id = format!("{name}:{label}");
    env.trace.event_tag = "execute-source".into();
    *env.execute_source_depth += 1;

    let mut source_scope = RuntimeExecutionScope::default();
    for statement in &statements {
        if apply_runtime_statement(
            statement,
            instance,
            instance_index,
            &mut source_scope,
            destroy_event_entries,
            eval_context,
            env,
        )
        .is_some()
        {
            break;
        }
    }

    *env.execute_source_depth = env.execute_source_depth.saturating_sub(1);
    env.trace = previous_trace;
    Some(())
}

fn evaluate_path_start_args<'a, H: RuntimeHost>(
    args: &[LoweredLogicExpr],
    instance: &RuntimeInstance,
    scope: &RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'a, H>,
) -> Option<(iwm_runtime_model::PathResource, f64, i32, bool)> {
    let path = args
        .first()
        .and_then(|expr| {
            evaluate_with_diagnostics(
                expr,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| runtime_value_to_path_id(&value, env.path_ids_by_name))
        .and_then(|path_id| env.paths.iter().find(|path| path.id == path_id))
        .cloned()?;
    let speed = args
        .get(1)
        .and_then(|arg| {
            evaluate_with_diagnostics(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))?;
    let end_action = args
        .get(2)
        .and_then(|arg| {
            evaluate_with_diagnostics(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))?
        .round() as i32;
    let absolute = args
        .get(3)
        .and_then(|arg| {
            evaluate_with_diagnostics(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .is_some_and(|value| is_truthy(Some(value)));
    Some((path, speed, end_action, absolute))
}

fn dispatch_draw_text<H: RuntimeHost>(
    args: &[LoweredLogicExpr],
    instance: &RuntimeInstance,
    scope: &mut RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    let Some(x) = args
        .first()
        .and_then(|arg| {
            evaluate_runtime_expr(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))
    else {
        return;
    };
    let Some(y) = args
        .get(1)
        .and_then(|arg| {
            evaluate_runtime_expr(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))
    else {
        return;
    };
    let Some(text) = args
        .get(2)
        .and_then(|arg| {
            evaluate_runtime_expr(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .map(|value| runtime_value_to_string_text(&value))
    else {
        return;
    };
    if let Some(draw) = env.draw.as_deref_mut() {
        draw.commands.push(RuntimeDrawCommand::DrawText {
            text,
            x: x.round() as i32,
            y: y.round() as i32,
            size: draw.size,
            font_name: draw.font_name.clone(),
            font_bold: draw.font_bold,
            font_italic: draw.font_italic,
            colour: draw.colour,
            align: draw.align.clone(),
        });
    }
}

fn dispatch_draw_rectangle<H: RuntimeHost>(
    args: &[LoweredLogicExpr],
    instance: &RuntimeInstance,
    scope: &mut RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    let [Some(x1), Some(y1), Some(x2), Some(y2)] = std::array::from_fn(|index| {
        args.get(index)
            .and_then(|arg| {
                evaluate_runtime_expr(
                    arg,
                    Some(instance),
                    Some(scope),
                    eval_context,
                    env,
                    instance,
                )
            })
            .and_then(|value| as_number(&value))
    }) else {
        return;
    };
    let Some(outline) = args.get(4).and_then(|arg| {
        evaluate_runtime_expr(
            arg,
            Some(instance),
            Some(scope),
            eval_context,
            env,
            instance,
        )
    }) else {
        return;
    };
    if is_truthy(Some(outline)) {
        record_unsupported_function(env, "draw_rectangle:outline", instance);
        return;
    }

    let (x1, x2) = (x1.round() as i32, x2.round() as i32);
    let (y1, y2) = (y1.round() as i32, y2.round() as i32);
    if let Some(draw) = env.draw.as_deref_mut() {
        draw.commands.push(RuntimeDrawCommand::FillRect {
            x: x1.min(x2),
            y: y1.min(y2),
            width: x1.abs_diff(x2),
            height: y1.abs_diff(y2),
            colour: draw.colour,
        });
    }
}

fn dispatch_draw_sprite<H: RuntimeHost>(
    args: &[LoweredLogicExpr],
    instance: &RuntimeInstance,
    scope: &mut RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    let Some(sprite_id) = args
        .first()
        .and_then(|arg| draw_sprite_id_arg(arg, instance, scope, eval_context, env))
    else {
        return;
    };
    let frame_index = args
        .get(1)
        .and_then(|arg| {
            evaluate_runtime_expr(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))
        .filter(|value| value.is_finite() && *value >= 0.0)
        .map(|value| value.floor() as usize)
        .unwrap_or(0);
    let Some(x) = args
        .get(2)
        .and_then(|arg| {
            evaluate_runtime_expr(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))
    else {
        return;
    };
    let Some(y) = args
        .get(3)
        .and_then(|arg| {
            evaluate_runtime_expr(
                arg,
                Some(instance),
                Some(scope),
                eval_context,
                env,
                instance,
            )
        })
        .and_then(|value| as_number(&value))
    else {
        return;
    };
    let sprite = env
        .sprite_index
        .get(&sprite_id)
        .and_then(|index| env.sprites.get(*index));
    if let Some(draw) = env.draw.as_deref_mut() {
        draw.commands.push(RuntimeDrawCommand::DrawSprite {
            sprite_id,
            frame_index,
            x: x.round() as i32,
            y: y.round() as i32,
            origin_x: sprite.map(|sprite| sprite.origin_x).unwrap_or(0),
            origin_y: sprite.map(|sprite| sprite.origin_y).unwrap_or(0),
            xscale: 1.0,
            yscale: 1.0,
            alpha: 1.0,
            angle_degrees: 0.0,
        });
    }
}

fn draw_colour_arg(expr: &LoweredLogicExpr) -> Option<Rgba8> {
    let name = match expr {
        LoweredLogicExpr::Identifier(name) | LoweredLogicExpr::LiteralText(name) => {
            name.to_ascii_lowercase()
        }
        LoweredLogicExpr::LiteralNumber(number) if number.is_finite() => {
            return Some(gm_colour_number_to_rgba(*number as u32));
        }
        _ => return None,
    };
    Some(match name.as_str() {
        "c_black" => rgba(0, 0, 0),
        "c_white" => rgba(255, 255, 255),
        "c_red" => rgba(255, 0, 0),
        "c_green" => rgba(0, 128, 0),
        "c_blue" => rgba(0, 0, 255),
        "c_yellow" => rgba(255, 255, 0),
        "c_gray" | "c_grey" => rgba(128, 128, 128),
        "c_ltgray" | "c_ltgrey" => rgba(192, 192, 192),
        "c_dkgray" | "c_dkgrey" => rgba(64, 64, 64),
        _ => return None,
    })
}

fn draw_align_arg(expr: &LoweredLogicExpr) -> Option<String> {
    let name = match expr {
        LoweredLogicExpr::Identifier(name) | LoweredLogicExpr::LiteralText(name) => {
            name.to_ascii_lowercase()
        }
        _ => return None,
    };
    match name.as_str() {
        "fa_left" => Some("left".into()),
        "fa_center" => Some("center".into()),
        "fa_right" => Some("right".into()),
        _ => None,
    }
}

fn draw_font_arg<H: RuntimeHost>(
    expr: &LoweredLogicExpr,
    env: &RuntimeStatementEnvironment<'_, H>,
) -> Option<DrawFont> {
    if let LoweredLogicExpr::Identifier(name) | LoweredLogicExpr::LiteralText(name) = expr {
        if let Some(font) = env
            .font_index_by_name
            .get(&name.to_ascii_lowercase())
            .and_then(|index| env.fonts.get(*index))
        {
            return Some(DrawFont {
                name: Some(font.name.clone()),
                size: font.size,
                bold: font.bold,
                italic: font.italic,
            });
        }
    }

    draw_font_size_arg(expr).map(|size| DrawFont {
        name: None,
        size,
        bold: false,
        italic: false,
    })
}

fn draw_font_size_arg(expr: &LoweredLogicExpr) -> Option<u32> {
    match expr {
        LoweredLogicExpr::Identifier(name) | LoweredLogicExpr::LiteralText(name) => name
            .chars()
            .filter(|ch| ch.is_ascii_digit())
            .collect::<String>()
            .parse::<u32>()
            .ok()
            .filter(|size| *size > 0),
        LoweredLogicExpr::LiteralNumber(number) if number.is_finite() && *number > 0.0 => {
            Some(number.round() as u32)
        }
        _ => None,
    }
}

fn draw_sprite_id_arg<H: RuntimeHost>(
    expr: &LoweredLogicExpr,
    instance: &RuntimeInstance,
    scope: &mut RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> Option<usize> {
    match expr {
        LoweredLogicExpr::Identifier(name) | LoweredLogicExpr::LiteralText(name) => env
            .sprite_ids_by_name
            .get(&name.to_ascii_lowercase())
            .copied(),
        LoweredLogicExpr::LiteralNumber(number) if number.is_finite() && *number >= 0.0 => {
            Some(number.round() as usize)
        }
        _ => evaluate_runtime_expr(
            expr,
            Some(instance),
            Some(scope),
            eval_context,
            env,
            instance,
        )
        .and_then(|value| as_number(&value))
        .filter(|value| value.is_finite() && *value >= 0.0)
        .map(|value| value.round() as usize),
    }
}

pub(crate) fn gm_colour_number_to_rgba(value: u32) -> Rgba8 {
    rgba(
        (value & 0xff) as u8,
        ((value >> 8) & 0xff) as u8,
        ((value >> 16) & 0xff) as u8,
    )
}

fn rgba(r: u8, g: u8, b: u8) -> Rgba8 {
    Rgba8 { r, g, b, a: 255 }
}

fn dispatch_event_inherited<H: RuntimeHost>(
    instance: &mut RuntimeInstance,
    instance_index: usize,
    scope: &mut RuntimeExecutionScope,
    destroy_event_entries: &HashMap<usize, Vec<LoweredLogicEntry>>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    let Some(owner_object_id) = env.event_owner_id else {
        return;
    };
    let Some(selector) = env.event_selector.clone() else {
        return;
    };
    let Some((inherited_owner_id, block_id)) =
        inherited_event_block_id(env.objects, owner_object_id, &selector)
    else {
        return;
    };
    let Some(entry) = env
        .lowered_entries
        .iter()
        .find(|entry| entry.block_id == block_id)
        .cloned()
    else {
        return;
    };

    let previous_owner_id = env.event_owner_id;
    let previous_trace = env.trace.clone();
    env.event_owner_id = Some(inherited_owner_id);
    env.trace.block_id.clone_from(&entry.block_id);

    for nested in &entry.statements {
        apply_runtime_statement(
            nested,
            instance,
            instance_index,
            scope,
            destroy_event_entries,
            eval_context,
            env,
        );
    }

    env.trace = previous_trace;
    env.event_owner_id = previous_owner_id;
}

fn execute_assignment_expression<H: RuntimeHost>(
    expr: &LoweredLogicExpr,
    instance: &mut RuntimeInstance,
    scope: &mut RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    if let LoweredLogicExpr::BinaryExpr { op, left, right } = expr {
        if op == "=" {
            if let Some(key) =
                assignable_key(left, Some(instance), env.globals, Some(scope), eval_context)
            {
                if let Some(value) = evaluate_with_diagnostics(
                    right,
                    Some(instance),
                    Some(scope),
                    eval_context,
                    env,
                    instance,
                ) {
                    assign_runtime_value_or_room_transition(
                        left,
                        key,
                        value,
                        instance,
                        scope,
                        eval_context,
                        env,
                    );
                }
            }
        }
    }
}

pub(super) fn evaluate_with_diagnostics<H: RuntimeHost>(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
    trace_instance: &RuntimeInstance,
) -> Option<RuntimeValue> {
    let value = evaluate_runtime_expr(expr, instance, scope, eval_context, env, trace_instance);
    if value.is_none() && !env_has_pending_scene_change(env) {
        record_unsupported_expr_functions(env, expr, trace_instance);
    }
    value
}

fn evaluate_runtime_expr<H: RuntimeHost>(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
    trace_instance: &RuntimeInstance,
) -> Option<RuntimeValue> {
    if let LoweredLogicExpr::Identifier(name) = expr {
        if name.eq_ignore_ascii_case("working_directory") {
            return Some(RuntimeValue::Text(String::new()));
        }
        if name.eq_ignore_ascii_case("room_speed")
            && !scope.map(|scope| scope.is_local_key(name)).unwrap_or(false)
        {
            return Some(RuntimeValue::Number(*env.room_speed as f64));
        }
    }
    if let LoweredLogicExpr::UnaryExpr { op, child } = expr {
        let value =
            evaluate_runtime_expr(child, instance, scope, eval_context, env, trace_instance)?;
        return match op.as_str() {
            "-" => Some(RuntimeValue::Number(-as_number(&value)?)),
            "+" => Some(RuntimeValue::Number(as_number(&value)?)),
            "!" => Some(RuntimeValue::Bool(!is_truthy(Some(value)))),
            _ => None,
        };
    }
    if let LoweredLogicExpr::BinaryExpr { op, left, right } = expr {
        // GML short-circuits boolean expressions before evaluating later operands.
        if op == "&&" {
            let left =
                evaluate_runtime_expr(left, instance, scope, eval_context, env, trace_instance)?;
            if !is_truthy(Some(left)) {
                return Some(RuntimeValue::Bool(false));
            }
            let right =
                evaluate_runtime_expr(right, instance, scope, eval_context, env, trace_instance)?;
            return Some(RuntimeValue::Bool(is_truthy(Some(right))));
        }
        if op == "||" {
            let left =
                evaluate_runtime_expr(left, instance, scope, eval_context, env, trace_instance)?;
            if is_truthy(Some(left)) {
                return Some(RuntimeValue::Bool(true));
            }
            let right =
                evaluate_runtime_expr(right, instance, scope, eval_context, env, trace_instance)?;
            return Some(RuntimeValue::Bool(is_truthy(Some(right))));
        }
        let left = evaluate_runtime_binary_operand(
            left,
            instance,
            scope,
            eval_context,
            env,
            trace_instance,
        )?;
        let right = evaluate_runtime_binary_operand(
            right,
            instance,
            scope,
            eval_context,
            env,
            trace_instance,
        )?;
        return eval_runtime_binary_expr(op, &left, &right);
    }
    if let LoweredLogicExpr::Call { name, args } = expr {
        if let Some(scope) = scope {
            if let Some(value) =
                dispatch_legacy_audio_call(env, name, args, trace_instance, scope, eval_context)
            {
                return Some(value);
            }
        }
        if matches!(name.as_str(), "string_width" | "string_height") {
            let text = args
                .first()
                .and_then(|arg| {
                    evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
                })
                .map(|value| runtime_value_to_string_text(&value))?;
            let (width, height) = runtime_text_dimensions(&text, env);
            return Some(RuntimeValue::Number(if name == "string_width" {
                width
            } else {
                height
            }));
        }
        if name == "string" {
            let value = args.first().and_then(|arg| {
                evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
            })?;
            return Some(RuntimeValue::Text(runtime_value_to_string_text(&value)));
        }
        if name == "show_question" {
            let text = args
                .first()
                .and_then(|arg| {
                    evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
                })
                .map(|value| runtime_value_to_string_text(&value))?;
            let answer =
                dispatch_runtime_dialog(env, RuntimeDialogKind::Question, text, trace_instance)?;
            return Some(RuntimeValue::Bool(matches!(
                answer,
                RuntimeDialogAnswer::Yes
            )));
        }
        match name.as_str() {
            "instance_number" => {
                if let Some(scratch) = env.object_query_scratch.as_deref_mut() {
                    return evaluate_instance_number_with_scratch(args, eval_context, scratch);
                }
            }
            "distance_to_object" => {
                if let Some(scratch) = env.object_query_scratch.as_deref_mut() {
                    return evaluate_distance_to_object_with_scratch(
                        args,
                        instance,
                        eval_context,
                        scratch,
                    );
                }
            }
            "collision_line" => {
                if let Some(scratch) = env.object_query_scratch.as_deref_mut() {
                    return evaluate_collision_line_with_scratch(
                        args,
                        instance,
                        env.globals,
                        scope,
                        eval_context,
                        scratch,
                    );
                }
            }
            "collision_rectangle" => {
                if let Some(scratch) = env.object_query_scratch.as_deref_mut() {
                    return evaluate_collision_rectangle_with_scratch(
                        args,
                        instance,
                        env.globals,
                        scope,
                        eval_context,
                        scratch,
                    );
                }
            }
            _ => {}
        }
        if name == "instance_create" {
            let instance = instance?;
            let scope = scope?;
            return runtime_instance_create_request(
                args,
                instance,
                env.globals,
                scope,
                eval_context,
                env.room_instance_creates.len(),
            )
            .map(|create| {
                let instance_id = create.instance_id;
                env.room_instance_creates.push(create);
                RuntimeValue::Number(instance_id as f64)
            });
        }
        if name == "sound_isplaying" {
            let sound_id = args.first().and_then(|arg| {
                resolve_runtime_sound_id(
                    arg,
                    trace_instance,
                    scope,
                    eval_context,
                    env.globals,
                    env.sound_index,
                    env.zero_uninitialized_vars,
                )
            })?;
            return env
                .host
                .is_sound_playing(sound_id)
                .ok()
                .map(RuntimeValue::Bool);
        }
        if name == "keyboard_get_numlock" {
            return Some(RuntimeValue::Bool(env.host.keyboard_numlock()));
        }
        if name == "file_exists" {
            let path = args.first().and_then(|arg| {
                evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
            })?;
            let RuntimeValue::Text(path) = path else {
                return None;
            };
            return Some(RuntimeValue::Bool(env.host.read(Path::new(&path)).is_ok()));
        }
        if name == "file_bin_open" {
            let path = args.first().and_then(|arg| {
                evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
            })?;
            let RuntimeValue::Text(path) = path else {
                return None;
            };
            let mode = args
                .get(1)
                .and_then(|arg| {
                    evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
                })
                .and_then(|value| as_number(&value))
                .map(|value| value.round() as i32)
                .unwrap_or(0);
            let handle = env.binary_files.open(&*env.host, path, mode);
            return Some(RuntimeValue::Number(handle as f64));
        }
        if name == "file_bin_read_byte" {
            let handle = args
                .first()
                .and_then(|arg| {
                    evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
                })
                .and_then(|value| runtime_value_to_i32(&value))?;
            let byte = env.binary_files.read_byte(handle);
            return Some(RuntimeValue::Number(byte as f64));
        }
        if let Some(mode) = file_text_open_mode(name) {
            let path = args.first().and_then(|arg| {
                evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
            })?;
            let RuntimeValue::Text(path) = path else {
                return None;
            };
            let handle = env.text_files.open(&*env.host, path, mode);
            return Some(RuntimeValue::Number(handle as f64));
        }
        if matches!(
            name.as_str(),
            "file_text_read_string" | "file_text_read_real" | "file_text_eof" | "file_text_eoln"
        ) {
            let handle = args
                .first()
                .and_then(|arg| {
                    evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
                })
                .and_then(|value| runtime_value_to_i32(&value))?;
            return Some(match name.as_str() {
                "file_text_read_string" => RuntimeValue::Text(env.text_files.read_string(handle)),
                "file_text_read_real" => RuntimeValue::Number(env.text_files.read_real(handle)),
                "file_text_eof" => RuntimeValue::Bool(env.text_files.eof(handle)),
                _ => RuntimeValue::Bool(env.text_files.eoln(handle)),
            });
        }
        if name == "room_get_name" {
            let room_id = args
                .first()
                .and_then(|arg| {
                    evaluate_runtime_expr(arg, instance, scope, eval_context, env, trace_instance)
                })
                .and_then(|value| runtime_value_to_room_id(&value))?;
            return env
                .rooms
                .iter()
                .find(|room| room.id == room_id)
                .map(|room| RuntimeValue::Text(room.name.clone()));
        }
        if env.script_entries.contains_key(name) {
            let mut instance = instance?.clone();
            let instance_index = instance.runtime_id;
            return execute_runtime_script(
                name,
                args,
                &mut instance,
                instance_index,
                scope?,
                &HashMap::new(),
                eval_context,
                env,
            );
        }
    }
    if let Some((target, member)) =
        instance_member_access(expr, instance, env.globals, scope, eval_context)
    {
        if let Some(value) = pending_create_member_value_by_object_target(
            env.room_instance_creates,
            target,
            &member,
            scope,
            eval_context,
        ) {
            return Some(value);
        }
        if let Some(RuntimeValue::Number(instance_ref)) =
            evaluate_runtime_expr(target, instance, scope, eval_context, env, trace_instance)
        {
            if let Some(value) =
                pending_create_member_value(env.room_instance_creates, instance_ref, &member)
            {
                return Some(value);
            }
        }
    }

    evaluate_expr_with_resource_constants(
        expr,
        instance,
        env.globals,
        scope,
        eval_context,
        env.sprite_ids_by_name,
        env.sound_index,
        env.path_ids_by_name,
    )
    .or_else(|| {
        (env.zero_uninitialized_vars
            && matches!(
                expr,
                LoweredLogicExpr::Identifier(_)
                    | LoweredLogicExpr::MemberAccess { .. }
                    | LoweredLogicExpr::IndexAccess { .. }
            ))
        .then_some(RuntimeValue::Number(0.0))
    })
}

fn execute_lifecycle_event<H: RuntimeHost>(
    entries: &[LoweredLogicEntry],
    selector: RuntimeEventSelector,
    event_tag: &str,
    instance: &mut RuntimeInstance,
    instance_index: usize,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) {
    let previous_selector = env.event_selector.clone();
    let previous_owner_id = env.event_owner_id;
    let previous_trace = env.trace.clone();
    let nested_destroy_entries = HashMap::new();
    for entry in entries {
        env.event_selector = Some(selector.clone());
        env.event_owner_id = event_owner_id_for_block_id(env.objects, &entry.block_id);
        env.trace.block_id.clone_from(&entry.block_id);
        env.trace.event_tag = event_tag.into();
        let mut lifecycle_scope = RuntimeExecutionScope::default();
        for nested in &entry.statements {
            if apply_runtime_statement(
                nested,
                instance,
                instance_index,
                &mut lifecycle_scope,
                &nested_destroy_entries,
                eval_context,
                env,
            )
            .is_some()
                || env_has_pending_scene_change(env)
            {
                break;
            }
        }
        if env_has_pending_scene_change(env) {
            break;
        }
    }
    env.event_selector = previous_selector;
    env.event_owner_id = previous_owner_id;
    env.trace = previous_trace;
}

fn runtime_text_dimensions<H: RuntimeHost>(
    text: &str,
    env: &RuntimeStatementEnvironment<'_, H>,
) -> (f64, f64) {
    if text.is_empty() {
        return (0.0, 0.0);
    }
    let draw = env.draw.as_deref();
    let size = draw.map(|draw| draw.size).unwrap_or(16);
    let font = draw
        .and_then(|draw| draw.font_name.as_deref())
        .and_then(|name| env.font_index_by_name.get(&name.to_ascii_lowercase()))
        .and_then(|index| env.fonts.get(*index));
    let line_height = font
        .and_then(|font| font.glyphs.iter().map(|glyph| glyph.height).max())
        .filter(|height| *height > 0)
        .unwrap_or(size) as f64;
    let mut line_count = 1usize;
    let mut line_width = 0i32;
    let mut max_width = 0i32;
    let mut characters = text.chars().peekable();
    while let Some(mut character) = characters.next() {
        if character == '\\' && characters.peek() == Some(&'#') {
            characters.next();
            character = '#';
        } else if character == '\r' && characters.peek() == Some(&'\n') {
            characters.next();
        }
        if matches!(character, '#' | '\r' | '\n') {
            max_width = max_width.max(line_width);
            line_width = 0;
            line_count += 1;
            continue;
        }
        line_width += font
            .and_then(|font| {
                font.glyphs
                    .get(character as usize)
                    .or_else(|| font.glyphs.get(32))
            })
            .map(|glyph| glyph.advance)
            .unwrap_or_else(|| (size as f64 * 0.6).round() as i32);
    }
    (
        max_width.max(line_width) as f64,
        line_count as f64 * line_height,
    )
}

fn evaluate_runtime_binary_operand<H: RuntimeHost>(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
    trace_instance: &RuntimeInstance,
) -> Option<RuntimeValue> {
    evaluate_runtime_expr(expr, instance, scope, eval_context, env, trace_instance)
        .or_else(|| uninitialized_runtime_instance_operand(expr, instance, scope))
}

fn uninitialized_runtime_instance_operand(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
) -> Option<RuntimeValue> {
    let LoweredLogicExpr::Identifier(name) = expr else {
        return None;
    };
    if instance.is_some()
        && !name.eq_ignore_ascii_case("global")
        && !scope.map(|scope| scope.is_local_key(name)).unwrap_or(false)
    {
        Some(RuntimeValue::Number(0.0))
    } else {
        None
    }
}

fn eval_runtime_binary_expr(
    op: &str,
    left: &RuntimeValue,
    right: &RuntimeValue,
) -> Option<RuntimeValue> {
    match op {
        "+" => match (left, right) {
            (RuntimeValue::Text(_), _) | (_, RuntimeValue::Text(_)) => {
                Some(RuntimeValue::Text(format!(
                    "{}{}",
                    runtime_value_to_string_text(left),
                    runtime_value_to_string_text(right)
                )))
            }
            _ => Some(RuntimeValue::Number(as_number(left)? + as_number(right)?)),
        },
        "-" => Some(RuntimeValue::Number(as_number(left)? - as_number(right)?)),
        "*" => Some(RuntimeValue::Number(as_number(left)? * as_number(right)?)),
        "/" => Some(RuntimeValue::Number(as_number(left)? / as_number(right)?)),
        "div" => {
            let divisor = as_number(right)?;
            if divisor == 0.0 {
                return None;
            }
            Some(RuntimeValue::Number((as_number(left)? / divisor).trunc()))
        }
        "mod" => {
            let divisor = as_number(right)?;
            if divisor == 0.0 {
                return None;
            }
            Some(RuntimeValue::Number(as_number(left)? % divisor))
        }
        "==" | "=" => Some(RuntimeValue::Bool(runtime_values_equal(left, right))),
        "!=" => Some(RuntimeValue::Bool(!runtime_values_equal(left, right))),
        ">=" => Some(RuntimeValue::Bool(as_number(left)? >= as_number(right)?)),
        "<=" => Some(RuntimeValue::Bool(as_number(left)? <= as_number(right)?)),
        ">" => Some(RuntimeValue::Bool(as_number(left)? > as_number(right)?)),
        "<" => Some(RuntimeValue::Bool(as_number(left)? < as_number(right)?)),
        "&&" => Some(RuntimeValue::Bool(
            is_truthy(Some(left.clone())) && is_truthy(Some(right.clone())),
        )),
        "||" => Some(RuntimeValue::Bool(
            is_truthy(Some(left.clone())) || is_truthy(Some(right.clone())),
        )),
        _ => None,
    }
}

fn runtime_value_to_string_text(value: &RuntimeValue) -> String {
    match value {
        RuntimeValue::Number(number) if number.fract() == 0.0 => format!("{}", *number as i64),
        RuntimeValue::Number(number) => number.to_string(),
        RuntimeValue::Bool(flag) => flag.to_string(),
        RuntimeValue::Text(text) => text.clone(),
    }
}

pub(crate) fn runtime_values_equal(left: &RuntimeValue, right: &RuntimeValue) -> bool {
    match (as_number(left), as_number(right)) {
        (Some(left), Some(right)) => left == right,
        _ => left == right,
    }
}
