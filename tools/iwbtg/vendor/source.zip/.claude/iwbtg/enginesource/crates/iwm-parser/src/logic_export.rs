use crate::event_tags::normalize_event_tag;
use crate::models::{
    LogicBlock, LogicOp, ObjectDefinition, ObjectEventEntry, RoomBackgroundLayer, RoomDefinition,
    RoomInstancePlacement, RoomTilePlacement, RoomView, ScriptIrFile,
};
use gm8exe::{
    asset::{CodeAction, Object, PascalString, Room, Script},
    AssetList,
};

/// Decodes GM8 PascalString bytes using a strict gate: valid UTF-8 wins (most
/// fangames are pure ASCII); otherwise only accept CP932 when every byte
/// decodes without error (kana/kanji patterns are unambiguous); otherwise fall
/// back to CP1252, whose replacement handling never fails. Without the strict
/// CP932 gate, CP1252 bytes like 0x92/0x93 would pair up as fake kanji.
pub(crate) fn decode_gm8_text(value: &PascalString) -> String {
    if let Ok(text) = std::str::from_utf8(&value.0) {
        return text.to_owned();
    }
    let (text, encoding, had_errors) = encoding_rs::SHIFT_JIS.decode(&value.0);
    if !had_errors {
        let _ = encoding;
        return text.into_owned();
    }
    let (text, _encoding, _errors) = encoding_rs::WINDOWS_1252.decode(&value.0);
    text.into_owned()
}

pub fn export_rooms_and_logic(
    rooms: &AssetList<Room>,
    objects: &AssetList<Object>,
    scripts: &AssetList<Script>,
) -> (Vec<RoomDefinition>, Vec<ObjectDefinition>, ScriptIrFile) {
    let mut blocks = Vec::new();

    let mut room_defs: Vec<RoomDefinition> = rooms
        .iter()
        .enumerate()
        .filter_map(|ri| ri.1.as_ref().map(|r| (ri.0, r)))
        .map(|(room_id, room)| {
            let creation_block_id = if room.creation_code.0.is_empty() {
                None
            } else {
                let id = room_creation_block_id(room_id);
                blocks.push(LogicBlock {
                    id: id.clone(),
                    name: format!("room {} creation", room.name),
                    kind: "room-creation".into(),
                    support: "source-only".into(),
                    executable_action_count: 0,
                    ops: vec![LogicOp::SourceSnippet {
                        code: decode_gm8_text(&room.creation_code),
                    }],
                });
                Some(id)
            };

            let instances: Vec<RoomInstancePlacement> = room
                .instances
                .iter()
                .map(|instance| {
                    let creation_block_id = if instance.creation_code.0.is_empty() {
                        None
                    } else {
                        let id = instance_creation_block_id(room_id, instance.id);
                        blocks.push(LogicBlock {
                            id: id.clone(),
                            name: format!("room {room_id} instance {} creation", instance.id),
                            kind: "instance-creation".into(),
                            support: "source-only".into(),
                            executable_action_count: 0,
                            ops: vec![LogicOp::SourceSnippet {
                                code: decode_gm8_text(&instance.creation_code),
                            }],
                        });
                        Some(id)
                    };

                    // Look up the object to get solid/hazard/checkpoint hints
                    let (is_solid, is_hazard, is_checkpoint) =
                        match objects.get(instance.object as usize) {
                            Some(Some(obj)) => {
                                let name_str = decode_gm8_text(&obj.name);
                                (
                                    obj.solid,
                                    detect_hazard(&name_str),
                                    detect_checkpoint(&name_str),
                                )
                            }
                            _ => (false, false, false),
                        };

                    RoomInstancePlacement {
                        instance_id: instance.id,
                        object_id: instance.object,
                        x: instance.x,
                        y: instance.y,
                        xscale: instance.xscale,
                        yscale: instance.yscale,
                        angle: instance.angle,
                        blend: instance.blend,
                        creation_block_id,
                        is_solid,
                        is_hazard,
                        is_checkpoint,
                    }
                })
                .collect();

            // Detect if room is playable (has instances with sprites that aren't decorative)
            let playable = instances
                .iter()
                .any(|i| match objects.get(i.object_id as usize) {
                    Some(Some(obj)) => {
                        let name_str = decode_gm8_text(&obj.name);
                        obj.sprite_index >= 0 && !is_decorative_object(&name_str)
                    }
                    _ => false,
                });

            RoomDefinition {
                id: room_id,
                name: decode_gm8_text(&room.name),
                width: room.width,
                height: room.height,
                speed: room.speed,
                persistent: room.persistent,
                background_colour: room.bg_colour.into(),
                clear_screen: room.clear_screen,
                backgrounds: room
                    .backgrounds
                    .iter()
                    .map(|bg| RoomBackgroundLayer {
                        visible_on_start: bg.visible_on_start,
                        is_foreground: bg.is_foreground,
                        source_bg: bg.source_bg,
                        xoffset: bg.xoffset,
                        yoffset: bg.yoffset,
                        tile_horz: bg.tile_horz,
                        tile_vert: bg.tile_vert,
                        hspeed: bg.hspeed,
                        vspeed: bg.vspeed,
                        stretch: bg.stretch,
                    })
                    .collect(),
                views_enabled: room.views_enabled,
                views: room
                    .views
                    .iter()
                    .map(|view| RoomView {
                        visible: view.visible,
                        source_x: view.source_x,
                        source_y: view.source_y,
                        source_w: view.source_w,
                        source_h: view.source_h,
                        port_x: view.port_x,
                        port_y: view.port_y,
                        port_w: view.port_w,
                        port_h: view.port_h,
                        target: view.following.target,
                        hborder: view.following.hborder,
                        vborder: view.following.vborder,
                        hspeed: view.following.hspeed,
                        vspeed: view.following.vspeed,
                    })
                    .collect(),
                tiles: room
                    .tiles
                    .iter()
                    .map(|tile| RoomTilePlacement {
                        tile_id: tile.id,
                        source_bg: tile.source_bg,
                        x: tile.x,
                        y: tile.y,
                        tile_x: tile.tile_x,
                        tile_y: tile.tile_y,
                        width: tile.width,
                        height: tile.height,
                        depth: tile.depth,
                        xscale: tile.xscale,
                        yscale: tile.yscale,
                        blend: tile.blend,
                    })
                    .collect(),
                instances,
                creation_block_id,
                playable,
                // Transition targets will be populated by analyzing room_goto actions
                transition_targets: Vec::new(),
            }
        })
        .collect();

    // Collect room transition targets from object events by object id first.
    let mut object_transition_map: std::collections::HashMap<usize, Vec<usize>> =
        std::collections::HashMap::new();
    for (object_id, object) in objects.iter().enumerate() {
        if let Some(obj) = object.as_ref() {
            let mut targets = Vec::new();
            for sub_events in &obj.events {
                for (_sub_event, actions) in sub_events {
                    for action in actions {
                        if let Some(target_room) = detect_room_goto_target(action) {
                            targets.push(target_room);
                        }
                    }
                }
            }

            if !targets.is_empty() {
                targets.sort_unstable();
                targets.dedup();
                object_transition_map.insert(object_id, targets);
            }
        }
    }

    let object_defs = objects
        .iter()
        .enumerate()
        .filter_map(|(object_id, object)| object.as_ref().map(|o| (object_id, o)))
        .map(|(object_id, object)| {
            let mut events = Vec::new();

            for (event_type, sub_events) in object.events.iter().enumerate() {
                for (sub_event, actions) in sub_events {
                    let block_id = event_block_id(object_id, event_type, *sub_event);
                    let executable_count = count_executable_actions(actions);
                    let support = if executable_count > 0 {
                        "action-list"
                    } else {
                        "source-only"
                    };

                    blocks.push(LogicBlock {
                        id: block_id.clone(),
                        name: format!("object {} event {}:{}", object.name, event_type, sub_event),
                        kind: "object-event".into(),
                        support: support.into(),
                        executable_action_count: executable_count,
                        ops: actions.iter().map(action_to_logic_op).collect(),
                    });

                    events.push(ObjectEventEntry {
                        event_type,
                        sub_event: *sub_event,
                        event_tag: normalize_event_tag(event_type, *sub_event),
                        block_id,
                        action_count: actions.len(),
                    });
                }
            }

            ObjectDefinition {
                id: object_id,
                name: decode_gm8_text(&object.name),
                sprite_index: object.sprite_index,
                parent_index: object.parent_index,
                depth: object.depth,
                persistent: object.persistent,
                visible: object.visible,
                solid: object.solid,
                mask_index: object.mask_index,
                is_hazard: detect_hazard(&decode_gm8_text(&object.name)).then_some(true),
                is_checkpoint: detect_checkpoint(&decode_gm8_text(&object.name)).then_some(true),
                is_player: detect_player(&decode_gm8_text(&object.name)),
                events,
            }
        })
        .collect();

    // Update room transition_targets based on discovered targets for the objects present in each room.
    for room in &mut room_defs.iter_mut() {
        let mut transition_targets = room
            .instances
            .iter()
            .filter_map(|instance| object_transition_map.get(&(instance.object_id as usize)))
            .flat_map(|targets| targets.iter().copied())
            .collect::<Vec<_>>();
        transition_targets.sort_unstable();
        transition_targets.dedup();
        room.transition_targets = transition_targets;
    }

    for (script_id, script) in scripts
        .iter()
        .enumerate()
        .filter_map(|(id, script)| script.as_ref().map(|script| (id, script)))
    {
        blocks.push(LogicBlock {
            id: format!("script:{script_id}"),
            name: decode_gm8_text(&script.name),
            kind: "script".into(),
            support: "source-only".into(),
            executable_action_count: 0,
            ops: vec![LogicOp::SourceSnippet {
                code: decode_gm8_text(&script.source),
            }],
        });
    }

    (
        room_defs,
        object_defs,
        ScriptIrFile {
            format: "iwm-script-ir-v1".into(),
            blocks,
        },
    )
}

/// Count how many actions in a list can be executed without GML lowering
fn count_executable_actions(actions: &[CodeAction]) -> usize {
    actions.iter().filter(|a| a.fn_code.0.is_empty()).count()
}

/// Detect if an object name suggests it's a hazard
fn detect_hazard(name: &str) -> bool {
    let name_lower = name.to_lowercase();
    let hazard_patterns = [
        "hazard", "spike", "trap", "danger", "killer", "death", "hurt", "enemy", "bad",
    ];
    hazard_patterns.iter().any(|p| name_lower.contains(p))
}

/// Detect if an object name suggests it's a checkpoint
fn detect_checkpoint(name: &str) -> bool {
    let name_lower = name.to_lowercase();
    let checkpoint_patterns = ["checkpoint", "cp", "save", "flag", "spawn", "start"];
    checkpoint_patterns.iter().any(|p| name_lower.contains(p))
}

/// Detect if an object name suggests it's player-controlled
fn detect_player(name: &str) -> bool {
    let name_lower = name.to_lowercase();
    let player_patterns = ["player", "p1", "p2", "hero", "character", "avatar"];
    player_patterns.iter().any(|p| name_lower.contains(p))
}

/// Check if an object is decorative (not part of gameplay)
fn is_decorative_object(name: &str) -> bool {
    let name_lower = name.to_lowercase();
    let decorative_patterns = ["bg_", "back", "deco", "particle", "effect"];
    decorative_patterns.iter().any(|p| name_lower.contains(p))
}

/// Try to detect room_goto target from an action
fn detect_room_goto_target(action: &CodeAction) -> Option<usize> {
    // room_goto(room) sets first arg to room index
    let fn_name_str = decode_gm8_text(&action.fn_name);
    if fn_name_str.contains("room_goto") && !action.fn_code.0.is_empty() {
        // This is source code - we'd need to parse it to get the room
        None
    } else if fn_name_str.contains("room_goto") {
        // Action call - check args
        if let Some(room_arg) = action.param_strings.first() {
            let room_arg_str = decode_gm8_text(room_arg);
            room_arg_str.parse().ok()
        } else {
            None
        }
    } else {
        None
    }
}

pub fn event_block_id(object_id: usize, event_type: usize, sub_event: u32) -> String {
    format!("object:{object_id}:event:{event_type}:{sub_event}")
}

pub fn room_creation_block_id(room_id: usize) -> String {
    format!("room:{room_id}:create")
}

pub fn instance_creation_block_id(room_id: usize, instance_id: i32) -> String {
    format!("room:{room_id}:instance:{instance_id}:create")
}

pub fn take_action_args(param_count: usize, args: [String; 8]) -> Vec<String> {
    args.into_iter().take(param_count).collect()
}

fn action_to_logic_op(action: &CodeAction) -> LogicOp {
    let args = action
        .param_strings
        .iter()
        .take(action.param_count)
        .map(decode_gm8_text)
        .collect();

    if !action.fn_code.0.is_empty() {
        return LogicOp::SourceSnippet {
            code: decode_gm8_text(&action.fn_code),
        };
    }

    LogicOp::ActionCall {
        action_id: action.id,
        lib_id: action.lib_id,
        applies_to: action.applies_to,
        is_condition: action.is_condition,
        invert_condition: action.invert_condition,
        is_relative: action.is_relative,
        fn_name: decode_gm8_text(&action.fn_name),
        fn_code: decode_gm8_text(&action.fn_code),
        args,
    }
}

#[cfg(test)]
mod decode_tests {
    use super::decode_gm8_text;
    use gm8exe::asset::PascalString;

    #[test]
    fn decodes_cp932_dialog_text() {
        // "MS ゴシック" in CP932: MS + space + go-shi--ku-kku-to.
        let bytes: Vec<u8> = "MS "
            .bytes()
            .chain([0x83, 0x53, 0x83, 0x56, 0x83, 0x62, 0x83, 0x4E])
            .collect();
        let decoded = decode_gm8_text(&PascalString(bytes.into_boxed_slice()));
        assert_eq!(decoded, "MS ゴシック");
    }

    #[test]
    fn decodes_ascii_and_utf8_text_unchanged() {
        assert_eq!(
            decode_gm8_text(&PascalString((*b"show_message").into())),
            "show_message"
        );
        // Valid UTF-8 multibyte input must not be reinterpreted as CP932.
        assert_eq!(
            decode_gm8_text(&PascalString((*"über".as_bytes()).into())),
            "über"
        );
    }

    #[test]
    fn falls_back_to_cp1252_when_cp932_decode_errors() {
        // A dangling CP932 lead byte (0x92 at end of input) always errors in
        // CP932; without the strict gate it would become U+FFFD, with the
        // gate it falls back to CP1252 = U+2018. Mid-string 0x92 followed by
        // an ASCII letter is a VALID CP932 pair, so that inherent ambiguity
        // remains (heuristic codepage detection cannot fully solve it).
        let decoded = decode_gm8_text(&PascalString(vec![b'a', 0x92].into_boxed_slice()));
        assert_eq!(decoded, "a\u{2019}");
    }
}
