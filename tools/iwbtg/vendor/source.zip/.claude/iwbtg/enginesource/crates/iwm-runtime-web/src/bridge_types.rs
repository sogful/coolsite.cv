use serde::{Deserialize, Serialize};

pub use iwm_runtime_host::{
    Rgba8 as BridgeRgba8, RuntimeDrawCommand as BridgeDrawCommand,
    RuntimeRenderFrame as BridgeFrameSnapshot,
};

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WebInputState {
    pub left: bool,
    pub right: bool,
    pub jump: bool,
    pub jump_pressed: bool,
    pub jump_released: bool,
    pub restart: bool,
    #[serde(default)]
    pub keys_held: Vec<u16>,
    #[serde(default)]
    pub keys_pressed: Vec<u16>,
    #[serde(default)]
    pub keys_released: Vec<u16>,
    #[serde(default)]
    pub mouse_x: i32,
    #[serde(default)]
    pub mouse_y: i32,
    #[serde(default)]
    pub mouse_buttons_held: Vec<u8>,
    #[serde(default)]
    pub mouse_buttons_pressed: Vec<u8>,
    #[serde(default)]
    pub mouse_buttons_released: Vec<u8>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeDialogRequest {
    pub kind: String,
    pub text: String,
    pub site: String,
}
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeJumpSnapshot {
    pub grounded: bool,
    pub active: bool,
    pub hold_frames: u32,
    pub cut_applied: bool,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgePlayerSnapshot {
    pub runtime_id: usize,
    pub instance_id: i32,
    pub object_id: usize,
    pub object_name: String,
    pub x: f64,
    pub y: f64,
    pub hspeed: f64,
    pub vspeed: f64,
    pub facing_left: bool,
    pub alive: bool,
    pub jump: BridgeJumpSnapshot,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeInputTraceSnapshot {
    pub jump_button_key: u16,
    pub jump_pressed: bool,
    pub jump_just_pressed: bool,
    pub jump_just_released: bool,
    pub active_keys: Vec<String>,
}

#[derive(Debug, Clone, Copy, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeTickPhaseSnapshot {
    pub input_diag_nanos: u64,
    pub step_events_nanos: u64,
    pub view_sync_nanos: u64,
    pub player_movement_nanos: u64,
    pub collision_events_nanos: u64,
    pub alarms_nanos: u64,
    pub keyboard_events_nanos: u64,
    pub render_submit_nanos: u64,
    pub total_nanos: u64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeCollisionParticipantTrace {
    pub runtime_id: usize,
    pub instance_id: i32,
    pub object_id: usize,
    pub object_name: String,
    pub x: f64,
    pub y: f64,
    pub previous_x: f64,
    pub previous_y: f64,
    pub hspeed: f64,
    pub vspeed: f64,
    pub bounds: [i32; 4],
    pub previous_bounds: [i32; 4],
    pub solid: bool,
    pub hazard: bool,
    pub has_collision_mask: bool,
    pub collision_mask_size: Option<[u32; 2]>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeCollisionTraceEntry {
    pub tick: u64,
    pub phase: String,
    pub target_object_id: usize,
    pub solid_collision: bool,
    pub contact_y: Option<i32>,
    pub event_blocks: Vec<String>,
    pub owner: BridgeCollisionParticipantTrace,
    pub other: BridgeCollisionParticipantTrace,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeDeathTraceEntry {
    pub tick: u64,
    pub room_id: usize,
    pub room_name: String,
    pub reason: String,
    pub player: BridgeCollisionParticipantTrace,
    pub hazard: Option<BridgeCollisionParticipantTrace>,
    pub collision_window: Vec<BridgeCollisionTraceEntry>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeSnapshot {
    pub status: String,
    pub tick: u64,
    pub room_id: Option<usize>,
    pub room_name: Option<String>,
    pub room_speed: Option<u32>,
    pub instance_count: usize,
    pub deaths: u64,
    pub player: Option<BridgePlayerSnapshot>,
    pub pending_dialog: Option<BridgeDialogRequest>,
    pub input_trace: BridgeInputTraceSnapshot,
    pub tick_phases: BridgeTickPhaseSnapshot,
    pub diagnostics: Vec<String>,
    pub collision_trace: Vec<BridgeCollisionTraceEntry>,
    pub death_trace: Vec<BridgeDeathTraceEntry>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BridgeStepResult {
    pub snapshot: BridgeSnapshot,
    pub frame: BridgeFrameSnapshot,
}
