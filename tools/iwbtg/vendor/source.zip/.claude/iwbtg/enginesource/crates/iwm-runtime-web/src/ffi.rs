use std::sync::{Mutex, OnceLock};

use crate::bridge_buffer::{
    decode_web_input_state_from_buffer, encode_bridge_step_result_to_buffer,
};
use crate::result_store::{
    last_result_len, read_utf8_from_ptr, store_error_result, store_json_result, store_result_bytes,
};
use crate::{WebInputState, WebRuntimeHost};
use iwm_runtime_host::RuntimeDialogAnswer;

fn parse_web_input_state(pointer: *const u8, len: usize) -> Result<WebInputState, String> {
    let input_json = read_utf8_from_ptr(pointer, len)?;
    serde_json::from_str::<WebInputState>(&input_json).map_err(|error| error.to_string())
}

fn parse_web_input_state_buffer(pointer: *const u8, len: usize) -> Result<WebInputState, String> {
    if pointer.is_null() {
        return Err("received null pointer for input buffer".into());
    }
    // SAFETY: The caller provides a pointer and byte length allocated in this
    // module's WASM memory. We validate non-null here and only borrow the slice.
    let bytes = unsafe { std::slice::from_raw_parts(pointer, len) };
    decode_web_input_state_from_buffer(bytes)
}

fn runtime_host() -> &'static Mutex<WebRuntimeHost> {
    static RUNTIME: OnceLock<Mutex<WebRuntimeHost>> = OnceLock::new();
    RUNTIME.get_or_init(|| Mutex::new(WebRuntimeHost::new()))
}

#[no_mangle]
pub extern "C" fn iwm_alloc(len: usize) -> *mut u8 {
    let mut bytes = Vec::<u8>::with_capacity(len);
    let pointer = bytes.as_mut_ptr();
    std::mem::forget(bytes);
    pointer
}

/// Releases a buffer allocated by [`iwm_alloc`].
///
/// # Safety
///
/// `pointer` must have been returned by [`iwm_alloc`] and `len` must be the
/// same capacity passed to that allocation.
#[no_mangle]
pub unsafe extern "C" fn iwm_free(pointer: *mut u8, len: usize) {
    if pointer.is_null() {
        return;
    }

    unsafe {
        let _ = Vec::from_raw_parts(pointer, 0, len);
    }
}

#[no_mangle]
pub extern "C" fn iwm_last_result_len() -> usize {
    last_result_len()
}

#[no_mangle]
pub extern "C" fn iwm_boot_json(pointer: *const u8, len: usize) -> usize {
    let package_json = match read_utf8_from_ptr(pointer, len) {
        Ok(value) => value,
        Err(error) => return store_error_result(error),
    };

    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.boot_from_json(&package_json) {
        Ok(snapshot) => store_json_result(&snapshot),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_set_input_json(pointer: *const u8, len: usize) -> usize {
    let input = match parse_web_input_state(pointer, len) {
        Ok(value) => value,
        Err(error) => return store_error_result(error),
    };

    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    host.set_input(input);
    match host.snapshot() {
        Some(snapshot) => store_json_result(&snapshot),
        None => store_error_result("runtime core is not booted".into()),
    }
}

#[no_mangle]
pub extern "C" fn iwm_step_json(pointer: *const u8, len: usize) -> usize {
    let input = match parse_web_input_state(pointer, len) {
        Ok(value) => value,
        Err(error) => return store_error_result(error),
    };

    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.step(input) {
        Ok(result) => store_json_result(&result),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_step_buffer(pointer: *const u8, len: usize) -> usize {
    let input = match parse_web_input_state_buffer(pointer, len) {
        Ok(value) => value,
        Err(error) => return store_error_result(error),
    };

    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host
        .step(input)
        .and_then(|result| encode_bridge_step_result_to_buffer(&result))
    {
        Ok(bytes) => store_result_bytes(bytes),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_dialog_response(answer: u32) -> usize {
    let answer = match answer {
        0 => RuntimeDialogAnswer::Accepted,
        1 => RuntimeDialogAnswer::Yes,
        2 => RuntimeDialogAnswer::No,
        _ => return store_error_result("invalid dialog answer".into()),
    };
    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.dialog_response(answer) {
        Ok(snapshot) => store_json_result(&snapshot),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_tick(frames: u32) -> usize {
    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.tick(frames) {
        Ok(snapshot) => store_json_result(&snapshot),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_reset() -> usize {
    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.reset() {
        Ok(snapshot) => store_json_result(&snapshot),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_select_room(room_id: u32) -> usize {
    let mut host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.select_room(room_id as usize) {
        Ok(snapshot) => store_json_result(&snapshot),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_snapshot_json() -> usize {
    let host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.snapshot() {
        Some(snapshot) => store_json_result(&snapshot),
        None => store_error_result("runtime core is not booted".into()),
    }
}

#[no_mangle]
pub extern "C" fn iwm_frame_json() -> usize {
    let host = runtime_host().lock().expect("runtime host mutex poisoned");
    match host.frame_snapshot() {
        Ok(frame) => store_json_result(&frame),
        Err(error) => store_error_result(error),
    }
}

#[no_mangle]
pub extern "C" fn iwm_diagnostics_json() -> usize {
    let host = runtime_host().lock().expect("runtime host mutex poisoned");
    store_json_result(&host.diagnostics())
}
