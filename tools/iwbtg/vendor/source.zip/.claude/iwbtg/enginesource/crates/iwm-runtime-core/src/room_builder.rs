use std::collections::HashMap;

use iwm_runtime_model::{ObjectDefinition, RoomDefinition, SpriteResource};

use crate::helpers::{adjusted_spawn_for_player, is_preferred_player_name};
use crate::types::{RuntimeCollisionMask, RuntimeJumpState, RuntimeRoomView};
use crate::{RuntimeCore, RuntimeCoreError, RuntimeInstance, RuntimeRoomState, RuntimeValue};

pub(crate) fn object_is_hazard(objects: &[ObjectDefinition], object_id: usize) -> bool {
    let mut current_object_id = Some(object_id);
    while let Some(id) = current_object_id {
        let Some(object) = objects.iter().find(|object| object.id == id) else {
            return false;
        };
        if let Some(is_hazard) = object.is_hazard {
            return is_hazard;
        }
        current_object_id = usize::try_from(object.parent_index).ok();
    }
    false
}

impl RuntimeCore {
    pub fn boot_default_room(&mut self) -> Result<(), RuntimeCoreError> {
        let room_id = self
            .package
            .manifest
            .default_room_id
            .or_else(|| self.package.rooms.first().map(|room| room.id))
            .ok_or(RuntimeCoreError::NoRooms)?;

        self.current_room = Some(self.build_room(room_id)?);
        self.room_needs_first_render_settle = true;
        self.status = crate::RuntimeStatus::Ready;
        Ok(())
    }

    pub(crate) fn build_room(
        &mut self,
        room_id: usize,
    ) -> Result<RuntimeRoomState, RuntimeCoreError> {
        self.build_room_with_create_visible_instances(room_id, &[])
    }

    pub(crate) fn build_room_with_create_visible_instances(
        &mut self,
        room_id: usize,
        visible_instances: &[RuntimeInstance],
    ) -> Result<RuntimeRoomState, RuntimeCoreError> {
        let (mut room_state, room) = self.build_room_layout(room_id)?;
        self.apply_create_logic_with_visible_instances(&mut room_state, &room, visible_instances);
        self.apply_room_start_logic_with_visible_instances(&mut room_state, visible_instances);
        Ok(room_state)
    }

    pub(crate) fn build_room_layout(
        &mut self,
        room_id: usize,
    ) -> Result<(RuntimeRoomState, RoomDefinition), RuntimeCoreError> {
        let room = self
            .room_index
            .get(&room_id)
            .and_then(|index| self.package.rooms.get(*index))
            .cloned()
            .ok_or(RuntimeCoreError::RoomMissing(room_id))?;

        let spawn_point = room
            .instances
            .iter()
            .find(|instance| instance.is_checkpoint)
            .or_else(|| room.instances.first())
            .map(|instance| (instance.x, instance.y));

        let instances = room
            .instances
            .iter()
            .enumerate()
            .filter_map(|(runtime_id, instance)| {
                let object = self
                    .object_index
                    .get(&(instance.object_id as usize))
                    .and_then(|index| self.package.objects.get(*index))?;
                let metrics = self.sprite_metrics(object);
                let vars = runtime_instance_vars(
                    instance.x as f64,
                    instance.y as f64,
                    instance.xscale,
                    instance.yscale,
                );
                Some(RuntimeInstance {
                    runtime_id,
                    instance_id: instance.instance_id,
                    object_id: instance.object_id as usize,
                    object_name: object.name.clone(),
                    x: instance.x as f64,
                    y: instance.y as f64,
                    previous_x: instance.x as f64,
                    previous_y: instance.y as f64,
                    hspeed: 0.0,
                    vspeed: 0.0,
                    width: metrics.width,
                    height: metrics.height,
                    origin_x: metrics.origin_x,
                    origin_y: metrics.origin_y,
                    image_xscale: instance.xscale,
                    image_yscale: instance.yscale,
                    bbox_left: metrics.bbox_left,
                    bbox_right: metrics.bbox_right,
                    bbox_top: metrics.bbox_top,
                    bbox_bottom: metrics.bbox_bottom,
                    collision_masks: metrics.collision_masks.clone(),
                    per_frame_collision_masks: metrics.per_frame_collision_masks,
                    facing_left: false,
                    visible: object.visible,
                    alive: true,
                    active: true,
                    persistent: object.persistent,
                    solid: instance.is_solid || object.solid,
                    hazard: instance.is_hazard
                        || object_is_hazard(&self.package.objects, object.id),
                    checkpoint: instance.is_checkpoint || object.is_checkpoint.unwrap_or(false),
                    player_candidate: object.is_player,
                    jump: RuntimeJumpState::default(),
                    vars,
                })
            })
            .collect::<Vec<_>>();

        let mut room_state = RuntimeRoomState {
            room_id: room.id,
            room_name: room.name.clone(),
            width: room.width,
            height: room.height,
            speed: room.speed,
            playable: room.playable,
            transition_targets: room.transition_targets.clone(),
            spawn_point,
            views_enabled: room.views_enabled,
            views: room.views.iter().map(RuntimeRoomView::from).collect(),
            instances,
        };
        if let Some((spawn_x, spawn_y)) = room_state.spawn_point {
            if let Some(player_index) = room_state.instances.iter().position(|instance| {
                instance.player_candidate
                    && instance.is_active()
                    && is_preferred_player_name(&instance.object_name)
            }) {
                let adjusted = adjusted_spawn_for_player(
                    &room_state.instances[player_index],
                    spawn_x,
                    spawn_y,
                    &room_state,
                );
                let player = &mut room_state.instances[player_index];
                player.x = adjusted.0 as f64;
                player.y = adjusted.1 as f64;
                player.previous_x = adjusted.0 as f64;
                player.previous_y = adjusted.1 as f64;
            }
        }
        Ok((room_state, room))
    }

    pub(crate) fn sprite_metrics(&self, object: &ObjectDefinition) -> RuntimeSpriteMetrics {
        sprite_metrics_for_object(object, &self.package.resources.sprites)
    }

    pub(crate) fn instantiate_runtime_object(
        &self,
        object_id: usize,
        runtime_id: usize,
        instance_id: i32,
        x: f64,
        y: f64,
    ) -> Option<RuntimeInstance> {
        let object = self
            .object_index
            .get(&object_id)
            .and_then(|index| self.package.objects.get(*index))?;
        let metrics = self.sprite_metrics(object);
        let vars = runtime_instance_vars(x, y, 1.0, 1.0);
        Some(RuntimeInstance {
            runtime_id,
            instance_id,
            object_id: object.id,
            object_name: object.name.clone(),
            x,
            y,
            previous_x: x,
            previous_y: y,
            hspeed: 0.0,
            vspeed: 0.0,
            width: metrics.width,
            height: metrics.height,
            origin_x: metrics.origin_x,
            origin_y: metrics.origin_y,
            image_xscale: 1.0,
            image_yscale: 1.0,
            bbox_left: metrics.bbox_left,
            bbox_right: metrics.bbox_right,
            bbox_top: metrics.bbox_top,
            bbox_bottom: metrics.bbox_bottom,
            collision_masks: metrics.collision_masks,
            per_frame_collision_masks: metrics.per_frame_collision_masks,
            facing_left: false,
            visible: object.visible,
            alive: true,
            active: true,
            persistent: object.persistent,
            solid: object.solid,
            hazard: object_is_hazard(&self.package.objects, object.id),
            checkpoint: object.is_checkpoint.unwrap_or(false),
            player_candidate: object.is_player,
            jump: RuntimeJumpState::default(),
            vars,
        })
    }
}

pub(crate) fn next_runtime_instance_id(instances: &[RuntimeInstance]) -> i32 {
    instances
        .iter()
        .filter_map(|instance| (instance.instance_id > 0).then_some(instance.instance_id))
        .max()
        .unwrap_or(0)
        .saturating_add(1)
}

fn runtime_instance_vars(
    x: f64,
    y: f64,
    xscale: f64,
    yscale: f64,
) -> HashMap<String, RuntimeValue> {
    HashMap::from([
        ("image_xscale".into(), RuntimeValue::Number(xscale)),
        ("image_yscale".into(), RuntimeValue::Number(yscale)),
        ("image_index".into(), RuntimeValue::Number(0.0)),
        ("image_speed".into(), RuntimeValue::Number(1.0)),
        ("timeline_index".into(), RuntimeValue::Number(-1.0)),
        ("timeline_position".into(), RuntimeValue::Number(0.0)),
        ("timeline_speed".into(), RuntimeValue::Number(1.0)),
        ("timeline_running".into(), RuntimeValue::Bool(false)),
        ("timeline_loop".into(), RuntimeValue::Bool(false)),
        ("path_index".into(), RuntimeValue::Number(-1.0)),
        ("path_position".into(), RuntimeValue::Number(0.0)),
        ("path_positionprevious".into(), RuntimeValue::Number(0.0)),
        ("path_speed".into(), RuntimeValue::Number(0.0)),
        ("path_scale".into(), RuntimeValue::Number(1.0)),
        ("path_orientation".into(), RuntimeValue::Number(0.0)),
        ("path_endaction".into(), RuntimeValue::Number(0.0)),
        ("path_xstart".into(), RuntimeValue::Number(x)),
        ("path_ystart".into(), RuntimeValue::Number(y)),
    ])
}

pub(crate) fn sprite_metrics_for_object(
    object: &ObjectDefinition,
    sprites: &[SpriteResource],
) -> RuntimeSpriteMetrics {
    let sprite_index = if object.mask_index >= 0 {
        object.mask_index
    } else {
        object.sprite_index
    };
    usize::try_from(sprite_index)
        .ok()
        .and_then(|id| sprites.iter().find(|sprite| sprite.id == id))
        .map(RuntimeSpriteMetrics::from)
        .unwrap_or_default()
}

#[derive(Debug, Clone)]
pub(crate) struct RuntimeSpriteMetrics {
    pub width: i32,
    pub height: i32,
    pub origin_x: i32,
    pub origin_y: i32,
    pub bbox_left: i32,
    pub bbox_right: i32,
    pub bbox_top: i32,
    pub bbox_bottom: i32,
    pub collision_masks: Vec<RuntimeCollisionMask>,
    pub per_frame_collision_masks: bool,
}

impl Default for RuntimeSpriteMetrics {
    fn default() -> Self {
        Self {
            width: 16,
            height: 16,
            origin_x: 0,
            origin_y: 0,
            bbox_left: 0,
            bbox_right: 15,
            bbox_top: 0,
            bbox_bottom: 15,
            collision_masks: Vec::new(),
            per_frame_collision_masks: false,
        }
    }
}

impl From<&SpriteResource> for RuntimeSpriteMetrics {
    fn from(sprite: &SpriteResource) -> Self {
        let width = sprite.width.max(1) as i32;
        let height = sprite.height.max(1) as i32;
        Self {
            width,
            height,
            origin_x: sprite.origin_x,
            origin_y: sprite.origin_y,
            bbox_left: sprite.bbox_left as i32,
            bbox_right: sprite.bbox_right as i32,
            bbox_top: sprite.bbox_top as i32,
            bbox_bottom: sprite.bbox_bottom as i32,
            collision_masks: sprite
                .collision_masks
                .iter()
                .map(|mask| RuntimeCollisionMask {
                    width: mask.width,
                    height: mask.height,
                    bbox_left: mask.bbox_left as i32,
                    bbox_right: mask.bbox_right as i32,
                    bbox_top: mask.bbox_top as i32,
                    bbox_bottom: mask.bbox_bottom as i32,
                    data: mask.data.clone(),
                })
                .collect(),
            per_frame_collision_masks: sprite.per_frame_collision_masks,
        }
    }
}
