use crate::helpers::is_player_instance;
use crate::{
    LoweredLogicEntry, LoweredLogicExpr, LoweredLogicFile, LoweredLogicStatement, RuntimeCore,
    RuntimeCoreError, RuntimeStatus,
};

use super::support::{
    add_collision_block, add_destroy_block, add_step_block, append_lowered_entry, sample_package,
};

#[test]
fn core_loads_default_room_and_instances() {
    let core = RuntimeCore::load(sample_package()).unwrap();

    assert_eq!(core.status(), RuntimeStatus::Ready);
    assert_eq!(core.current_room().map(|room| room.room_id), Some(7));
    assert_eq!(
        core.current_room().map(|room| room.instances.len()),
        Some(5)
    );
    assert!(core.current_room().unwrap().instances[0].player_candidate);
}

#[test]
fn core_preserves_sparse_object_ids_in_room_instances() {
    let core = RuntimeCore::load(sample_package()).unwrap();
    let room = core.current_room().unwrap();

    assert!(room
        .instances
        .iter()
        .any(|instance| instance.object_id == 705));
    assert!(room
        .instances
        .iter()
        .any(|instance| instance.object_id == 705 && instance.width == 16));
}

#[test]
fn object_hazard_inherits_from_parent_when_child_is_unspecified() {
    let mut package = sample_package();
    let mut parent = package.objects[2].clone();
    parent.id = 900;
    parent.name = "hazard_parent".into();
    parent.is_hazard = Some(true);

    let mut child = parent.clone();
    child.id = 901;
    child.name = "hazard_child".into();
    child.parent_index = parent.id as i32;
    child.is_hazard = None;

    let mut explicit_safe_child = child.clone();
    explicit_safe_child.id = 902;
    explicit_safe_child.name = "explicit_safe_child".into();
    explicit_safe_child.is_hazard = Some(false);

    package.objects.extend([parent, child, explicit_safe_child]);

    assert!(crate::room_builder::object_is_hazard(&package.objects, 901));
    assert!(!crate::room_builder::object_is_hazard(
        &package.objects,
        902
    ));
}

#[test]
fn runtime_room_state_copies_package_view_state() {
    let mut package = sample_package();
    package.rooms[0].views_enabled = true;
    package.rooms[0].views[0].source_x = 800;
    package.rooms[0].views[0].source_y = 608;
    package.rooms[0].views[0].source_w = 800;
    package.rooms[0].views[0].source_h = 600;
    package.rooms[0].views[0].port_w = 800;
    package.rooms[0].views[0].port_h = 600;
    package.rooms[0].views[0].target = 259;
    package.rooms[0].views[0].hborder = 40;
    package.rooms[0].views[0].vborder = 48;
    package.rooms[0].views[0].hspeed = -1;
    package.rooms[0].views[0].vspeed = 12;

    let core = RuntimeCore::load(package).unwrap();
    let room = core.current_room().unwrap();

    assert!(room.views_enabled);
    assert_eq!(room.views.len(), 1);
    assert_eq!(room.views[0].source_x, 800);
    assert_eq!(room.views[0].source_y, 608);
    assert_eq!(room.views[0].source_w, 800);
    assert_eq!(room.views[0].source_h, 600);
    assert_eq!(room.views[0].port_w, 800);
    assert_eq!(room.views[0].port_h, 600);
    assert_eq!(room.views[0].target, 259);
    assert_eq!(room.views[0].hborder, 40);
    assert_eq!(room.views[0].vborder, 48);
    assert_eq!(room.views[0].hspeed, -1);
    assert_eq!(room.views[0].vspeed, 12);
}

#[test]
fn core_reports_missing_room() {
    let mut package = sample_package();
    package.manifest.default_room_id = Some(99);

    let error = RuntimeCore::load(package).unwrap_err();
    assert!(matches!(error, RuntimeCoreError::RoomMissing(99)));
}

#[test]
fn core_does_not_spawn_fallback_player_when_room_has_checkpoint_but_no_spawn_logic() {
    let mut package = sample_package();
    package.rooms[0]
        .instances
        .retain(|instance| instance.object_id != 0);
    package.rooms[0].instances[0].is_checkpoint = true;

    let core = RuntimeCore::load(package).unwrap();
    let room = core.current_room().unwrap();

    assert!(!room.instances.iter().any(is_player_instance));
    assert!(!room
        .instances
        .iter()
        .any(|instance| instance.object_id == 0));
}

#[test]
fn core_does_not_treat_player_start_markers_as_spawned_players() {
    let mut package = sample_package();
    package.rooms[0]
        .instances
        .retain(|instance| instance.object_id != 0);
    package.rooms[0].instances[0].is_checkpoint = true;
    package.rooms[0]
        .instances
        .push(iwm_runtime_model::RoomInstancePlacement {
            instance_id: 99,
            object_id: 2,
            x: 24,
            y: 24,
            xscale: 1.0,
            yscale: 1.0,
            angle: 0.0,
            blend: 0x00ff_ffff,
            creation_block_id: None,
            is_solid: false,
            is_hazard: false,
            is_checkpoint: true,
        });
    package.objects.push(iwm_runtime_model::ObjectDefinition {
        id: 2,
        name: "playerStart".into(),
        sprite_index: -1,
        parent_index: -1,
        depth: -10,
        persistent: false,
        visible: false,
        solid: false,
        mask_index: -1,
        is_hazard: Some(false),
        is_checkpoint: Some(true),
        is_player: true,
        events: vec![],
    });

    let core = RuntimeCore::load(package).unwrap();
    let room = core.current_room().unwrap();

    assert!(!room.instances.iter().any(is_player_instance));
    assert!(room
        .instances
        .iter()
        .any(|instance| { instance.object_name == "playerStart" && instance.player_candidate }));
}

#[test]
fn core_loads_structured_lowered_logic_entries() {
    let mut package = sample_package();
    package.lowered_logic = Some(LoweredLogicFile {
        format: "iwm-lowered-logic-v1".into(),
        entries: vec![LoweredLogicEntry {
            block_id: "room:7:create".into(),
            statements: vec![
                LoweredLogicStatement::VariableDeclaration {
                    names: vec!["i".into()],
                },
                LoweredLogicStatement::For {
                    init: LoweredLogicExpr::Identifier("i = 0".into()),
                    condition: LoweredLogicExpr::BinaryExpr {
                        op: "<".into(),
                        left: Box::new(LoweredLogicExpr::Identifier("i".into())),
                        right: Box::new(LoweredLogicExpr::LiteralNumber(3.0)),
                    },
                    step: LoweredLogicExpr::BinaryExpr {
                        op: "+".into(),
                        left: Box::new(LoweredLogicExpr::Identifier("i".into())),
                        right: Box::new(LoweredLogicExpr::LiteralNumber(1.0)),
                    },
                    body: vec![LoweredLogicStatement::Return {
                        value: Some(LoweredLogicExpr::LiteralBool(false)),
                    }],
                },
            ],
        }],
    });

    let core = RuntimeCore::load(package).unwrap();

    assert_eq!(core.current_room().map(|room| room.room_id), Some(7));
    assert!(core.current_room().is_some_and(|room| room
        .instances
        .iter()
        .any(|instance| instance.player_candidate)));
}

#[test]
fn core_caches_create_and_destroy_event_entries_on_load() {
    let mut package = sample_package();
    package.objects[0]
        .events
        .push(iwm_runtime_model::ObjectEventEntry {
            event_type: 0,
            sub_event: 0,
            event_tag: "create".into(),
            block_id: "object:0:event:0:0".into(),
            action_count: 0,
        });
    package.objects[0]
        .events
        .push(iwm_runtime_model::ObjectEventEntry {
            event_type: 1,
            sub_event: 0,
            event_tag: "destroy".into(),
            block_id: "object:0:event:1:0".into(),
            action_count: 0,
        });
    package.lowered_logic = Some(LoweredLogicFile {
        format: "iwm-lowered-logic-v1".into(),
        entries: vec![
            LoweredLogicEntry {
                block_id: "object:0:event:0:0".into(),
                statements: vec![LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("created".into()),
                    value: LoweredLogicExpr::LiteralBool(true),
                }],
            },
            LoweredLogicEntry {
                block_id: "object:0:event:1:0".into(),
                statements: vec![LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("destroyed".into()),
                    value: LoweredLogicExpr::LiteralBool(true),
                }],
            },
        ],
    });

    let core = RuntimeCore::load(package).unwrap();

    let create_entries = core.cached_create_event_entries.get(&0).unwrap();
    assert!(create_entries
        .iter()
        .any(|entry| entry.block_id == "object:0:event:0:0"));

    let destroy_entries = core.cached_destroy_event_entries.get(&0).unwrap();
    assert!(destroy_entries
        .iter()
        .any(|entry| entry.block_id == "object:0:event:1:0"));
}

#[test]
fn core_caches_lowered_event_entry_indices_on_load() {
    let mut package = sample_package();

    append_lowered_entry(&mut package, "object:0:event:0:0".into(), vec![]);
    add_step_block(&mut package, vec![]);
    add_destroy_block(&mut package, vec![]);
    add_collision_block(&mut package, 2, vec![]);

    let core = RuntimeCore::load(package).unwrap();

    assert_eq!(
        core.cached_dispatch_tables
            .step_entry_indices_by_object_id
            .get(&0)
            .map(Vec::len),
        Some(1)
    );
    assert_eq!(
        core.cached_dispatch_tables
            .create_entry_indices_by_object_id
            .get(&0)
            .map(Vec::len),
        Some(1)
    );
    assert_eq!(
        core.cached_dispatch_tables
            .destroy_entry_indices_by_object_id
            .get(&0)
            .map(Vec::len),
        Some(1)
    );
    assert_eq!(
        core.cached_dispatch_tables
            .collision_entry_indices_by_owner_and_target
            .get(&(0, 2))
            .map(Vec::len),
        Some(1)
    );
}
