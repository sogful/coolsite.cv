use super::*;

use crate::RuntimeInstance;

#[test]
fn crimson_count_killed_bosses_script_returns_without_unsupported_diagnostics() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(163).unwrap();
    let mut host = HeadlessHost::new("sandbox");

    core.tick(&mut host).unwrap();

    assert!(!core.diagnostics().iter().any(|diagnostic| {
        diagnostic.code == "runtime-unsupported-function"
            && diagnostic.message.contains("countKilledBosses")
    }));
}

#[cfg(feature = "local-sample-tests")]
#[test]
fn orbit_stage01_block_spike_corner_does_not_kill_player() {
    let Some(package) = local_sample_package("gm8-core/28_I wanna be the Orbit") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(150).unwrap();
    core.set_debug_trace_limits(128, 12);
    let mut host = HeadlessHost::new("orbit-corner");

    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
            .expect("room should include the player");
        player.x = 100.0;
        player.y = 410.0;
        player.previous_x = 100.0;
        player.previous_y = 409.0;
        player.hspeed = 0.0;
        player.vspeed = 0.0;
    }

    assert!(core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .filter(|instance| instance.object_name == "rise path")
        .all(|instance| instance.hazard));

    core.tick(&mut host).unwrap();

    let snapshot = core.snapshot();
    assert!(
        snapshot.player.is_some(),
        "Orbit corner should keep player alive"
    );
    assert_eq!(snapshot.deaths, 0, "safe block-spike corner must not kill");
    assert!(snapshot
        .collision_trace
        .iter()
        .any(|trace| trace.target_object_id == 6 && trace.other.object_name == "spikeLeft"));
}

fn move_real_sample_player_onto_savepoint(core: &mut RuntimeCore) {
    move_real_sample_player_onto_target(
        core,
        |instance| instance.object_name.eq_ignore_ascii_case("savePoint"),
        "savePoint",
    );
}

fn move_real_sample_player_onto_savepoint_at(core: &mut RuntimeCore, x: f64, y: f64) -> usize {
    move_real_sample_player_onto_target(
        core,
        |instance| {
            instance.object_name.eq_ignore_ascii_case("savePoint")
                && instance.x == x
                && instance.y == y
        },
        "savePoint at requested coordinates",
    )
}

fn move_real_sample_player_onto_target<F>(
    core: &mut RuntimeCore,
    mut matches_target: F,
    description: &str,
) -> usize
where
    F: FnMut(&RuntimeInstance) -> bool,
{
    let room = core.current_room.as_mut().unwrap();
    let target = room
        .instances
        .iter()
        .find(|instance| instance.alive && matches_target(instance))
        .cloned()
        .unwrap_or_else(|| panic!("room should include a live {description}"));
    let player = room
        .instances
        .iter_mut()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .expect("room should include a live player");
    let (x, y) = overlapping_player_position(player, &target)
        .unwrap_or_else(|| panic!("test setup should find overlap for {description}"));
    player.x = x;
    player.y = y;
    player.previous_x = player.x;
    player.previous_y = player.y;
    assert!(
        crate::helpers::collides_with_instance_at(
            player,
            player.x,
            player.y,
            &target,
            None,
            |_| true
        ),
        "test setup should overlap player and {description}"
    );
    target.runtime_id
}

fn overlapping_player_position(
    player: &RuntimeInstance,
    target: &RuntimeInstance,
) -> Option<(f64, f64)> {
    let (left, top, right, bottom) = crate::helpers::bounds_at(target, target.x, target.y);
    for world_y in top..bottom {
        for world_x in left..right {
            for player_local_y in player.bbox_top..=player.bbox_bottom {
                for player_local_x in player.bbox_left..=player.bbox_right {
                    let x = (world_x + player.origin_x - player_local_x) as f64;
                    let y = (world_y + player.origin_y - player_local_y) as f64;
                    if crate::helpers::collides_with_instance_at(player, x, y, target, None, |_| {
                        true
                    }) {
                        return Some((x, y));
                    }
                }
            }
        }
    }
    None
}

fn real_sample_room_id(core: &RuntimeCore, name: &str) -> usize {
    core.package
        .rooms
        .iter()
        .find(|room| room.name.eq_ignore_ascii_case(name))
        .map(|room| room.id)
        .unwrap_or_else(|| panic!("sample package should include room {name}"))
}

fn tick_real_sample_until_room(
    core: &mut RuntimeCore,
    host: &mut HeadlessHost,
    room_id: usize,
    name: &str,
) {
    for _ in 0..120 {
        if core.snapshot().room_id == Some(room_id) {
            return;
        }
        core.tick(host).unwrap();
        host.input.clear_transitions();
    }
    assert_eq!(
        core.snapshot().room_id,
        Some(room_id),
        "sample should reach {name}"
    );
}

fn tap_real_sample_jump(core: &mut RuntimeCore, host: &mut HeadlessHost) {
    let key = match core.globals.get("global.jumpbutton") {
        Some(RuntimeValue::Number(value)) => *value as u16,
        _ => 0x10,
    };
    press_real_sample_key(host, key);
    core.tick(host).unwrap();
    release_real_sample_key(host, key);
    host.input.clear_transitions();
}

fn enter_real_sample_difficulty_room(core: &mut RuntimeCore, host: &mut HeadlessHost) {
    let title_room = real_sample_room_id(core, "rTitle");
    let menu_room = real_sample_room_id(core, "rMenu");
    let difficulty_room = real_sample_room_id(core, "rSelectStage");

    if !matches!(
        core.snapshot().room_id,
        Some(room_id) if room_id == title_room || room_id == menu_room || room_id == difficulty_room
    ) {
        tick_real_sample_until_room(core, host, title_room, "rTitle");
    }
    if core.snapshot().room_id == Some(title_room) {
        tap_real_sample_jump(core, host);
        tick_real_sample_until_room(core, host, menu_room, "rMenu");
    }
    if core.snapshot().room_id == Some(menu_room) {
        let live_worlds = core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .filter(|instance| instance.object_name.eq_ignore_ascii_case("world") && instance.alive)
            .map(|instance| instance.runtime_id)
            .collect::<Vec<_>>();
        assert_eq!(
            live_worlds.len(),
            1,
            "package title flow should carry one persistent world into rMenu, got {live_worlds:?}"
        );
    }
    if core.snapshot().room_id == Some(menu_room) {
        tap_real_sample_jump(core, host);
        tick_real_sample_until_room(core, host, difficulty_room, "rSelectStage");
    }
    assert_eq!(core.snapshot().room_id, Some(difficulty_room));
    let live_worlds = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("world") && instance.alive)
        .map(|instance| instance.runtime_id)
        .collect::<Vec<_>>();
    assert_eq!(
        live_worlds.len(),
        1,
        "package menu flow should carry one persistent world into rSelectStage, got {live_worlds:?}; diagnostics={:?}",
        core.diagnostics()
            .iter()
            .filter(|diagnostic| diagnostic.message.contains("world"))
            .collect::<Vec<_>>()
    );
}

fn select_real_sample_medium_difficulty(core: &mut RuntimeCore, host: &mut HeadlessHost) {
    enter_real_sample_difficulty_room(core, host);
    let stage_room = real_sample_room_id(core, "rStage01");

    move_real_sample_player_onto_target(
        core,
        |instance| {
            instance.object_name.eq_ignore_ascii_case("warpStart")
                && instance.vars.get("dif") == Some(&RuntimeValue::Number(0.0))
        },
        "medium difficulty warpStart",
    );

    core.tick(host).unwrap();
    host.input.clear_transitions();

    assert_eq!(
        core.globals.get("global.difficulty"),
        Some(&RuntimeValue::Number(0.0)),
        "difficulty should be selected through the package-owned warpStart collision; room={:?}, players={:?}, recent diagnostics={:?}",
        core.snapshot().room_id,
        core.current_room()
            .unwrap()
            .instances
            .iter()
            .filter(|instance| crate::helpers::is_player_instance(instance))
            .map(|instance| (
                instance.runtime_id,
                instance.alive,
                instance.x,
                instance.y,
                instance.hspeed,
                instance.vspeed,
                instance.vars.get("frozen"),
            ))
            .collect::<Vec<_>>(),
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert_eq!(core.snapshot().room_id, Some(stage_room));
}

#[test]
fn real_sample_r_select_stage_spike_reset_keeps_player_movable() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let difficulty_room = real_sample_room_id(&core, "rSelectStage");

    enter_real_sample_difficulty_room(&mut core, &mut host);
    move_real_sample_player_onto_target(
        &mut core,
        |instance| instance.hazard && instance.object_name.to_ascii_lowercase().contains("spike"),
        "rSelectStage spike hazard",
    );

    core.tick(&mut host).unwrap();
    host.input.clear_transitions();

    assert_eq!(core.snapshot().room_id, Some(difficulty_room));
    let x_before = core
        .snapshot()
        .player
        .as_ref()
        .map(|player| player.x)
        .expect("spike reset should recreate a live player");

    press_real_sample_key(&mut host, 0x27);
    core.tick(&mut host).unwrap();

    let player = core
        .snapshot()
        .player
        .expect("player should remain live after reset movement");
    assert!(
        player.x > x_before,
        "player should move right after rSelectStage spike reset; before={x_before}, after={}, diagnostics={:?}",
        player.x,
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn real_sample_r_key_does_not_load_save_on_difficulty_room() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let difficulty_room = real_sample_room_id(&core, "rSelectStage");

    core.reload_room(difficulty_room).unwrap();
    assert_eq!(
        core.pending_room_transition, None,
        "manual rSelectStage reload should not leave a pending transition"
    );
    move_real_sample_player_away_from_warp_starts(&mut core);
    for instance in &mut core.current_room.as_mut().unwrap().instances {
        if !instance.object_name.eq_ignore_ascii_case("world")
            && !crate::helpers::is_player_instance(instance)
        {
            instance.alive = false;
        }
    }
    let live_non_input_instances = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .filter(|instance| {
            instance.alive
                && !instance.object_name.eq_ignore_ascii_case("world")
                && !crate::helpers::is_player_instance(instance)
        })
        .map(|instance| {
            (
                instance.object_name.clone(),
                instance.object_id,
                instance.runtime_id,
            )
        })
        .collect::<Vec<_>>();
    assert!(
        live_non_input_instances.is_empty(),
        "test setup should leave only world/player alive, got {live_non_input_instances:?}"
    );
    core.globals
        .insert("global.savenum".into(), RuntimeValue::Number(1.0));
    let saved_position = (321.0, 654.0);
    host.files
        .write_temp(Path::new("save1"), &sample_save_bytes(143, 321, 654))
        .unwrap();

    press_real_sample_key(&mut host, 0x52);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x52);

    let snapshot = core.snapshot();
    assert_eq!(
        snapshot.room_id,
        Some(difficulty_room),
        "R on rSelectStage should be ignored by package load logic; diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert_ne!(
        snapshot.player.as_ref().map(|player| (player.x, player.y)),
        Some(saved_position),
        "R on rSelectStage should not restore save coordinates"
    );
    assert!(core
        .diagnostics()
        .iter()
        .all(|diagnostic| diagnostic.code != "runtime-room-restart-requested"));
}

fn move_real_sample_player_away_from_warp_starts(core: &mut RuntimeCore) {
    let room = core.current_room.as_mut().unwrap();
    let player_indices = room
        .instances
        .iter()
        .enumerate()
        .filter_map(|(index, instance)| {
            (crate::helpers::is_player_instance(instance) && instance.alive).then_some(index)
        })
        .collect::<Vec<_>>();
    assert!(
        !player_indices.is_empty(),
        "room should include a live player"
    );
    let warp_starts = room
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("warpStart") && instance.alive)
        .cloned()
        .collect::<Vec<_>>();
    for (x, y) in [(0.0, 0.0), (32.0, 32.0), (400.0, 300.0), (760.0, 520.0)] {
        if player_indices.iter().all(|player_index| {
            let player = &room.instances[*player_index];
            warp_starts.iter().all(|warp| {
                !crate::helpers::collides_with_instance_at(player, x, y, warp, None, |_| true)
            })
        }) {
            for player_index in &player_indices {
                let player = &mut room.instances[*player_index];
                player.x = x;
                player.y = y;
                player.previous_x = x;
                player.previous_y = y;
            }
            return;
        }
    }
    panic!("test setup should find a player position away from warpStart");
}

#[test]
fn real_sample_bootstrap_sets_shift_jump_binding() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let title_room = real_sample_room_id(&core, "rTitle");

    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");

    assert_eq!(
        core.globals.get("global.jumpbutton"),
        Some(&RuntimeValue::Number(0x10 as f64))
    );
}

#[test]
fn crimson_world_room_start_sets_shared_runtime_room_speed() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let title_room = real_sample_room_id(&core, "rTitle");

    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");
    assert_eq!(core.current_room_speed(), Some(50));

    enter_real_sample_difficulty_room(&mut core, &mut host);
    assert_eq!(core.current_room_speed(), Some(50));

    // Crimson's medium warpStart enters room001, not the Dife-style rStage01.
    let medium_stage_room = real_sample_room_id(&core, "room001");
    move_real_sample_player_onto_target(
        &mut core,
        |instance| {
            instance.object_name.eq_ignore_ascii_case("warpStart")
                && instance.vars.get("dif") == Some(&RuntimeValue::Number(0.0))
        },
        "medium difficulty warpStart",
    );
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();

    assert_eq!(
        core.globals.get("global.difficulty"),
        Some(&RuntimeValue::Number(0.0)),
        "medium warpStart collision should select difficulty; diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert_eq!(core.snapshot().room_id, Some(medium_stage_room));
    assert_eq!(core.current_room_speed(), Some(50));
}

#[test]
fn crimson_room001_lift_starts_rising_when_player_touches_it() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let stage_room = real_sample_room_id(&core, "room001");
    core.reload_room(stage_room).unwrap();

    // Let instance creation code run so the lift stores its vspd = -2.5.
    for _ in 0..2 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    // Instance 142635 is the object491 lift on the right side of room001. Its
    // movement is started by movingPlatformCollision's inherited collision
    // event with the player, which must stay active even though object491
    // declares its own collision event with object492.
    let lift_runtime_id = move_real_sample_player_onto_target(
        &mut core,
        |instance| instance.instance_id == 142635,
        "object491 lift instance 142635",
    );

    let lift_y_before = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.runtime_id == lift_runtime_id && instance.alive)
        .expect("lift should be alive before ticking")
        .y;

    for _ in 0..6 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    let lift_y_after = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.runtime_id == lift_runtime_id && instance.alive)
        .expect("lift should still be alive after ticking")
        .y;

    assert!(
        lift_y_after < lift_y_before,
        "touching the lift should start its parsed vspd = -2.5 rise; before={lift_y_before}, after={lift_y_after}, diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn crimson_player_falls_every_tick_while_holding_direction_into_wall() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    // Boot through the title so crimson's init sets global.buttonLeft; the
    // step event only re-assigns hspeed once the bindings are live, which is
    // what used to flip the motion-changed gate every other tick.
    let title_room = real_sample_room_id(&core, "rTitle");
    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");

    let stage_room = real_sample_room_id(&core, "room001");
    core.reload_room(stage_room).unwrap();

    // Airborne beside the tall wall whose right face is at x=1632; a player at
    // x=1637 hugs it flush on the left.
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("room001 should include a live player");
        player.x = 1637.0;
        player.y = 950.0;
        player.previous_x = player.x;
        player.previous_y = player.y;
        player.set_hspeed(0.0);
        player.set_vspeed(0.0);
    }

    press_real_sample_key(&mut host, 0x25);
    let mut previous_y = 950.0;
    for tick in 0..15 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
        let player = core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("player should stay alive during the wall slide");
        assert!(
            player.y > previous_y,
            "wall slide must descend every tick, not every other tick (tick {tick}: y stayed at {})",
            player.y
        );
        assert!(
            (player.x - 1637.0).abs() < 1.0,
            "player should stay pinned to the wall face (tick {tick}: x={})",
            player.x
        );
        previous_y = player.y;
    }
}

#[test]
fn real_sample_title_shift_enters_save_menu() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let title_room = real_sample_room_id(&core, "rTitle");
    let menu_room = real_sample_room_id(&core, "rMenu");

    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");
    tap_real_sample_jump(&mut core, &mut host);

    assert_eq!(
        core.snapshot().room_id,
        Some(menu_room),
        "title Shift should follow parsed room_goto(rMenu); globals={:?}, input_trace={:?}, instances={:?}, diagnostics={:?}",
        core.globals,
        core.snapshot().input_trace,
        core.current_room()
            .unwrap()
            .instances
            .iter()
            .map(|instance| (
                instance.object_name.clone(),
                instance.object_id,
                instance.alive,
                instance.vars.clone()
            ))
            .collect::<Vec<_>>(),
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn crimson_title_starts_opbgm_loop() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let opbgm_id = package
        .resources
        .sounds
        .iter()
        .find(|sound| sound.name.eq_ignore_ascii_case("opbgm"))
        .expect("Crimson package should include opbgm")
        .id as i32;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let title_room = real_sample_room_id(&core, "rTitle");

    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");
    core.tick(&mut host).unwrap();

    assert!(
        host.audio
            .played
            .contains(&(opbgm_id, RuntimeSoundMode::Loop)),
        "rTitle should dispatch its package-owned BGM; played={:?}; music={:?}; diagnostics={:?}",
        host.audio.played,
        core.current_room()
            .unwrap()
            .instances
            .iter()
            .find(|instance| instance.object_id == 3)
            .map(|instance| &instance.vars),
        core.diagnostics()
    );
}

#[test]
fn crimson_stage_entry_switches_bgm_from_opbgm_to_track01() {
    let Some(package) = local_sample_package("gm8-core/I wanna be the Crimson ver.1.0") else {
        return;
    };
    let opbgm_id = package
        .resources
        .sounds
        .iter()
        .find(|sound| sound.name.eq_ignore_ascii_case("opbgm"))
        .expect("Crimson package should include opbgm")
        .id as i32;
    let track01_id = package
        .resources
        .sounds
        .iter()
        .find(|sound| sound.name.eq_ignore_ascii_case("track01"))
        .expect("Crimson package should include track01")
        .id as i32;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let title_room = real_sample_room_id(&core, "rTitle");
    // Explicit stageBGM=track01 create code.
    let stage_with_bgm = real_sample_room_id(&core, "rStage01");
    // Medium-difficulty first room is room001; playMusic has no creation_code so stageBGM
    // is uninitialized and must resolve as 0 under zero_uninitialized_vars (track01).
    let stage_unset_bgm = 148usize;

    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");
    core.tick(&mut host).unwrap();
    assert!(
        host.audio
            .played
            .contains(&(opbgm_id, RuntimeSoundMode::Loop)),
        "rTitle should start opbgm before stage entry; played={:?}",
        host.audio.played
    );

    for stage_room in [stage_with_bgm, stage_unset_bgm] {
        host.audio.played.clear();
        host.audio.stopped_all_count = 0;
        host.audio.playing.clear();
        host.audio
            .play_sound(opbgm_id, RuntimeSoundMode::Loop)
            .unwrap();

        core.request_room_transition(stage_room);
        core.tick(&mut host).unwrap();
        core.tick(&mut host).unwrap();

        let play_music = core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .find(|instance| {
                instance.object_name.eq_ignore_ascii_case("playMusic") && instance.alive
            })
            .map(|instance| {
                (
                    instance.vars.get("stageBGM").cloned(),
                    instance.vars.get("stageName").cloned(),
                )
            });
        let played_loops = host
            .audio
            .played
            .iter()
            .filter(|(_, mode)| *mode == RuntimeSoundMode::Loop)
            .copied()
            .collect::<Vec<_>>();

        assert_eq!(core.snapshot().room_id, Some(stage_room));
        assert!(
            play_music.is_some(),
            "room {stage_room} should place playMusic; playMusic={play_music:?}"
        );
        assert_eq!(
            play_music.as_ref().and_then(|(_, stage)| stage.clone()),
            Some(RuntimeValue::Number(stage_room as f64)),
            "playMusic create should assign stageName=room; room={stage_room}; playMusic={play_music:?}"
        );
        assert!(
            played_loops.contains(&(track01_id, RuntimeSoundMode::Loop)),
            "room {stage_room} should sound_loop(track01); played_loops={played_loops:?}; playMusic={play_music:?}; stopped_all={}; is_playing_opbgm={}; is_playing_track01={}; diagnostics={:?}",
            host.audio.stopped_all_count,
            host.audio.is_sound_playing(opbgm_id).unwrap(),
            host.audio.is_sound_playing(track01_id).unwrap(),
            core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
        );
        assert!(
            host.audio.stopped_all_count > 0,
            "room {stage_room} should sound_stop_all before stage BGM; playMusic={play_music:?}"
        );
        assert!(
            !host.audio.is_sound_playing(opbgm_id).unwrap(),
            "room {stage_room} should stop opbgm; playMusic={play_music:?}"
        );
    }
}

#[test]
fn real_sample_new_game_starts_at_stage_spawn_and_writes_initial_save() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    select_real_sample_medium_difficulty(&mut core, &mut host);

    let snapshot = core.snapshot();
    let player = snapshot
        .player
        .as_ref()
        .expect("new game should create a live player at the first stage start");
    assert_eq!(snapshot.room_id, Some(147));
    assert_eq!((player.x, player.y), (913.0, 1175.0));
    let save_bytes = host.files.read(Path::new("save1")).unwrap();
    assert!(
        save_bytes.starts_with(&[0, 1, 47, 0, 9, 13, 0, 11, 75, 0, 0]),
        "new-game save should start with room/player/difficulty bytes, got {save_bytes:?}"
    );
}

#[test]
fn real_sample_r_restart_keeps_stage_bgm_loop_running() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let bgm_id = package
        .resources
        .sounds
        .iter()
        .find(|sound| sound.name.eq_ignore_ascii_case("PPPPPP"))
        .expect("Dife package should include the PPPPPP stage BGM")
        .id as i32;
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    select_real_sample_medium_difficulty(&mut core, &mut host);
    let stage_room = real_sample_room_id(&core, "rStage01");

    let bgm_loop_plays = |host: &HeadlessHost| {
        host.audio
            .played
            .iter()
            .filter(|(id, mode)| *id == bgm_id && *mode == RuntimeSoundMode::Loop)
            .count()
    };
    assert_eq!(
        bgm_loop_plays(&host),
        1,
        "stage entry should start the PPPPPP loop exactly once; played={:?}",
        host.audio.played
    );
    assert!(host.audio.is_sound_playing(bgm_id).unwrap());

    press_real_sample_key(&mut host, 82);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 82);
    tick_real_sample_until_room(&mut core, &mut host, stage_room, "rStage01 after R restart");

    assert!(
        core.diagnostics().iter().any(|diagnostic| {
            diagnostic.code == "runtime-room-changed"
                && diagnostic.message.contains("reason=game_restart")
        }),
        "R should route through the package-owned loadGame/game_restart GML; diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    // GM8 keeps sounds playing across game_restart, and rStage01's playMusic
    // creation code guards with sound_isplaying, so an R retry must neither
    // stop the BGM nor restart it from zero.
    assert_eq!(
        host.audio.stopped_all_count,
        0,
        "R restart must not stop_all_sounds; diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert!(
        host.audio.is_sound_playing(bgm_id).unwrap(),
        "stage BGM loop should survive the R restart; stopped={:?}",
        host.audio.stopped
    );
    assert_eq!(
        bgm_loop_plays(&host),
        1,
        "stage BGM must not be re-played from zero after R; played={:?}",
        host.audio.played
    );
}

#[test]
fn real_sample_menu_uses_death_time_file_stats() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let title_room = real_sample_room_id(&core, "rTitle");
    let menu_room = real_sample_room_id(&core, "rMenu");

    host.files
        .write_temp(
            Path::new("DeathTime"),
            &[
                0, 0, 0, 12, 0, 0, 0, 65, 0, 0, 0, 3, 0, 0, 36, 61, 0, 0, 0, 7, 0, 0, 0, 9,
            ],
        )
        .unwrap();

    tick_real_sample_until_room(&mut core, &mut host, title_room, "rTitle");
    tap_real_sample_jump(&mut core, &mut host);
    tick_real_sample_until_room(&mut core, &mut host, menu_room, "rMenu");
    core.render(&mut host).unwrap();

    let frame = host.renderer.submitted_frames.last().unwrap();
    let texts = frame
        .commands
        .iter()
        .filter_map(|command| match command {
            iwm_runtime_host::RuntimeDrawCommand::DrawText { text, .. } => Some(text.as_str()),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert!(
        texts.contains(&"death:12") && texts.contains(&"time:0:1:5"),
        "rMenu should render persisted slot stats, got texts={texts:?}; globals={:?}",
        core.globals
    );
}

#[test]
fn real_sample_stage_alarm_increments_selected_save_time() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    select_real_sample_medium_difficulty(&mut core, &mut host);
    assert_eq!(
        core.globals.get("global.time[1]"),
        Some(&RuntimeValue::Number(0.0))
    );
    let room_speed = core
        .current_room_speed()
        .expect("stage room should expose room_speed") as usize;

    for _ in 0..=room_speed {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    assert_eq!(
        core.globals.get("global.time[1]"),
        Some(&RuntimeValue::Number(1.0)),
        "player alarm should count one elapsed second using room_speed; diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

fn runtime_value_is_true(value: &RuntimeValue) -> bool {
    match value {
        RuntimeValue::Bool(flag) => *flag,
        RuntimeValue::Number(number) => *number >= 0.5,
        RuntimeValue::Text(text) => !text.is_empty(),
    }
}

#[test]
fn real_sample_spent_double_jump_landing_restores_djump_on_both_platform_kinds() {
    let Some(_) = real_sample_package() else {
        return;
    };

    for platform_name in ["platform", "movingPlatform"] {
        let package = real_sample_package().unwrap();
        let mut core = RuntimeCore::load(package).unwrap();
        let mut host = host();
        let platform_room = real_sample_room_id(&core, "rMegaman01");
        core.reload_room(platform_room).unwrap();

        // Let creation codes / first step settle so moving platforms pick up speed.
        for _ in 0..2 {
            core.tick(&mut host).unwrap();
            host.input.clear_transitions();
        }

        {
            let room = core.current_room.as_mut().unwrap();
            let platform = room
                .instances
                .iter()
                .find(|instance| {
                    instance.object_name.eq_ignore_ascii_case(platform_name)
                        && instance.alive
                        && (platform_name != "movingPlatform"
                            || ((instance.x - 1888.0).abs() < 64.0
                                && (instance.y - 767.0).abs() < 64.0))
                })
                .cloned()
                .unwrap_or_else(|| panic!("rMegaman01 should include a live {platform_name}"));
            let player = room
                .instances
                .iter_mut()
                .find(|instance| {
                    instance.object_name.eq_ignore_ascii_case("player") && instance.alive
                })
                .expect("rMegaman01 should include a live player");

            player.x = platform.x + 8.0;
            player.y = platform.y - 16.0;
            player.previous_x = player.x;
            player.previous_y = player.y;
            player.hspeed = 0.0;
            player.vspeed = 0.0;
            player
                .vars
                .insert("djump".into(), RuntimeValue::Bool(false));
            player
                .vars
                .insert("onPlatform".into(), RuntimeValue::Bool(false));
            eprintln!(
                "[{platform_name}] probe start: player=({}, {}), platform=({}, {}), vars(jump={:?}, gravity={:?}, maxFallSpeed={:?}, maxVspeed={:?})",
                player.x,
                player.y,
                platform.x,
                platform.y,
                player.vars.get("jump"),
                player.vars.get("gravity"),
                player.vars.get("maxFallSpeed"),
                player.vars.get("maxVspeed"),
            );
        }

        let mut djump_restored_tick: Option<usize> = None;
        for tick in 0..90 {
            core.tick(&mut host).unwrap();
            host.input.clear_transitions();
            let room = core.current_room().unwrap();
            let player = room
                .instances
                .iter()
                .find(|instance| {
                    instance.object_name.eq_ignore_ascii_case("player") && instance.alive
                })
                .cloned();
            let platform = room
                .instances
                .iter()
                .find(|instance| {
                    instance.object_name.eq_ignore_ascii_case(platform_name) && instance.alive
                })
                .cloned();
            let (Some(player), Some(platform)) = (player, platform) else {
                eprintln!("[{platform_name}] tick {tick}: player or platform gone");
                break;
            };
            let djump = player.vars.get("djump").is_some_and(runtime_value_is_true);
            let on_platform = player
                .vars
                .get("onPlatform")
                .is_some_and(runtime_value_is_true);
            eprintln!(
                "[{platform_name}] tick {tick:>2}: player(y={:>8.3} vy={:>6.3} x={:>8.3}) plat(x={:>8.3} y={:>8.3} vy={:>5.2} yspeed={:?}) djump={djump} onPlatform={on_platform}",
                player.y,
                player.vspeed,
                player.x,
                platform.x,
                platform.y,
                platform.vspeed,
                platform.vars.get("yspeed"),
            );
            if djump && djump_restored_tick.is_none() {
                djump_restored_tick = Some(tick);
            }
        }

        assert!(
            djump_restored_tick.is_some(),
            "[{platform_name}] landing with spent djump should restore djump within 90 ticks; diagnostics={:?}",
            core.diagnostics().iter().rev().take(15).collect::<Vec<_>>()
        );
    }
}

#[test]
fn real_sample_player_standing_on_moving_platform_follows_platform() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let platform_room = real_sample_room_id(&core, "rMegaman01");
    core.reload_room(platform_room).unwrap();

    // Let room creation code assign the platform speed before placing the probe.
    for _ in 0..2 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    let platform_runtime_id = {
        let room = core.current_room.as_mut().unwrap();
        let platform = room
            .instances
            .iter()
            .find(|instance| instance.instance_id == 116826 && instance.alive)
            .cloned()
            .expect("rMegaman01 should include movingPlatform instance 116826");
        let player_template = room
            .instances
            .iter()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .cloned()
            .expect("rMegaman01 should include a live player");
        let solids = room
            .instances
            .iter()
            .filter(|instance| instance.alive && instance.solid)
            .cloned()
            .collect::<Vec<_>>();
        let mut player_position = None;
        let mut best_score = i32::MAX;
        for dy in -64i32..=64 {
            for dx in -64i32..=64 {
                let mut probe = player_template.clone();
                probe.x = platform.x + f64::from(dx);
                probe.y = platform.y + f64::from(dy);
                if !crate::helpers::collides_with_instance_at(
                    &platform,
                    platform.x,
                    platform.y - 2.0,
                    &probe,
                    Some(platform.runtime_id),
                    |_| true,
                ) {
                    continue;
                }
                if crate::helpers::collides_at(
                    &probe,
                    probe.x + platform.hspeed,
                    probe.y,
                    &solids,
                    Some(probe.runtime_id),
                ) {
                    continue;
                }
                let score = (dx - 8).abs() + (dy + 16).abs();
                if score < best_score {
                    best_score = score;
                    player_position = Some((probe.x, probe.y));
                }
            }
        }
        let (player_x, player_y) =
            player_position.expect("test setup should find a player position above movingPlatform");
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("rMegaman01 should include a live player");

        player.x = player_x;
        player.y = player_y;
        player.previous_x = player.x;
        player.previous_y = player.y;
        player.hspeed = 0.0;
        player.vspeed = 0.0;
        player
            .vars
            .insert("onPlatform".into(), RuntimeValue::Bool(false));

        platform.runtime_id
    };

    let before_player = real_sample_player(&core);
    let before_platform = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.runtime_id == platform_runtime_id && instance.alive)
        .cloned()
        .expect("tracked moving platform should still exist");
    let before_offset = before_player.x - before_platform.x;

    for _ in 0..6 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    let after_player = real_sample_player(&core);
    let after_platform = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.runtime_id == platform_runtime_id && instance.alive)
        .cloned()
        .expect("tracked moving platform should still exist after ticking");
    let platform_delta = after_platform.x - before_platform.x;
    let player_delta = after_player.x - before_player.x;
    let after_offset = after_player.x - after_platform.x;

    assert!(
        platform_delta > 0.0,
        "tracked moving platform should move right from its parsed creation hspeed; before={before_platform:?}, after={after_platform:?}, diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert!(
        player_delta > 0.0,
        "player standing on the moving platform should be carried by the parsed movingPlatform Step GML; before={before_player:?}, after={after_player:?}, platform_delta={platform_delta}, diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert!(
        (after_offset - before_offset).abs() <= 1.0,
        "player should keep roughly the same horizontal offset on the tracked moving platform; before_offset={before_offset}, after_offset={after_offset}, player_delta={player_delta}, platform_delta={platform_delta}"
    );
}

#[test]
fn real_sample_spent_double_jump_landing_on_platform_restores_air_jump() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let platform_room = real_sample_room_id(&core, "rMegaman01");
    core.reload_room(platform_room).unwrap();
    core.globals.insert(
        "global.jumpbutton".into(),
        RuntimeValue::Number(0x10 as f64),
    );

    {
        let room = core.current_room.as_mut().unwrap();
        let platform = room
            .instances
            .iter()
            .find(|instance| {
                instance.object_name.eq_ignore_ascii_case("platform") && instance.alive
            })
            .cloned()
            .expect("rMegaman01 should include a live platform");
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("rMegaman01 should include a live player");

        player.x = platform.x + 8.0;
        player.y = platform.y - 48.0;
        player.previous_x = player.x;
        player.previous_y = player.y;
        player.hspeed = 0.0;
        player.vspeed = 12.0;
        player
            .vars
            .insert("djump".into(), RuntimeValue::Bool(false));
        player
            .vars
            .insert("onPlatform".into(), RuntimeValue::Bool(false));
        player
            .vars
            .insert("gravity".into(), RuntimeValue::Number(0.0));
        player
            .vars
            .insert("maxFallSpeed".into(), RuntimeValue::Number(64.0));
    }

    for _ in 0..10 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
        let player = core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .unwrap();
        if player
            .vars
            .get("onPlatform")
            .is_some_and(runtime_value_is_true)
        {
            break;
        }
    }

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .unwrap();
    assert!(
        player
            .vars
            .get("onPlatform")
            .is_some_and(runtime_value_is_true),
        "landing on the real Dife platform should set onPlatform; player={:?}, diagnostics={:?}",
        player,
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
    assert!(
        player.vars.get("djump").is_some_and(runtime_value_is_true),
        "landing on the real Dife platform after spending double jump should restore djump; player={:?}, diagnostics={:?}",
        player,
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );

    let jump_key = match core.globals.get("global.jumpbutton") {
        Some(RuntimeValue::Number(value)) => *value as u16,
        _ => 0x10,
    };
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .unwrap();
        player.x = 160.0;
        player.previous_x = 160.0;
        player.hspeed = 0.0;
        player.vspeed = 0.0;
    }

    press_real_sample_key(&mut host, jump_key);
    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .unwrap();
    assert!(
        player.vspeed < 0.0,
        "walking off the platform after restored djump should allow the next air jump; player={:?}, diagnostics={:?}",
        player,
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn real_sample_block_landing_restores_spent_djump_for_walkoff_air_jump() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let platform_room = real_sample_room_id(&core, "rMegaman01");
    core.reload_room(platform_room).unwrap();
    core.globals.insert(
        "global.jumpbutton".into(),
        RuntimeValue::Number(0x10 as f64),
    );
    core.globals.insert(
        "global.leftbutton".into(),
        RuntimeValue::Number(0x25 as f64),
    );

    for _ in 0..2 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    // Ledge: blocks at (224..255, 192) between the wall columns at x=192/256.
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("rMegaman01 should include a live player");
        player.x = 232.0;
        player.y = 176.0;
        player.previous_x = player.x;
        player.previous_y = player.y;
        player.hspeed = 0.0;
        player.vspeed = 0.0;
        player
            .vars
            .insert("djump".into(), RuntimeValue::Bool(false));
        player
            .vars
            .insert("onPlatform".into(), RuntimeValue::Bool(false));
    }

    // Land on the block ledge and stand for a while.
    for tick in 0..12 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
        let player = real_sample_player(&core);
        eprintln!(
            "[block-land] tick {tick:>2}: y={:>8.3} vy={:>6.3} x={:>7.3} djump={} onPlatform={}",
            player.y,
            player.vspeed,
            player.x,
            player.vars.get("djump").is_some_and(runtime_value_is_true),
            player
                .vars
                .get("onPlatform")
                .is_some_and(runtime_value_is_true),
        );
    }
    let after_landing = real_sample_player(&core);
    let djump_after_block_landing = after_landing
        .vars
        .get("djump")
        .is_some_and(runtime_value_is_true);
    eprintln!(
        "[block-land] after standing: djump={djump_after_block_landing} y={} vy={}",
        after_landing.y, after_landing.vspeed
    );

    assert!(
        djump_after_block_landing,
        "landing on a solid block after spending the double jump must re-run the \
         block collision event and restore djump (GM8 refire while standing)"
    );

    // Leave the ground the way a walkoff does: airborne with djump untouched.
    // (rMegaman01's start ledges are boxed in by wall columns, so the probe
    // hops straight to the open shaft at x[96..127], y[320..415].)
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("player should still be alive");
        player.x = 112.0;
        player.y = 340.0;
        player.previous_x = player.x;
        player.previous_y = player.y;
        player.hspeed = 0.0;
        player.vspeed = 0.5;
    }
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    let before_jump = real_sample_player(&core);
    let djump_before_air_jump = before_jump
        .vars
        .get("djump")
        .is_some_and(runtime_value_is_true);
    eprintln!(
        "[airborne] y={:>8.3} vy={:>6.3} djump={djump_before_air_jump}",
        before_jump.y, before_jump.vspeed
    );
    assert!(
        before_jump.vspeed > 0.0,
        "player should be falling in the shaft; player=({}, {}, vy={})",
        before_jump.x,
        before_jump.y,
        before_jump.vspeed
    );
    assert!(
        djump_before_air_jump,
        "djump restored on the block must survive walking off into the air"
    );

    press_real_sample_key(&mut host, 0x10);
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    let player = real_sample_player(&core);
    eprintln!(
        "[air-jump] after jump press: y={:>8.3} vy={:>6.3} djump_now={}",
        player.y,
        player.vspeed,
        player.vars.get("djump").is_some_and(runtime_value_is_true),
    );
    assert!(
        player.vspeed < 0.0,
        "air jump after block-landing djump restore should fire; player=({}, {}, vy={})",
        player.x,
        player.y,
        player.vspeed
    );
    assert!(
        !player.vars.get("djump").is_some_and(runtime_value_is_true),
        "the air jump should consume djump"
    );
}

fn real_sample_player(core: &RuntimeCore) -> crate::RuntimeInstance {
    core.current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .cloned()
        .expect("live player should exist")
}

fn real_sample_sprite_id(core: &RuntimeCore, name: &str) -> f64 {
    core.package
        .resources
        .sprites
        .iter()
        .find(|sprite| sprite.name.eq_ignore_ascii_case(name))
        .map(|sprite| sprite.id as f64)
        .unwrap_or_else(|| panic!("sample package should include sprite {name}"))
}

fn real_sample_player_animation_value(core: &RuntimeCore, key: &str) -> f64 {
    real_sample_player(core)
        .vars
        .get(key)
        .and_then(|value| match value {
            RuntimeValue::Number(number) => Some(*number),
            _ => None,
        })
        .unwrap_or_else(|| panic!("live player should expose numeric {key}"))
}

fn real_sample_bound_key(core: &RuntimeCore, key: &str, fallback: u16) -> u16 {
    core.globals
        .get(key)
        .and_then(|value| match value {
            RuntimeValue::Number(number) => Some(*number as u16),
            _ => None,
        })
        .unwrap_or(fallback)
}

fn enter_real_sample_animation_room(core: &mut RuntimeCore, host: &mut HeadlessHost) {
    select_real_sample_medium_difficulty(core, host);
    core.reload_room(143).unwrap();
}

#[test]
fn real_sample_player_uses_running_sprite_animation() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    enter_real_sample_animation_room(&mut core, &mut host);
    let running_sprite = real_sample_sprite_id(&core, "sprPlayerRunning");
    let right_key = real_sample_bound_key(&core, "global.rightbutton", 0x27);

    press_real_sample_key(&mut host, right_key);
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    let first_frame = real_sample_player_animation_value(&core, "image_index");

    assert_eq!(
        real_sample_player_animation_value(&core, "sprite_index"),
        running_sprite
    );
    assert_eq!(
        real_sample_player_animation_value(&core, "image_speed"),
        0.5
    );

    core.tick(&mut host).unwrap();
    let second_frame = real_sample_player_animation_value(&core, "image_index");
    assert_ne!(second_frame, first_frame);
}

#[test]
fn real_sample_player_uses_jump_and_fall_sprite_animation() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    enter_real_sample_animation_room(&mut core, &mut host);
    let jump_sprite = real_sample_sprite_id(&core, "sprPlayerJump");
    let fall_sprite = real_sample_sprite_id(&core, "sprPlayerFall");
    let jump_key = real_sample_bound_key(&core, "global.jumpbutton", 0x10);

    press_real_sample_key(&mut host, jump_key);
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    core.tick(&mut host).unwrap();
    let jump_frame = real_sample_player_animation_value(&core, "image_index");
    let jumping_player = real_sample_player(&core);
    assert!(jumping_player.vspeed < -0.05);
    assert_eq!(
        real_sample_player_animation_value(&core, "sprite_index"),
        jump_sprite
    );

    core.tick(&mut host).unwrap();
    assert_ne!(
        real_sample_player_animation_value(&core, "image_index"),
        jump_frame
    );

    release_real_sample_key(&mut host, jump_key);
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    for _ in 0..120 {
        if real_sample_player(&core).vspeed > 0.05
            && real_sample_player_animation_value(&core, "sprite_index") == fall_sprite
        {
            break;
        }
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    let falling_player = real_sample_player(&core);
    assert!(falling_player.vspeed > 0.05);
    assert_eq!(
        real_sample_player_animation_value(&core, "sprite_index"),
        fall_sprite
    );
    let fall_frame = real_sample_player_animation_value(&core, "image_index");
    core.tick(&mut host).unwrap();
    assert_ne!(
        real_sample_player_animation_value(&core, "image_index"),
        fall_frame
    );
}

fn release_real_sample_key(host: &mut HeadlessHost, key: u16) {
    host.input.set_button_state(
        RuntimeButton::Keyboard(key),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: true,
        },
    );
}

fn press_real_sample_key(host: &mut HeadlessHost, key: u16) {
    host.input.set_button_state(
        RuntimeButton::Keyboard(key),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
}

fn sample_save_bytes(room_id: u16, x: u16, y: u16) -> Vec<u8> {
    let mut bytes = Vec::new();
    for value in [room_id, x, y] {
        bytes.push((value / 10000) as u8);
        bytes.push(((value % 10000) / 100) as u8);
        bytes.push((value % 100) as u8);
    }
    bytes.push(0); // difficulty
    bytes.push(0); // grav
    bytes.extend(std::iter::repeat(0).take(16)); // boss flags
    bytes.push(0); // clear
    bytes.extend(std::iter::repeat(0).take(8)); // item flags
    bytes.push(0); // ble
    bytes.push(0); // music
    bytes
}

#[test]
fn real_sample_room147_s_key_savepoint_respawns_at_activated_position() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    select_real_sample_medium_difficulty(&mut core, &mut host);
    let activated_runtime_id = move_real_sample_player_onto_savepoint_at(&mut core, 864.0, 1120.0);

    press_real_sample_key(&mut host, 0x53);
    core.tick(&mut host).unwrap();

    let room = core.current_room().unwrap();
    assert!(
        !room.instances.iter().any(|instance| {
            instance.runtime_id == activated_runtime_id
                && instance.object_name.eq_ignore_ascii_case("savePoint")
                && instance.alive
        }),
        "activated savePoint should be destroyed while its feedback/helper animation runs"
    );
    assert!(
        room.instances.iter().any(|instance| instance
            .object_name
            .eq_ignore_ascii_case("object819")
            && instance.alive
            && instance.x == 864.0
            && instance.y == 1120.0),
        "respawn helper should be created at the activated savePoint position"
    );
    let view = room.views.iter().find(|view| view.visible).unwrap();
    assert!(
        room.instances.iter().any(|instance| {
            instance.object_name.eq_ignore_ascii_case("object808")
                && instance.alive
                && instance.x == view.source_x as f64
                && instance.y == view.source_y as f64
        }),
        "white-flash overlay should be created at the active view origin"
    );
    assert!(
        host.renderer
            .submitted_frames
            .last()
            .unwrap()
            .commands
            .iter()
            .any(|command| matches!(
                command,
                iwm_runtime_host::RuntimeDrawCommand::DrawSprite {
                    sprite_id: 524,
                    x: 0,
                    y: 0,
                    alpha,
                    ..
                } if *alpha > 0.0
            )),
        "white-flash sprite should cover the active canvas"
    );

    release_real_sample_key(&mut host, 0x53);
    for _ in 0..81 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    let room = core.current_room().unwrap();
    assert!(
        room.instances.iter().any(|instance| {
            instance.runtime_id != activated_runtime_id
                && instance.object_name.eq_ignore_ascii_case("savePoint")
                && instance.alive
                && instance.x == 864.0
                && instance.y == 1120.0
        }),
        "a new live savePoint should reappear at the activated position; difficulty={:?}, matching instances={:?}, recent diagnostics={:?}",
        core.globals.get("global.difficulty"),
        room.instances
            .iter()
            .filter(|instance| instance.object_name.eq_ignore_ascii_case("savePoint")
                && instance.x == 864.0
                && instance.y == 1120.0)
            .map(|instance| (instance.runtime_id, instance.alive, instance.vars.get("saveTimer")))
            .collect::<Vec<_>>(),
        core.diagnostics().iter().rev().take(20).collect::<Vec<_>>()
    );
}

#[test]
fn real_sample_s_key_savepoint_writes_save_file_and_spawns_feedback() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core.snapshot().input_trace.jump_button_key == 0x10 {
            break;
        }
        host.input.clear_transitions();
    }
    assert_eq!(core.snapshot().input_trace.jump_button_key, 0x10);

    select_real_sample_medium_difficulty(&mut core, &mut host);
    core.reload_room(143).unwrap();
    move_real_sample_player_onto_savepoint(&mut core);

    press_real_sample_key(&mut host, 0x53);
    core.tick(&mut host).unwrap();

    let save_bytes = host
        .files
        .read(Path::new("save1"))
        .expect("S savepoint should write save1");
    assert!(
        save_bytes.len() >= 10,
        "save1 should contain room/player/difficulty bytes, got {save_bytes:?}"
    );

    let room = core.current_room().unwrap();
    for expected in ["object808", "object809", "object819"] {
        assert!(
            room.instances
                .iter()
                .any(|instance| instance.object_name.eq_ignore_ascii_case(expected)),
            "save feedback should create {expected}"
        );
    }
    assert!(
        !room
            .instances
            .iter()
            .any(
                |instance| instance.object_name.eq_ignore_ascii_case("savePoint") && instance.alive
            ),
        "activated savePoint should be hidden until its respawn helper fires"
    );
    let initial_bubbles = room
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("object809") && instance.alive)
        .map(|instance| (instance.runtime_id, instance.x, instance.y))
        .collect::<Vec<_>>();
    assert_eq!(initial_bubbles.len(), 7);

    release_real_sample_key(&mut host, 0x53);
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();

    let room = core.current_room().unwrap();
    let stepped_bubbles = room
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("object809") && instance.alive)
        .collect::<Vec<_>>();
    assert_eq!(stepped_bubbles.len(), 7);
    assert!(stepped_bubbles.iter().all(|instance| {
        instance
            .vars
            .get("image_alpha")
            .and_then(crate::helpers::as_number)
            .is_some_and(|alpha| (alpha - 0.98).abs() < 1e-9)
    }));
    assert!(stepped_bubbles.iter().any(|instance| {
        initial_bubbles.iter().any(|(runtime_id, x, y)| {
            *runtime_id == instance.runtime_id && (*x != instance.x || *y != instance.y)
        })
    }));

    for _ in 0..80 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }

    let room = core.current_room().unwrap();
    assert!(
        room.instances
            .iter()
            .any(
                |instance| instance.object_name.eq_ignore_ascii_case("savePoint") && instance.alive
            ),
        "savePoint should reappear after package-owned alarm helper recreates object id 5"
    );
    assert!(
        !room
            .instances
            .iter()
            .any(
                |instance| instance.object_name.eq_ignore_ascii_case("object819") && instance.alive
            ),
        "respawn helper should destroy itself after recreating savePoint"
    );
    assert!(
        core.diagnostics().iter().all(|diagnostic| {
            diagnostic.code != "runtime-unsupported-function"
                && diagnostic.code != "runtime-unsupported-expression"
        }),
        "savepoint path should not emit unsupported runtime diagnostics: {:?}",
        core.diagnostics()
    );
}

#[test]
fn real_sample_r_load_after_s_save_restores_saved_player_position() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    select_real_sample_medium_difficulty(&mut core, &mut host);
    core.reload_room(143).unwrap();
    move_real_sample_player_onto_savepoint(&mut core);
    let saved_position = core
        .snapshot()
        .player
        .as_ref()
        .map(|player| (player.x, player.y))
        .expect("test setup should have a player before saving");

    press_real_sample_key(&mut host, 0x53);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x53);
    host.input.clear_transitions();
    assert_eq!(
        core.globals.get("global.grav"),
        Some(&RuntimeValue::Number(0.0)),
        "S save should not mutate global.grav before restart; save1={:?}",
        host.files.read(Path::new("save1"))
    );

    press_real_sample_key(&mut host, 0x52);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x52);

    let snapshot = core.snapshot();
    let player = snapshot
        .player
        .as_ref()
        .expect("R load should leave a live player");
    assert_eq!(snapshot.room_id, Some(143));
    assert_eq!(
        (player.x, player.y),
        saved_position,
        "R load should restore the exact saved position; room={:?}, difficulty={:?}, grav={:?}, save1={:?}, live players={:?}, recent diagnostics={:?}",
        core.snapshot().room_id,
        core.globals.get("global.difficulty"),
        core.globals.get("global.grav"),
        host.files.read(Path::new("save1")),
        core.current_room()
            .unwrap()
            .instances
            .iter()
            .filter(|instance| crate::helpers::is_player_instance(instance))
            .map(|instance| (instance.object_name.clone(), instance.runtime_id, instance.alive, instance.x, instance.y))
            .collect::<Vec<_>>(),
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn real_sample_r_load_after_s_save_keeps_shift_jump_bound() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    select_real_sample_medium_difficulty(&mut core, &mut host);
    core.reload_room(143).unwrap();
    move_real_sample_player_onto_savepoint(&mut core);

    press_real_sample_key(&mut host, 0x53);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x53);
    host.input.clear_transitions();

    press_real_sample_key(&mut host, 0x52);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x52);
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();

    for _ in 0..180 {
        core.tick(&mut host).unwrap();
        if core
            .snapshot()
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false)
        {
            break;
        }
    }
    assert!(
        core.snapshot()
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false),
        "R load should leave the player able to land before testing jump; room={:?}; players={:?}",
        core.snapshot().room_id,
        core.current_room()
            .unwrap()
            .instances
            .iter()
            .filter(|instance| crate::helpers::is_player_instance(instance))
            .map(|instance| (
                instance.runtime_id,
                instance.instance_id,
                instance.alive,
                instance.x,
                instance.y,
                instance.vspeed,
                instance.vars.clone()
            ))
            .collect::<Vec<_>>()
    );

    press_real_sample_key(&mut host, 0x10);
    core.tick(&mut host).unwrap();

    let snapshot = core.snapshot();
    let player = snapshot
        .player
        .as_ref()
        .expect("R load should leave a live player");
    assert_eq!(
        snapshot.input_trace.jump_button_key, 0x10,
        "R load should preserve the sample's Shift jump binding; globals={:?}",
        core.globals
    );
    assert!(
        snapshot.input_trace.jump_just_pressed,
        "Shift should be observed as the jump edge after R load; trace={:?}",
        snapshot.input_trace
    );
    assert!(
        player.vspeed < 0.0,
        "Shift after R load should produce upward vspeed, got {}; player={:?}; players={:?}",
        player.vspeed,
        player,
        core.current_room()
            .unwrap()
            .instances
            .iter()
            .filter(|instance| crate::helpers::is_player_instance(instance))
            .map(|instance| (
                instance.runtime_id,
                instance.instance_id,
                instance.alive,
                instance.x,
                instance.y,
                instance.vspeed,
                instance.vars.clone()
            ))
            .collect::<Vec<_>>()
    );
}

#[test]
fn real_sample_death_feedback_waits_for_reset_before_room_reload() {
    let Some(package) = real_sample_package() else {
        return;
    };
    let snd_death_id = package
        .resources
        .sounds
        .iter()
        .find(|sound| sound.name.eq_ignore_ascii_case("sndDeath"))
        .map(|sound| sound.id as i32)
        .expect("sample package should include sndDeath");

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    for _ in 0..2 {
        core.tick(&mut host).unwrap();
        host.input.clear_transitions();
    }
    core.reload_room(151).unwrap();
    core.render(&mut host).unwrap();

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x27),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    for _ in 0..90 {
        core.tick(&mut host).unwrap();
        host.input.set_button_state(
            RuntimeButton::Keyboard(0x27),
            ButtonState {
                pressed: true,
                just_pressed: false,
                just_released: false,
            },
        );
        if core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .any(|instance| instance.object_name.eq_ignore_ascii_case("GAMEOVER") && instance.alive)
        {
            break;
        }
    }

    let room = core.current_room().unwrap();
    assert_eq!(room.room_id, 151);
    assert!(
        room.instances.iter().any(
            |instance| instance.object_name.eq_ignore_ascii_case("GAMEOVER") && instance.alive
        ),
        "expected GAMEOVER after death, snapshot={:?}, live player={:?}, recent diagnostics={:?}",
        core.snapshot().player,
        room.instances
            .iter()
            .find(|instance| crate::helpers::is_player_instance(instance))
            .map(|instance| (
                instance.x,
                instance.y,
                instance.hspeed,
                instance.vspeed,
                instance.alive
            )),
        core.diagnostics().iter().rev().take(8).collect::<Vec<_>>()
    );
    assert!(
        host.audio
            .played
            .contains(&(snd_death_id, iwm_runtime_host::RuntimeSoundMode::Once)),
        "expected sndDeath id {snd_death_id}, played sounds: {:?}",
        host.audio.played
    );
    assert!(room.instances.iter().any(|instance| {
        instance.object_name.eq_ignore_ascii_case("bloodEmitter2") && instance.alive
    }));
    assert!(!room
        .instances
        .iter()
        .any(|instance| crate::helpers::is_player_instance(instance) && instance.alive));

    host.input.clear_transitions();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x27),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: false,
        },
    );
    let mut first_blood = None;
    for _ in 0..12 {
        core.tick(&mut host).unwrap();
        first_blood = core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("blood2") && instance.alive)
            .cloned();
        if first_blood.is_some() {
            break;
        }
    }
    let first_blood = first_blood.expect("expected blood2 particles after bloodEmitter2 step");
    core.tick(&mut host).unwrap();
    let blood_after_motion = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.runtime_id == first_blood.runtime_id)
        .cloned()
        .expect("expected blood2 particle to remain addressable after one tick");
    assert!(
        blood_after_motion.x != first_blood.x
            || blood_after_motion.y != first_blood.y
            || !blood_after_motion.alive,
        "blood2 should move or collide after spawn, before={:?}, after={:?}",
        (
            first_blood.x,
            first_blood.y,
            first_blood.hspeed,
            first_blood.vspeed
        ),
        (
            blood_after_motion.x,
            blood_after_motion.y,
            blood_after_motion.hspeed,
            blood_after_motion.vspeed,
            blood_after_motion.alive
        )
    );
    for _ in 0..3 {
        core.tick(&mut host).unwrap();
    }
    assert_eq!(core.snapshot().room_id, Some(151));

    let reset_key = 0x74;
    core.globals.insert(
        "global.restartbutton".into(),
        RuntimeValue::Number(reset_key as f64),
    );
    host.input.set_button_state(
        RuntimeButton::Keyboard(reset_key),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.tick(&mut host).unwrap();

    let room = core.current_room().unwrap();
    assert_eq!(room.room_id, 151);
    assert!(room
        .instances
        .iter()
        .any(|instance| crate::helpers::is_player_instance(instance) && instance.alive));
    assert!(!room
        .instances
        .iter()
        .any(|instance| instance.object_name.eq_ignore_ascii_case("GAMEOVER") && instance.alive));
    assert!(!room.instances.iter().any(|instance| {
        instance.object_name.eq_ignore_ascii_case("bloodEmitter2") && instance.alive
    }));
}

#[test]
fn real_sample_second_shift_press_after_manual_room_reload_uses_player_jump() {
    let Some(mut package) = real_sample_package() else {
        return;
    };

    if let Some(lowered) = package.lowered_logic.as_mut() {
        if let Some(step_entry) = lowered
            .entries
            .iter_mut()
            .find(|entry| entry.block_id == "object:0:event:3:0")
        {
            step_entry.statements.insert(
                0,
                LoweredLogicStatement::Conditional {
                    condition: LoweredLogicExpr::Call {
                        name: "keyboard_check_pressed".into(),
                        args: vec![LoweredLogicExpr::MemberAccess {
                            target: Box::new(LoweredLogicExpr::Identifier("global".into())),
                            member: "jumpbutton".into(),
                        }],
                    },
                    then_branch: vec![LoweredLogicStatement::Assignment {
                        target: LoweredLogicExpr::Identifier("debug_step_jump_pressed".into()),
                        value: LoweredLogicExpr::LiteralBool(true),
                    }],
                    else_branch: vec![],
                },
            );
        }

        if let Some(player_jump_entry) = lowered
            .entries
            .iter_mut()
            .find(|entry| entry.block_id == "script:11")
        {
            player_jump_entry.statements.insert(
                0,
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("debug_player_jump_called".into()),
                    value: LoweredLogicExpr::LiteralBool(true),
                },
            );
            player_jump_entry.statements.insert(
                1,
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("debug_ground_block".into()),
                    value: LoweredLogicExpr::Call {
                        name: "place_meeting".into(),
                        args: vec![
                            LoweredLogicExpr::Identifier("x".into()),
                            LoweredLogicExpr::BinaryExpr {
                                op: "+".into(),
                                left: Box::new(LoweredLogicExpr::Identifier("y".into())),
                                right: Box::new(LoweredLogicExpr::LiteralNumber(1.0)),
                            },
                            LoweredLogicExpr::Identifier("block".into()),
                        ],
                    },
                },
            );
            player_jump_entry.statements.insert(
                2,
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("debug_ground_branch_taken".into()),
                    value: LoweredLogicExpr::LiteralBool(false),
                },
            );
            if let Some(LoweredLogicStatement::Conditional { then_branch, .. }) =
                player_jump_entry.statements.get_mut(3)
            {
                if let Some(LoweredLogicStatement::ConditionalChain { branches, .. }) =
                    then_branch.get_mut(0)
                {
                    branches
                        .first_mut()
                        .expect("playerJump ground branch should exist")
                        .body
                        .insert(
                            0,
                            LoweredLogicStatement::Assignment {
                                target: LoweredLogicExpr::Identifier(
                                    "debug_ground_branch_taken".into(),
                                ),
                                value: LoweredLogicExpr::LiteralBool(true),
                            },
                        );
                }
            }
        }
    }

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core.snapshot().input_trace.jump_button_key == 0x10 {
            break;
        }
    }
    assert_eq!(core.snapshot().input_trace.jump_button_key, 0x10);

    core.reload_room(143).unwrap();

    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        let snapshot = core.snapshot();
        if snapshot
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false)
        {
            break;
        }
    }
    assert!(core
        .snapshot()
        .player
        .as_ref()
        .map(|player| player.jump.grounded)
        .unwrap_or(false));

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x10),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.tick(&mut host).unwrap();

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x10),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: true,
        },
    );
    core.tick(&mut host).unwrap();

    host.input.clear_transitions();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x10),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: false,
        },
    );
    for _ in 0..180 {
        core.tick(&mut host).unwrap();
        if core
            .snapshot()
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false)
        {
            break;
        }
    }

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x10),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.tick(&mut host).unwrap();

    let after_second = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| crate::helpers::is_player_instance(instance))
        .unwrap();

    assert_eq!(
        core.globals.get("global.grav"),
        Some(&RuntimeValue::Number(0.0))
    );
    assert_eq!(
        after_second.vars.get("debug_step_jump_pressed"),
        Some(&RuntimeValue::Bool(true))
    );
    assert_eq!(
        after_second.vars.get("debug_player_jump_called"),
        Some(&RuntimeValue::Bool(true))
    );
    assert_eq!(
        after_second.vars.get("debug_ground_block"),
        Some(&RuntimeValue::Bool(true))
    );
    assert_eq!(
        after_second.vars.get("debug_ground_branch_taken"),
        Some(&RuntimeValue::Bool(true))
    );
    assert!(
        after_second.vspeed < 0.0,
        "second jump should produce upward vspeed once bootstrap globals exist, got {:?}",
        after_second.vspeed
    );
}
#[test]
fn real_sample_step_events_alone_show_second_shift_playerjump_effect() {
    let Some(mut package) = real_sample_package() else {
        return;
    };

    if let Some(lowered) = package.lowered_logic.as_mut() {
        if let Some(player_jump_entry) = lowered
            .entries
            .iter_mut()
            .find(|entry| entry.block_id == "script:11")
        {
            player_jump_entry.statements.insert(
                0,
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("debug_player_jump_called".into()),
                    value: LoweredLogicExpr::LiteralBool(true),
                },
            );
        }
    }

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core.snapshot().input_trace.jump_button_key == 0x10 {
            break;
        }
    }
    assert_eq!(core.snapshot().input_trace.jump_button_key, 0x10);

    core.reload_room(143).unwrap();
    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core
            .snapshot()
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false)
        {
            break;
        }
    }

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x10),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.execute_lowered_step_events(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| crate::helpers::is_player_instance(instance))
        .unwrap();

    assert_eq!(
        player.vars.get("debug_player_jump_called"),
        Some(&RuntimeValue::Bool(true))
    );
    assert!(
        player.vspeed < 0.0,
        "step events alone should apply upward jump velocity, got {:?}",
        player.vspeed
    );
}

#[test]
fn real_sample_step_events_spawn_bullet_and_play_shoot_sound_on_z_press() {
    let Some(package) = real_sample_package() else {
        return;
    };

    let shoot_sound_id = package
        .resources
        .sounds
        .iter()
        .find(|sound| sound.name.eq_ignore_ascii_case("sndShoot"))
        .map(|sound| sound.id as i32)
        .expect("sample package should include sndShoot");

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core.snapshot().input_trace.jump_button_key == 0x10 {
            break;
        }
    }
    assert_eq!(core.snapshot().input_trace.jump_button_key, 0x10);
    assert_eq!(
        core.globals.get("global.shotbutton"),
        Some(&RuntimeValue::Number(0x5A as f64))
    );

    core.reload_room(143).unwrap();
    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core
            .snapshot()
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false)
        {
            break;
        }
    }

    let bullet_count_before = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("bullet"))
        .count();

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x5A),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.execute_lowered_step_events(&mut host).unwrap();

    let bullet_count_after = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("bullet"))
        .count();

    assert_eq!(
        bullet_count_after,
        bullet_count_before + 1,
        "Z press should spawn one bullet instance"
    );
    assert!(
        host.audio
            .played
            .contains(&(shoot_sound_id, iwm_runtime_host::RuntimeSoundMode::Once)),
        "Z press should dispatch sndShoot once, got {:?}",
        host.audio.played
    );
}

#[test]
fn real_sample_spawned_bullet_moves_and_can_see_forward_block_collision() {
    let Some(mut package) = real_sample_package() else {
        return;
    };

    if let Some(lowered) = package.lowered_logic.as_mut() {
        if let Some(bullet_step_entry) = lowered
            .entries
            .iter_mut()
            .find(|entry| entry.block_id == "object:2:event:3:0")
        {
            bullet_step_entry.statements.insert(
                0,
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("debug_forward_block".into()),
                    value: LoweredLogicExpr::Call {
                        name: "place_meeting".into(),
                        args: vec![
                            LoweredLogicExpr::BinaryExpr {
                                op: "+".into(),
                                left: Box::new(LoweredLogicExpr::Identifier("x".into())),
                                right: Box::new(LoweredLogicExpr::Identifier("hspeed".into())),
                            },
                            LoweredLogicExpr::Identifier("y".into()),
                            LoweredLogicExpr::Identifier("block".into()),
                        ],
                    },
                },
            );
        }
    }

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core.snapshot().input_trace.jump_button_key == 0x10 {
            break;
        }
    }

    core.reload_room(143).unwrap();
    for _ in 0..120 {
        core.tick(&mut host).unwrap();
        if core
            .snapshot()
            .player
            .as_ref()
            .map(|player| player.jump.grounded)
            .unwrap_or(false)
        {
            break;
        }
    }

    host.input.set_button_state(
        RuntimeButton::Keyboard(0x5A),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x5A),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: false,
        },
    );

    let bullet_after_spawn = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("bullet"))
        .cloned()
        .expect("expected spawned bullet");

    core.tick(&mut host).unwrap();

    let bullet_after_step = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.runtime_id == bullet_after_spawn.runtime_id)
        .cloned()
        .expect("expected bullet after step");

    let room = core.current_room().unwrap();
    let player_like = room
        .instances
        .iter()
        .filter(|instance| {
            instance.object_name.eq_ignore_ascii_case("player")
                || instance.object_name.eq_ignore_ascii_case("player2")
        })
        .map(|instance| {
            (
                instance.object_name.clone(),
                instance.alive,
                instance.vars.get("image_xscale").cloned(),
                instance.x,
                instance.y,
            )
        })
        .collect::<Vec<_>>();

    assert_eq!(
        bullet_after_spawn.hspeed.abs(),
        16.0,
        "spawned bullet should inherit 16px horizontal speed, bullet={:?}, players={:?}",
        (
            bullet_after_spawn.runtime_id,
            bullet_after_spawn.x,
            bullet_after_spawn.y,
            bullet_after_spawn.hspeed,
            bullet_after_spawn.vars.clone()
        ),
        player_like
    );
    assert!(
        bullet_after_step.x != bullet_after_spawn.x || !bullet_after_step.alive,
        "bullet should either move or destroy itself after step, spawn={:?} step={:?}",
        (
            bullet_after_spawn.x,
            bullet_after_spawn.y,
            bullet_after_spawn.hspeed,
            bullet_after_spawn.alive
        ),
        (
            bullet_after_step.x,
            bullet_after_step.y,
            bullet_after_step.hspeed,
            bullet_after_step.alive
        )
    );
}

/// Kamilia's `global_init()` writes `IWRTK_globaldata` with `file_text_*` and then
/// replays it with `execute_file()`. Both halves used to be unsupported, so the
/// whole save-data chain silently did nothing.
#[test]
fn kamilia_global_init_writes_and_replays_globaldata_through_the_file_host() {
    let Some(package) = local_sample_package("gm8-core/I Wanna Kill the Kamilia Ver. Final") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(34).unwrap();
    let mut host = HeadlessHost::new("sandbox");

    core.tick(&mut host).unwrap();

    let globaldata = host
        .files
        .read(Path::new("IWRTK_globaldata"))
        .expect("global_init() should have written IWRTK_globaldata through the file host");
    let globaldata = String::from_utf8(globaldata).expect("globaldata is GML text");
    assert!(globaldata.contains("musicOn = 1"), "{globaldata}");

    assert!(
        core.diagnostics().iter().any(|diagnostic| {
            diagnostic.code == "runtime-execute-source"
                && diagnostic.message.contains("source=IWRTK_globaldata")
        }),
        "execute_file() should have replayed the written globaldata: {:?}",
        core.diagnostics()
    );

    let world = core
        .current_room
        .as_ref()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("world") && instance.alive)
        .expect("world should be live");
    assert_eq!(world.vars.get("musicOn"), Some(&RuntimeValue::Number(1.0)));

    assert!(
        !core.diagnostics().iter().any(|diagnostic| {
            diagnostic.code == "runtime-unsupported-function"
                && (diagnostic.message.contains("file_text_")
                    || diagnostic.message.contains("execute_file"))
        }),
        "save chain should no longer report unsupported functions: {:?}",
        core.diagnostics()
    );
}

/// The reported bug: shooting a SavePoint recolours it but `R` sent the player
/// back to the start. `loadgame()` re-executes the save file, so with the text
/// slice missing `file_exists()` was false and it fell through to
/// `room_goto(beginning)`. This drives the real `world` Step `R` handler against a
/// save file in `savegame()`'s exact format.
#[test]
fn kamilia_restart_key_restores_the_saved_position_through_execute_file() {
    let Some(package) = local_sample_package("gm8-core/I Wanna Kill the Kamilia Ver. Final") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(34).unwrap();
    let mut host = HeadlessHost::new("sandbox");
    core.tick(&mut host).unwrap();

    let mut saved = String::from(
        "room_goto(testRoom);\r\n\
         if !instance_exists(player) instance_create(0,0,player);\r\n\
         player.x = 199\r\n\
         player.y = 486\r\n\
         difficulty = 2\r\n",
    );
    for index in 0..16 {
        saved.push_str(&format!("bosses[{index}] = 0\r\n"));
    }
    host.files
        .write_temp(Path::new("IWRTK_save0"), saved.as_bytes())
        .unwrap();

    // Walk the player off the saved spot so a restore is observable.
    {
        let player = core
            .current_room
            .as_mut()
            .unwrap()
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("testRoom should have a live player");
        player.x = 32.0;
        player.y = 64.0;
    }

    press_real_sample_key(&mut host, 0x52); // world.gameRestart == ord("R")
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x52);

    assert_eq!(
        core.current_room.as_ref().unwrap().room_id,
        34,
        "loadgame() should stay in the saved room instead of jumping to beginning"
    );
    let player = core
        .current_room
        .as_ref()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .expect("player should exist after loadgame");
    assert_eq!((player.x, player.y), (199.0, 486.0));
}

/// Same restore, reached the way a player reaches it: through the title/load
/// menu, so `world` and `player` arrive in testRoom as carried persistent
/// instances. That path also has to survive `testRoom`'s `playerSpawn` object,
/// whose Create spawns a player when none exists.
#[test]
fn kamilia_restart_after_menu_path_keeps_the_restored_player_instance() {
    let Some(package) = local_sample_package("gm8-core/I Wanna Kill the Kamilia Ver. Final") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = HeadlessHost::new("sandbox");
    for _ in 0..3 {
        core.tick(&mut host).unwrap();
    }
    // room69 -> "S" -> room0 -> Shift -> ... -> testRoom
    press_real_sample_key(&mut host, 0x53);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x53);
    for _ in 0..5 {
        core.tick(&mut host).unwrap();
    }
    press_real_sample_key(&mut host, 0x10);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x10);
    for _ in 0..10 {
        core.tick(&mut host).unwrap();
    }
    assert_eq!(core.current_room.as_ref().unwrap().room_id, 34);

    let mut saved = String::from(
        "room_goto(testRoom);\r\n\
         if !instance_exists(player) instance_create(0,0,player);\r\n\
         player.x = 393\r\n\
         player.y = 567\r\n\
         difficulty = 1\r\n",
    );
    for index in 0..16 {
        saved.push_str(&format!("bosses[{index}] = 0\r\n"));
    }
    host.files
        .write_temp(Path::new("IWRTK_save0"), saved.as_bytes())
        .unwrap();

    let saved_instance_id = {
        let player = core
            .current_room
            .as_mut()
            .unwrap()
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("testRoom should have a live player");
        player.x = 200.0;
        player.y = 500.0;
        player.instance_id
    };

    press_real_sample_key(&mut host, 0x52);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x52);

    let room = core.current_room.as_ref().unwrap();
    assert_eq!(room.room_id, 34);
    let players = room
        .instances
        .iter()
        .filter(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .collect::<Vec<_>>();
    assert_eq!(players.len(), 1, "playerSpawn must not add a second player");
    assert_eq!((players[0].x, players[0].y), (393.0, 567.0));
    assert_eq!(
        players[0].instance_id, saved_instance_id,
        "the carried player instance should survive the transition"
    );
}

/// The reported scenario end to end: shoot a SavePoint, walk away, press `R`.
///
/// The SavePoint's bullet-collision event runs
/// `with(world) { savegame(savenum); writeDeaths(); }`, and `R` runs
/// `loadgame(savenum)`, which replays the written GML through `execute_file()`.
#[test]
fn kamilia_shooting_a_savepoint_then_restarting_returns_to_it() {
    let Some(package) = local_sample_package("gm8-core/I Wanna Kill the Kamilia Ver. Final") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(34).unwrap();
    let mut host = HeadlessHost::new("sandbox");
    core.tick(&mut host).unwrap();

    // Park the player somewhere recognisable, then put a bullet on the SavePoint.
    let (save_x, save_y) = {
        let room = core.current_room.as_mut().unwrap();
        let (save_x, save_y) = room
            .instances
            .iter()
            .find(|instance| {
                instance.object_name.eq_ignore_ascii_case("SavePoint") && instance.alive
            })
            .map(|instance| (instance.x, instance.y))
            .expect("testRoom should contain a SavePoint");
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .expect("testRoom should have a live player");
        player.x = 264.0;
        player.y = 567.0;
        (save_x, save_y)
    };

    // Offset into the SavePoint's mask, and give the bullet a few ticks so the
    // collision pass sees it.
    let runtime_id = core.current_room.as_ref().unwrap().instances.len();
    let bullet = core
        .instantiate_runtime_object(6, runtime_id, 900_001, save_x + 8.0, save_y + 8.0)
        .expect("bullet object should instantiate");
    core.current_room.as_mut().unwrap().instances.push(bullet);

    for _ in 0..4 {
        core.tick(&mut host).unwrap();
    }

    let saved = String::from_utf8(host.files.read(Path::new("IWRTK_save0")).unwrap()).unwrap();
    assert!(
        saved.contains("room_goto(testRoom)"),
        "the save should point at the room the SavePoint was shot in: {saved}"
    );
    assert!(
        saved.contains("player.x = 264"),
        "the save should carry the player position at save time: {saved}"
    );
    assert!(
        host.files.read(Path::new("IWRTK_globaldata")).is_ok(),
        "writeDeaths() should also have flushed globaldata"
    );

    // Walk away, then press "R".
    {
        let player = core
            .current_room
            .as_mut()
            .unwrap()
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
            .unwrap();
        player.x = 64.0;
        player.y = 567.0;
    }
    press_real_sample_key(&mut host, 0x52);
    core.tick(&mut host).unwrap();
    release_real_sample_key(&mut host, 0x52);

    let room = core.current_room.as_ref().unwrap();
    assert_eq!(room.room_id, 34);
    let player = room
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player") && instance.alive)
        .expect("player should exist after loadgame");
    assert_eq!(
        (player.x, player.y),
        (264.0, 567.0),
        "R should return to the shot SavePoint, not the room start"
    );
}

#[test]
fn orbit_freetrigger_scaled_zone_fires_collision_event() {
    let Some(package) = local_sample_package("gm8-core/28_I wanna be the Orbit") else {
        return;
    };
    // freetrigger 164922 uses creation code
    // `trg=8; image_yscale=4;` -> GM8 collider spans y 224..352, while a
    // scale-1 bbox would only cover y 224..256.
    let place_player = |core: &mut RuntimeCore, x: f64, y: f64| {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
            .expect("room should include the player");
        player.x = x;
        player.y = y;
        player.previous_x = x;
        player.previous_y = y;
        player.hspeed = 0.0;
        player.vspeed = 0.0;
    };

    // Control: inside the unscaled bbox the collision event fires normally.
    {
        let mut core = RuntimeCore::load(package.clone()).unwrap();
        core.reload_room(150).unwrap();
        core.set_debug_trace_limits(256, 0);
        place_player(&mut core, 208.0, 240.0);
        let mut host = HeadlessHost::new("orbit-freetrigger-control");
        core.tick(&mut host).unwrap();
        assert_eq!(
            core.globals.get("global.trigger[8]"),
            Some(&RuntimeValue::Bool(true)),
            "player inside the unscaled trigger bbox must fire the collision event"
        );
        assert!(
            core.scaled_bounds_trace.is_empty(),
            "dispatched pairs must not be traced as scaled-bounds misses"
        );
    }

    // Scaled zone: inside the yscale=4 region but below a scale-1 bbox ->
    // the scale-aware collision path must still fire the trigger event, and
    // no scaled-bounds miss may be traced.
    {
        let mut core = RuntimeCore::load(package).unwrap();
        core.reload_room(150).unwrap();
        core.set_debug_trace_limits(256, 0);
        place_player(&mut core, 208.0, 300.0);
        let mut host = HeadlessHost::new("orbit-freetrigger-miss");
        core.tick(&mut host).unwrap();
        assert_eq!(
            core.globals.get("global.trigger[8]"),
            Some(&RuntimeValue::Bool(true)),
            "player inside the yscale=4 trigger region must fire the collision event"
        );
        assert!(
            core.scaled_bounds_trace.is_empty(),
            "scale-aware dispatch must not report scaled-bounds misses"
        );
    }
}

#[test]
fn orbit_freetrigger_scaled_zone_miss_is_traced_without_firing_event() {
    let Some(package) = local_sample_package("gm8-core/28_I wanna be the Orbit") else {
        return;
    };
    // Scale the trigger the way room 150's creation code does, then place the
    // player so the instance stays visually outside the scaled zone: the
    // event must not fire and no miss may be traced.
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(150).unwrap();
    core.set_debug_trace_limits(256, 0);
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
            .expect("room should include the player");
        player.x = 208.0;
        player.y = 400.0;
        player.previous_x = 208.0;
        player.previous_y = 400.0;
        player.hspeed = 0.0;
        player.vspeed = 0.0;
    }
    let mut host = HeadlessHost::new("orbit-freetrigger-outside");
    core.tick(&mut host).unwrap();
    assert_ne!(
        core.globals.get("global.trigger[8]"),
        Some(&RuntimeValue::Bool(true)),
        "player outside the scaled trigger region must not fire the collision event"
    );
    assert!(
        core.scaled_bounds_trace.is_empty(),
        "no scaled-bounds miss may be traced when the pair does not overlap"
    );
}

/// Orbit's roomChanger must finish its collision event after `room_goto`.
/// Its `warpX=0 && warpY=0` branch destroys the persistent player so the
/// destination room's playerStart can create one at its own coordinates.
#[cfg(feature = "local-sample-tests")]
#[test]
fn orbit_room_transition_recreates_player_at_destination_start() {
    let Some(package) = local_sample_package("gm8-core/28_I wanna be the Orbit") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(150).unwrap();
    core.set_debug_trace_limits(128, 0);
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
            .expect("room should include the player");
        player.x = 757.0;
        player.y = 8.5;
        player.previous_x = 757.0;
        player.previous_y = 11.8;
        player.hspeed = 0.0;
        player.vspeed = -3.3;
    }

    let mut host = HeadlessHost::new("orbit-transition");
    core.tick(&mut host).unwrap();

    assert_eq!(core.snapshot().room_id, Some(223));
    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
        .expect("room-start should recreate the player");
    assert!(player.alive);
    assert_eq!((player.x, player.y), (753.0, 583.0));
    assert!(core.diagnostics().iter().any(|diagnostic| {
        diagnostic.code == "runtime-instance-created"
            && diagnostic.message.contains("object=player")
    }));
    assert!(core
        .diagnostics()
        .iter()
        .all(|diagnostic| diagnostic.code != "runtime-kill-player-requested"));
}

/// Regression: the Orbit web-shell boundary kill at (751, 8.895) in stage0_1.
///
/// The boundary (other:7:1) wrap chain evaluates `room_width`/`room_height`, and
/// `killPlayer` reads the player position through the `outsideRoom` script. Those
/// built-in identifiers used to fall through identifier resolution and evaluate
/// to 0, so the wrap chain took the `x > room_width` branch (x=16) and every
/// boundary event counted as outside-room, killing the player while its head was
/// still inside the room. With the built-ins resolved the player survives this
/// exact state and only dies when fully outside the room with no roomChanger.
#[cfg(feature = "local-sample-tests")]
#[test]
fn orbit_stage01_boundary_kill_repro_room_width_builtin() {
    let Some(package) = local_sample_package("gm8-core/28_I wanna be the Orbit") else {
        return;
    };
    let mut core = RuntimeCore::load(package).unwrap();
    core.reload_room(223).unwrap();
    core.set_debug_trace_limits(256, 0);
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
            .expect("room should include the player");
        // Exact position from the web-shell runtime-player-lifecycle diagnostic.
        player.x = 751.0;
        player.y = 8.895;
        player.previous_x = 751.0;
        player.previous_y = 15.095;
        player.hspeed = 0.0;
        player.vspeed = -6.2;
    }
    let mut host = HeadlessHost::new("orbit-boundary-repro");
    core.tick(&mut host).unwrap();
    let alive_after_head_poke = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
        .map(|instance| instance.alive)
        .expect("player instance should still exist");
    assert!(
        alive_after_head_poke,
        "player with head above the top edge but bbox inside the room must survive the boundary event"
    );
    assert_eq!(core.snapshot().deaths, 0);

    // At the next position the origin is fully outside the room. There is no
    // roomChanger at this location, so the original game's kill is expected.
    for _ in 0..4 {
        core.tick(&mut host).unwrap();
    }
    assert!(
        !core
            .current_room()
            .unwrap()
            .instances
            .iter()
            .find(|instance| instance.object_name.eq_ignore_ascii_case("player"))
            .map(|instance| instance.alive)
            .unwrap_or(false),
        "fully outside-room player with no roomChanger under it dies"
    );
}
