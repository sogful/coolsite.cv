use std::collections::HashMap;

use iwm_runtime_host::RuntimeButton;

use super::context::{RuntimeEvalContext, RuntimeExecutionScope};
use super::eval::evaluate_expr;
use super::eval_values::is_truthy;
use crate::helpers::as_number;
use crate::tick_context::RuntimeObjectQueryScratch;
use crate::{LoweredLogicExpr, RuntimeInstance, RuntimeValue};

pub(super) fn evaluate_ord_call(args: &[LoweredLogicExpr]) -> Option<RuntimeValue> {
    let first = args.first()?;
    match first {
        LoweredLogicExpr::LiteralText(text) => text
            .chars()
            .next()
            .map(|ch| RuntimeValue::Number(ch as u32 as f64)),
        _ => None,
    }
}

pub(super) fn evaluate_random_call(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let max = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    if max == 0.0 {
        return Some(RuntimeValue::Number(0.0));
    }
    let unit = next_random_unit(eval_context, instance, scope, max.to_bits());
    Some(RuntimeValue::Number(unit * max))
}

pub(super) fn evaluate_random_range_call(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let min = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let max = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    if min == max {
        return Some(RuntimeValue::Number(min));
    }
    let unit = next_random_unit(eval_context, instance, scope, min.to_bits() ^ max.to_bits());
    Some(RuntimeValue::Number(min + unit * (max - min)))
}

pub(super) fn evaluate_irandom_call(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let max = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?
        .round();
    let unit = next_random_unit(eval_context, instance, scope, max.to_bits());
    let value = if max >= 0.0 {
        (unit * (max + 1.0)).floor()
    } else {
        -(unit * (-max + 1.0)).floor()
    };
    Some(RuntimeValue::Number(value))
}

pub(super) fn evaluate_irandom_range_call(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let first = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?
        .round();
    let second = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?
        .round();
    let min = first.min(second);
    let max = first.max(second);
    let unit = next_random_unit(eval_context, instance, scope, min.to_bits() ^ max.to_bits());
    Some(RuntimeValue::Number(
        min + (unit * (max - min + 1.0)).floor(),
    ))
}

pub(super) fn evaluate_choose_call(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    if args.is_empty() {
        return None;
    }
    let values = args
        .iter()
        .filter_map(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .collect::<Vec<_>>();
    if values.is_empty() {
        return None;
    }
    let unit = next_random_unit(eval_context, instance, scope, values.len() as u64);
    let index = ((unit * values.len() as f64).floor() as usize).min(values.len() - 1);
    values.get(index).cloned()
}

pub(super) fn evaluate_point_direction(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let values = args
        .iter()
        .take(4)
        .map(|arg| {
            evaluate_expr(arg, instance, globals, scope, eval_context)
                .and_then(|value| as_number(&value))
        })
        .collect::<Option<Vec<_>>>()?;
    if values.len() != 4 {
        return None;
    }
    let direction = (values[1] - values[3])
        .atan2(values[2] - values[0])
        .to_degrees()
        .rem_euclid(360.0);
    Some(RuntimeValue::Number(direction))
}

pub(super) fn evaluate_point_distance(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let values = evaluate_number_args(args, 4, instance, globals, scope, eval_context)?;
    Some(RuntimeValue::Number(
        (values[2] - values[0]).hypot(values[3] - values[1]),
    ))
}

pub(super) fn evaluate_lengthdir(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    y_axis: bool,
) -> Option<RuntimeValue> {
    let values = evaluate_number_args(args, 2, instance, globals, scope, eval_context)?;
    let radians = values[1].to_radians();
    Some(RuntimeValue::Number(if y_axis {
        -radians.sin() * values[0]
    } else {
        radians.cos() * values[0]
    }))
}

fn evaluate_number_args(
    args: &[LoweredLogicExpr],
    count: usize,
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<Vec<f64>> {
    let values = args
        .iter()
        .take(count)
        .map(|arg| {
            evaluate_expr(arg, instance, globals, scope, eval_context)
                .and_then(|value| as_number(&value))
        })
        .collect::<Option<Vec<_>>>()?;
    (values.len() == count).then_some(values)
}

pub(super) fn evaluate_keyboard_query(
    name: &str,
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let key_code = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))
        .map(|value| value.round() as u16)?;
    let state = context
        .button_states
        .get(&RuntimeButton::Keyboard(key_code))
        .copied()
        .unwrap_or_default();
    let result = match name {
        "keyboard_check" | "keyboard_check_direct" => state.pressed,
        "keyboard_check_pressed" => state.just_pressed,
        "keyboard_check_released" => state.just_released,
        _ => return None,
    };
    Some(RuntimeValue::Bool(result))
}

pub(super) fn evaluate_place_query(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    want_meeting: bool,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let instance = instance?;
    let query_x = args
        .first()
        .and_then(|arg| evaluate_expr(arg, Some(instance), globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let query_y = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, Some(instance), globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let collides = if let Some(target_expr) = args.get(2) {
        let target_object_ids = instance_target_object_ids(target_expr, context)?;
        context
            .room_instances_matching_object_ids_near(&target_object_ids, instance, query_x, query_y)
            .any(|(_, candidate)| {
                crate::helpers::collides_with_instance_at(
                    instance,
                    query_x,
                    query_y,
                    candidate,
                    Some(instance.runtime_id),
                    |_| true,
                )
            })
    } else if !want_meeting {
        let horizontal_query = (query_x - instance.x).abs() > f64::EPSILON
            && (query_y - instance.y).abs() <= f64::EPSILON;
        context
            .solid_room_instances_near(instance, query_x, query_y)
            .any(|(_, candidate)| {
                let collides = crate::helpers::collides_with_instance_at(
                    instance,
                    query_x,
                    query_y,
                    candidate,
                    Some(instance.runtime_id),
                    |candidate| candidate.solid,
                );
                collides
                    && !(horizontal_query
                        && horizontal_query_only_touches_supporting_top(
                            instance, query_x, query_y, candidate,
                        ))
            })
    } else {
        return None;
    };
    Some(RuntimeValue::Bool(if want_meeting {
        collides
    } else {
        !collides
    }))
}

pub(super) fn evaluate_instance_place(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let instance = instance?;
    let x = args
        .first()
        .and_then(|arg| evaluate_expr(arg, Some(instance), globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let y = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, Some(instance), globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let target_object_ids = instance_target_object_ids(args.get(2)?, context)?;
    let hit = context
        .room_instances_matching_object_ids_near(&target_object_ids, instance, x, y)
        .find(|(_, candidate)| {
            crate::helpers::collides_with_instance_at(
                instance,
                x,
                y,
                candidate,
                Some(instance.runtime_id),
                |_| true,
            )
        })
        .map(|(_, candidate)| candidate.instance_id as f64)
        .unwrap_or(-4.0);
    Some(RuntimeValue::Number(hit))
}

pub(super) fn evaluate_instance_position(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let x = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let y = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let target_object_ids = instance_target_object_ids(args.get(2)?, context)?;
    let point_x = x.round() as i32;
    let point_y = y.round() as i32;
    let hit = context
        .room_instances_matching_object_ids(&target_object_ids)
        .find(|(_, candidate)| {
            candidate.is_active() && instance_contains_point(candidate, point_x, point_y)
        })
        .map(|(_, candidate)| candidate.instance_id as f64)
        .unwrap_or(-4.0);
    Some(RuntimeValue::Number(hit))
}

/// GM `check_collision_point(handle, x, y, true)`: the point must fall inside the
/// instance's bounding box, and additionally inside its precise mask when one is
/// available. Marker objects such as `warpInvisible` have no mask, so the bbox
/// alone decides for them.
pub(crate) fn instance_contains_point(
    instance: &RuntimeInstance,
    world_x: i32,
    world_y: i32,
) -> bool {
    let (left, top, right, bottom) = inclusive_bounds_at(instance);
    if world_x < left || world_x > right || world_y < top || world_y > bottom {
        return false;
    }
    if instance.collision_masks.is_empty() {
        return true;
    }
    instance_mask_contains_point(instance, world_x, world_y)
}

pub(super) fn evaluate_instance_exists(
    args: &[LoweredLogicExpr],
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let target_object_ids = instance_target_object_ids(args.first()?, context)?;
    let exists = context
        .room_instances_matching_object_ids(&target_object_ids)
        .any(|(_, instance)| instance.is_active());
    Some(RuntimeValue::Bool(exists))
}

pub(super) fn evaluate_instance_number(
    args: &[LoweredLogicExpr],
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let mut scratch = RuntimeObjectQueryScratch::default();
    evaluate_instance_number_with_scratch(args, eval_context, &mut scratch)
}

pub(super) fn evaluate_instance_find(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let target_object_ids = instance_target_object_ids(args.first()?, context)?;
    let index = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?
        .round();
    if index < 0.0 {
        return Some(RuntimeValue::Number(-4.0));
    }
    let hit = context
        .room_instances_iter()
        .filter(|(_, candidate)| {
            candidate.is_active() && target_object_ids.contains(&candidate.object_id)
        })
        .nth(index as usize)
        .map(|(_, candidate)| candidate.instance_id as f64)
        .unwrap_or(-4.0);
    Some(RuntimeValue::Number(hit))
}

fn horizontal_query_only_touches_supporting_top(
    instance: &RuntimeInstance,
    query_x: f64,
    query_y: f64,
    candidate: &RuntimeInstance,
) -> bool {
    if crate::helpers::collides_with_instance_at(
        instance,
        instance.x,
        instance.y,
        candidate,
        Some(instance.runtime_id),
        |candidate| candidate.solid,
    ) {
        return false;
    }

    let (_, _, _, query_bottom) = crate::helpers::bounds_at(instance, query_x, query_y);
    let (_, candidate_top, _, _) = crate::helpers::bounds_at(candidate, candidate.x, candidate.y);
    query_bottom - candidate_top == 1
        && !crate::helpers::collides_with_instance_at(
            instance,
            query_x,
            query_y - 1.0,
            candidate,
            Some(instance.runtime_id),
            |candidate| candidate.solid,
        )
}

pub(super) fn evaluate_instance_number_with_scratch(
    args: &[LoweredLogicExpr],
    eval_context: Option<&RuntimeEvalContext<'_>>,
    scratch: &mut RuntimeObjectQueryScratch,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let target_object_ids = instance_target_object_ids(args.first()?, context)?;
    context.write_room_instance_indices_matching_object_ids(&target_object_ids, scratch);
    let count = scratch
        .candidates()
        .iter()
        .filter_map(|&index| context.room_instance(index))
        .filter(|instance| instance.is_active())
        .count();
    Some(RuntimeValue::Number(count as f64))
}

pub(super) fn evaluate_distance_to_object(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    _globals: &HashMap<String, RuntimeValue>,
    _scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let mut scratch = RuntimeObjectQueryScratch::default();
    evaluate_distance_to_object_with_scratch(args, instance, eval_context, &mut scratch)
}

pub(super) fn evaluate_distance_to_object_with_scratch(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    scratch: &mut RuntimeObjectQueryScratch,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let instance = instance?;
    let object_name = args.first().and_then(|arg| match arg {
        LoweredLogicExpr::Identifier(name) => Some(name.as_str()),
        _ => None,
    })?;
    let target_object_ids = context
        .place_target_ids_by_name
        .get(&object_name.to_ascii_lowercase())?;
    context.write_room_instance_indices_matching_object_ids(target_object_ids, scratch);
    let distance = scratch
        .candidates()
        .iter()
        .filter_map(|&index| context.room_instance(index))
        .filter(|candidate| candidate.is_active() && candidate.runtime_id != instance.runtime_id)
        .map(|candidate| instance_bbox_distance(instance, candidate))
        .fold(1_000_000.0, f64::min);

    Some(RuntimeValue::Number(distance))
}

pub(super) fn evaluate_collision_line(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let mut scratch = RuntimeObjectQueryScratch::default();
    evaluate_collision_line_with_scratch(args, instance, globals, scope, eval_context, &mut scratch)
}

pub(super) fn evaluate_collision_rectangle(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let mut scratch = RuntimeObjectQueryScratch::default();
    evaluate_collision_rectangle_with_scratch(
        args,
        instance,
        globals,
        scope,
        eval_context,
        &mut scratch,
    )
}

pub(super) fn evaluate_collision_rectangle_with_scratch(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    scratch: &mut RuntimeObjectQueryScratch,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let values = evaluate_number_args(args, 4, instance, globals, scope, eval_context)?;
    let left = values[0].min(values[2]).round() as i32;
    let top = values[1].min(values[3]).round() as i32;
    let right = values[0].max(values[2]).round() as i32;
    let bottom = values[1].max(values[3]).round() as i32;
    let target_object_ids = instance_target_object_ids(args.get(4)?, context)?;
    let precise = args
        .get(5)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .map(|value| is_truthy(Some(value)))
        .unwrap_or(false);
    let exclude_self = args
        .get(6)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .map(|value| is_truthy(Some(value)))
        .unwrap_or(false);
    let current_runtime_id = instance.map(|instance| instance.runtime_id);
    context.write_room_instance_indices_matching_object_ids(&target_object_ids, scratch);
    let hit = scratch
        .candidates()
        .iter()
        .filter_map(|&index| context.room_instance(index))
        .find(|candidate| {
            candidate.is_active()
                && (!exclude_self || current_runtime_id != Some(candidate.runtime_id))
                && rectangle_intersects_instance(candidate, left, top, right, bottom, precise)
        })
        .map(|candidate| candidate.instance_id as f64)
        .unwrap_or(-4.0);
    Some(RuntimeValue::Number(hit))
}

pub(super) fn evaluate_collision_line_with_scratch(
    args: &[LoweredLogicExpr],
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    scratch: &mut RuntimeObjectQueryScratch,
) -> Option<RuntimeValue> {
    let context = eval_context?;
    let x1 = args
        .first()
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let y1 = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let x2 = args
        .get(2)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let y2 = args
        .get(3)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))?;
    let object_name = args.get(4).and_then(|arg| match arg {
        LoweredLogicExpr::Identifier(name) => Some(name.as_str()),
        _ => None,
    })?;
    let precise = args
        .get(5)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .map(|value| is_truthy(Some(value)))
        .unwrap_or(false);
    let exclude_self = args
        .get(6)
        .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .map(|value| is_truthy(Some(value)))
        .unwrap_or(false);
    let current_runtime_id = instance.map(|instance| instance.runtime_id);
    let target_object_ids = context
        .place_target_ids_by_name
        .get(&object_name.to_ascii_lowercase())?;
    context.write_room_instance_indices_matching_object_ids(target_object_ids, scratch);
    let hit = scratch
        .candidates()
        .iter()
        .filter_map(|&index| context.room_instance(index))
        .find(|candidate| {
            candidate.is_active()
                && (!exclude_self || current_runtime_id != Some(candidate.runtime_id))
                && line_intersects_instance(candidate, x1, y1, x2, y2, precise)
        })
        .map(|candidate| candidate.instance_id as f64)
        .unwrap_or(-4.0);

    Some(RuntimeValue::Number(hit))
}

fn deterministic_random_unit(
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
    salt: u64,
) -> f64 {
    let mut seed = salt ^ 0x9e37_79b9_7f4a_7c15;
    if let Some(instance) = instance {
        seed ^= (instance.runtime_id as u64).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        seed ^= instance.x.to_bits().rotate_left(17);
        seed ^= instance.y.to_bits().rotate_left(29);
    }
    let loop_index = scope
        .and_then(|scope| scope.get("i"))
        .or_else(|| instance.and_then(|instance| instance.vars.get("i").cloned()));
    if let Some(RuntimeValue::Number(i)) = loop_index {
        seed ^= i.to_bits().rotate_left(7);
    }
    seed = seed.wrapping_add(0x9e37_79b9_7f4a_7c15);
    seed = (seed ^ (seed >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    seed = (seed ^ (seed >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    let mixed = seed ^ (seed >> 31);
    unit_interval_from_u64(mixed)
}

fn next_random_unit(
    eval_context: Option<&RuntimeEvalContext<'_>>,
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
    salt: u64,
) -> f64 {
    let Some(context) = eval_context else {
        return deterministic_random_unit(instance, scope, salt);
    };
    let mut seed = context
        .random_state
        .get()
        .wrapping_add(0x9e37_79b9_7f4a_7c15);
    seed = (seed ^ (seed >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    seed = (seed ^ (seed >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    let mixed = seed ^ (seed >> 31);
    context.random_state.set(mixed);
    unit_interval_from_u64(mixed)
}

fn unit_interval_from_u64(value: u64) -> f64 {
    ((value >> 11) as f64) * (1.0 / ((1u64 << 53) as f64))
}

fn instance_target_object_ids(
    expr: &LoweredLogicExpr,
    context: &RuntimeEvalContext<'_>,
) -> Option<Vec<usize>> {
    match expr {
        LoweredLogicExpr::Identifier(name) if name.eq_ignore_ascii_case("all") => Some(
            context
                .room_instances_iter()
                .map(|(_, instance)| instance.object_id)
                .collect(),
        ),
        LoweredLogicExpr::Identifier(name) => context
            .place_target_ids_by_name
            .get(&name.to_ascii_lowercase())
            .cloned()
            // GM8 compiles identifiers that are no object name into implicit variable
            // reads; with "treat uninitialized as 0" enabled a dangling target
            // (deleted object left in script source) evaluates to object index 0.
            .or_else(|| context.zero_uninitialized_vars.then(|| vec![0usize])),
        LoweredLogicExpr::LiteralNumber(number) if number.is_finite() && *number >= 0.0 => {
            Some(vec![number.round() as usize])
        }
        LoweredLogicExpr::LiteralNumber(number) if *number == -3.0 => Some(
            context
                .room_instances_iter()
                .map(|(_, instance)| instance.object_id)
                .collect(),
        ),
        _ => None,
    }
}

fn instance_bbox_distance(
    left_instance: &RuntimeInstance,
    right_instance: &RuntimeInstance,
) -> f64 {
    let (left, top, right, bottom) = inclusive_bounds_at(left_instance);
    let (other_left, other_top, other_right, other_bottom) = inclusive_bounds_at(right_instance);
    let dx = if left > other_right {
        left - other_right
    } else if other_left > right {
        other_left - right
    } else {
        0
    };
    let dy = if top > other_bottom {
        top - other_bottom
    } else if other_top > bottom {
        other_top - bottom
    } else {
        0
    };

    match (dx, dy) {
        (0, 0) => 0.0,
        (x, 0) => x as f64,
        (0, y) => y as f64,
        (x, y) => (x as f64).hypot(y as f64),
    }
}

fn inclusive_bounds_at(instance: &RuntimeInstance) -> (i32, i32, i32, i32) {
    let (xscale, yscale) = crate::helpers::instance_image_scale(instance);
    if xscale == 1.0 && yscale == 1.0 {
        let x = instance.x.round() as i32;
        let y = instance.y.round() as i32;
        return (
            x - instance.origin_x + instance.bbox_left,
            y - instance.origin_y + instance.bbox_top,
            x - instance.origin_x + instance.bbox_right,
            y - instance.origin_y + instance.bbox_bottom,
        );
    }
    let [left, top, right, bottom] =
        crate::helpers::scaled_bounds_at(instance, instance.x, instance.y);
    (left, top, right - 1, bottom - 1)
}

fn line_intersects_instance(
    instance: &RuntimeInstance,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    precise: bool,
) -> bool {
    let (left, top, right, bottom) = inclusive_bounds_at(instance);
    if !line_intersects_inclusive_rect(x1, y1, x2, y2, left, top, right, bottom) {
        return false;
    }
    if !precise || instance.collision_masks.is_empty() {
        return true;
    }
    line_points(x1, y1, x2, y2).any(|(x, y)| instance_mask_contains_point(instance, x, y))
}

fn rectangle_intersects_instance(
    instance: &RuntimeInstance,
    left: i32,
    top: i32,
    right: i32,
    bottom: i32,
    precise: bool,
) -> bool {
    let (instance_left, instance_top, instance_right, instance_bottom) =
        inclusive_bounds_at(instance);
    if left > instance_right
        || right < instance_left
        || top > instance_bottom
        || bottom < instance_top
    {
        return false;
    }
    if !precise || instance.collision_masks.is_empty() {
        return true;
    }
    for y in top.max(instance_top)..=bottom.min(instance_bottom) {
        for x in left.max(instance_left)..=right.min(instance_right) {
            if instance_mask_contains_point(instance, x, y) {
                return true;
            }
        }
    }
    false
}

fn line_intersects_inclusive_rect(
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    left: i32,
    top: i32,
    right: i32,
    bottom: i32,
) -> bool {
    let rect_left = left as f64;
    let rect_top = top as f64;
    let rect_right = (right + 1) as f64;
    let rect_bottom = (bottom + 1) as f64;
    let mut t0 = 0.0;
    let mut t1 = 1.0;
    clip_line_axis(-(x2 - x1), x1 - rect_left, &mut t0, &mut t1)
        && clip_line_axis(x2 - x1, rect_right - x1, &mut t0, &mut t1)
        && clip_line_axis(-(y2 - y1), y1 - rect_top, &mut t0, &mut t1)
        && clip_line_axis(y2 - y1, rect_bottom - y1, &mut t0, &mut t1)
}

fn clip_line_axis(p: f64, q: f64, t0: &mut f64, t1: &mut f64) -> bool {
    if p == 0.0 {
        return q >= 0.0;
    }
    let r = q / p;
    if p < 0.0 {
        if r > *t1 {
            return false;
        }
        if r > *t0 {
            *t0 = r;
        }
    } else {
        if r < *t0 {
            return false;
        }
        if r < *t1 {
            *t1 = r;
        }
    }
    true
}

fn line_points(x1: f64, y1: f64, x2: f64, y2: f64) -> impl Iterator<Item = (i32, i32)> {
    let x1 = x1.round() as i32;
    let y1 = y1.round() as i32;
    let x2 = x2.round() as i32;
    let y2 = y2.round() as i32;
    let steps = (x2 - x1).abs().max((y2 - y1).abs());
    (0..=steps).map(move |step| {
        if steps == 0 {
            (x1, y1)
        } else {
            let t = step as f64 / steps as f64;
            (
                (x1 as f64 + (x2 - x1) as f64 * t).round() as i32,
                (y1 as f64 + (y2 - y1) as f64 * t).round() as i32,
            )
        }
    })
}

fn instance_mask_contains_point(instance: &RuntimeInstance, world_x: i32, world_y: i32) -> bool {
    let Some(mask) = instance.collision_masks.first() else {
        return false;
    };
    let expected_len = mask.width.checked_mul(mask.height).unwrap_or(0) as usize;
    if mask.width == 0 || mask.height == 0 || mask.data.len() < expected_len {
        return false;
    }
    let (xscale, yscale) = crate::helpers::instance_image_scale(instance);
    let dx = world_x - instance.x.round() as i32;
    let dy = world_y - instance.y.round() as i32;
    let local_x = if xscale == 1.0 {
        dx + instance.origin_x
    } else {
        (instance.origin_x as f64 + dx as f64 / xscale).floor() as i32
    };
    let local_y = if yscale == 1.0 {
        dy + instance.origin_y
    } else {
        (instance.origin_y as f64 + dy as f64 / yscale).floor() as i32
    };
    if local_x < mask.bbox_left
        || local_x > mask.bbox_right
        || local_y < mask.bbox_top
        || local_y > mask.bbox_bottom
        || local_x < 0
        || local_y < 0
        || local_x >= mask.width as i32
        || local_y >= mask.height as i32
    {
        return false;
    }
    let index = local_y as usize * mask.width as usize + local_x as usize;
    mask.data.get(index).copied().unwrap_or(false)
}
