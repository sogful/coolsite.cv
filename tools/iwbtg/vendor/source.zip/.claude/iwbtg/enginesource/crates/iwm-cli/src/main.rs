use clap::{Parser, Subcommand};
use iwm_detector::{detect_input, load_package, selected_executable};
use iwm_parser::build_package;
use iwm_runtime_core::{RuntimeCore, RuntimePackage};
use iwm_runtime_host::{ButtonState, HeadlessHost, RuntimeButton, RuntimeDiagnostic};
use iwm_runtime_model::{read_runtime_package_dir, validate_runtime_package};
use serde_json::json;
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "iwm-cli")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Detect {
        #[arg(long)]
        input: PathBuf,
    },
    BuildPackage {
        #[arg(long)]
        input: PathBuf,
        #[arg(long)]
        output: PathBuf,
    },
    ValidatePackage {
        #[arg(long)]
        input: PathBuf,
    },
    RuntimeDiagnostics {
        #[arg(long)]
        input: PathBuf,
        #[arg(long, default_value_t = 600)]
        ticks: u32,
        #[arg(long, value_delimiter = ',')]
        press_keys: Vec<u16>,
        #[arg(long, default_value_t = false)]
        press_restart: bool,
        #[arg(long, value_delimiter = ',')]
        hold_keys: Vec<u16>,
        #[arg(long)]
        input_script: Option<PathBuf>,
        #[arg(long)]
        select_room: Option<usize>,
        #[arg(long, default_value_t = 0)]
        preselect_ticks: u32,
        #[arg(long, default_value_t = false)]
        trace_player: bool,
        #[arg(long, default_value_t = 1)]
        trace_every: u32,
        #[arg(long, default_value_t = false)]
        trace_collisions: bool,
        #[arg(long, default_value_t = false)]
        trace_on_death: bool,
        #[arg(long, default_value_t = 12)]
        death_trace_window: usize,
        #[arg(long)]
        trace_output: Option<PathBuf>,
    },
    RuntimeScenario {
        #[arg(long)]
        input: PathBuf,
        #[arg(long)]
        scenario: PathBuf,
        #[arg(long, default_value_t = 600)]
        ticks: u32,
        #[arg(long)]
        select_room: Option<usize>,
        #[arg(long, default_value_t = 0)]
        preselect_ticks: u32,
        #[arg(long, default_value_t = false)]
        trace_player: bool,
        #[arg(long, default_value_t = 1)]
        trace_every: u32,
    },
    SampleAudit {
        #[arg(long)]
        input: PathBuf,
        #[arg(long)]
        package_output: PathBuf,
        #[arg(long)]
        report_output: PathBuf,
        #[arg(long, default_value_t = 600)]
        ticks: u32,
    },
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Detect { input } => match detect_input(&input) {
            Ok(report) => {
                println!("{}", serde_json::to_string_pretty(&report).unwrap());
            }
            Err(err) => {
                eprintln!("{err}");
                std::process::exit(1);
            }
        },
        Commands::BuildPackage { input, output } => {
            let package = match load_package(&input) {
                Ok(package) => package,
                Err(err) => {
                    eprintln!("{err}");
                    std::process::exit(1);
                }
            };

            let report = match detect_input(&input) {
                Ok(report) => report,
                Err(err) => {
                    eprintln!("{err}");
                    std::process::exit(1);
                }
            };

            if !matches!(
                report.verdict,
                iwm_detector::DetectionVerdict::Gm8Likely | iwm_detector::DetectionVerdict::Unknown
            ) {
                eprintln!("input is classified as an unsupported engine or layout");
                std::process::exit(2);
            }

            let exe = match selected_executable(&package) {
                Ok(exe) => exe,
                Err(err) => {
                    eprintln!("{err}");
                    std::process::exit(2);
                }
            };

            if let Err(err) = build_package(exe, &output, &report.dlls) {
                eprintln!("{err:#}");
                std::process::exit(1);
            }
        }
        Commands::ValidatePackage { input } => {
            let package = match read_runtime_package_dir(&input) {
                Ok(package) => package,
                Err(err) => {
                    eprintln!("{err}");
                    std::process::exit(1);
                }
            };
            let report = validate_runtime_package(&package);
            println!("{}", serde_json::to_string_pretty(&report).unwrap());
            if !report.valid {
                std::process::exit(2);
            }
        }
        Commands::RuntimeDiagnostics {
            input,
            ticks,
            press_keys,
            press_restart,
            hold_keys,
            input_script,
            select_room,
            preselect_ticks,
            trace_player,
            trace_every,
            trace_collisions,
            trace_on_death,
            death_trace_window,
            trace_output,
        } => {
            if trace_player && trace_every == 0 {
                eprintln!("--trace-every must be greater than 0");
                std::process::exit(2);
            }
            if trace_on_death && death_trace_window == 0 {
                eprintln!(
                    "--death-trace-window must be greater than 0 when --trace-on-death is set"
                );
                std::process::exit(2);
            }
            let package = match read_runtime_package_dir(&input) {
                Ok(package) => {
                    let lowered_logic = match serde_json::to_value(package.lowered_logic)
                        .and_then(serde_json::from_value)
                    {
                        Ok(lowered_logic) => lowered_logic,
                        Err(err) => {
                            eprintln!("failed to convert lowered runtime logic: {err}");
                            std::process::exit(1);
                        }
                    };
                    RuntimePackage {
                        manifest: package.manifest,
                        rooms: package.rooms,
                        objects: package.objects,
                        scripts: package.scripts,
                        lowered_logic: Some(lowered_logic),
                        resources: package.resources,
                        analysis: package.analysis,
                    }
                }
                Err(err) => {
                    eprintln!("{err}");
                    std::process::exit(1);
                }
            };
            let mut core = match RuntimeCore::load(package) {
                Ok(core) => core,
                Err(err) => {
                    eprintln!("failed to boot runtime core: {err:?}");
                    std::process::exit(1);
                }
            };
            let mut host = HeadlessHost::new("runtime-diagnostics");
            if trace_collisions || trace_on_death {
                core.set_debug_trace_limits(
                    256,
                    if trace_on_death {
                        death_trace_window
                    } else {
                        0
                    },
                );
            }
            let input_script = match input_script {
                Some(path) => match read_runtime_input_script(&path) {
                    Ok(script) => Some(script),
                    Err(err) => {
                        eprintln!("failed to read input script {}: {err}", path.display());
                        std::process::exit(1);
                    }
                },
                None => None,
            };
            let mut scripted_input_state = RuntimeInputScriptState::default();
            let mut seen_runtime_events = HashSet::new();
            let mut runtime_events = Vec::new();
            for _ in 0..preselect_ticks {
                apply_cli_input(
                    &mut host,
                    u64::MAX,
                    &[],
                    false,
                    &[],
                    input_script.as_ref(),
                    &mut scripted_input_state,
                );
                if let Err(err) = core.tick(&mut host) {
                    eprintln!(
                        "runtime preselect tick failed at tick {}: {err:?}",
                        core.tick_count()
                    );
                    std::process::exit(1);
                }
                collect_runtime_events(
                    core.diagnostics(),
                    &mut seen_runtime_events,
                    &mut runtime_events,
                );
                host.input.clear_transitions();
            }
            if let Some(room_id) = select_room {
                if let Err(err) = core.reload_room(room_id) {
                    eprintln!("failed to select room {room_id}: {err:?}");
                    std::process::exit(1);
                }
                if let Err(err) = core.render(&mut host) {
                    eprintln!("failed to settle selected room {room_id}: {err:?}");
                    std::process::exit(1);
                }
            }
            let mut seen_messages = HashSet::new();
            let mut blockers: HashMap<String, RuntimeBlockerSummary> = HashMap::new();
            let mut player_trace = Vec::new();

            if trace_player {
                maybe_collect_player_trace(&core, trace_every, &mut player_trace);
            }

            for run_tick in 0..ticks {
                apply_cli_input(
                    &mut host,
                    u64::from(run_tick),
                    &press_keys,
                    press_restart,
                    &hold_keys,
                    input_script.as_ref(),
                    &mut scripted_input_state,
                );
                if let Err(err) = core.tick(&mut host) {
                    eprintln!("runtime tick failed at tick {}: {err:?}", core.tick_count());
                    std::process::exit(1);
                }
                collect_runtime_blockers(core.diagnostics(), &mut seen_messages, &mut blockers);
                collect_runtime_events(
                    core.diagnostics(),
                    &mut seen_runtime_events,
                    &mut runtime_events,
                );
                if trace_player {
                    maybe_collect_player_trace(&core, trace_every, &mut player_trace);
                }
                host.input.clear_transitions();
            }

            let mut ranked = blockers.into_values().collect::<Vec<_>>();
            ranked.sort_by(|left, right| {
                right
                    .count
                    .cmp(&left.count)
                    .then_with(|| left.key.cmp(&right.key))
            });

            let snapshot = core.snapshot();
            let mut output = json!({
                "ticks": ticks,
                "current_room": snapshot.room_name,
                "current_room_id": snapshot.room_id,
                "current_tick": core.tick_count(),
                "runtime_blockers": ranked,
                "runtime_events": runtime_events,
            });
            if trace_collisions {
                output["collision_trace"] = json!(snapshot.collision_trace);
                output["scaled_bounds_trace"] = json!(snapshot.scaled_bounds_trace);
            }
            if trace_on_death {
                output["death_trace"] = json!(snapshot.death_trace);
            }
            if trace_player {
                output["trace_summary"] = json!(summarize_player_trace(&player_trace));
                output["player_trace"] = json!(player_trace);
            }

            let output = serde_json::to_string_pretty(&output).unwrap();
            if let Some(path) = trace_output {
                if let Err(err) = fs::write(&path, output) {
                    eprintln!("failed to write trace output {}: {err}", path.display());
                    std::process::exit(1);
                }
            } else {
                println!("{output}");
            }
        }
        Commands::RuntimeScenario {
            input,
            scenario,
            ticks,
            select_room,
            preselect_ticks,
            trace_player,
            trace_every,
        } => run_runtime_scenario_command(
            &input,
            &scenario,
            ticks,
            select_room,
            preselect_ticks,
            trace_player,
            trace_every,
        ),
        Commands::SampleAudit {
            input,
            package_output,
            report_output,
            ticks,
        } => run_sample_audit_command(&input, &package_output, &report_output, ticks),
    }
}

fn run_sample_audit_command(
    input: &std::path::Path,
    package_output: &std::path::Path,
    report_output: &std::path::Path,
    ticks: u32,
) {
    if !input.exists() {
        eprintln!("sample input does not exist: {}", input.display());
        std::process::exit(1);
    }
    let detection = match detect_input(input) {
        Ok(report) => report,
        Err(err) => {
            eprintln!("sample detection failed: {err}");
            std::process::exit(1);
        }
    };
    let mut report = json!({
        "source": input,
        "package_output": package_output,
        "ticks": ticks,
        "detection": detection,
        "stages": {
            "detect": {"status":"passed"},
            "build": {"status":"pending"},
            "validate": {"status":"pending"},
            "runtime": {"status":"pending"}
        }
    });
    if !matches!(
        detection.verdict,
        iwm_detector::DetectionVerdict::Gm8Likely | iwm_detector::DetectionVerdict::Unknown
    ) {
        report["stages"]["build"] = json!({"status":"skipped","reason":"input is classified as an unsupported engine or layout"});
        write_audit_report(report_output, &report);
        std::process::exit(2);
    }
    let source_package = match load_package(input) {
        Ok(package) => package,
        Err(err) => {
            report["stages"]["build"] = json!({"status":"failed","error":err.to_string()});
            write_audit_report(report_output, &report);
            std::process::exit(1);
        }
    };
    let exe = match selected_executable(&source_package) {
        Ok(exe) => exe,
        Err(err) => {
            report["stages"]["build"] = json!({"status":"failed","error":err.to_string()});
            write_audit_report(report_output, &report);
            std::process::exit(1);
        }
    };
    if let Err(err) = build_package(exe, package_output, &detection.dlls) {
        report["stages"]["build"] = json!({"status":"failed","error":format!("{err:#}")});
        write_audit_report(report_output, &report);
        std::process::exit(1);
    }
    report["stages"]["build"] = json!({"status":"passed"});
    let runtime_package = match read_runtime_package_dir(package_output) {
        Ok(package) => package,
        Err(err) => {
            report["stages"]["validate"] = json!({"status":"failed","error":err.to_string()});
            write_audit_report(report_output, &report);
            std::process::exit(1);
        }
    };
    let validation = validate_runtime_package(&runtime_package);
    report["validation"] = json!(validation);
    report["inventory"] = json!({
        "default_room_id": runtime_package.manifest.default_room_id,
        "rooms": runtime_package.rooms.len(),
        "objects": runtime_package.objects.len(),
        "scripts": runtime_package.scripts.blocks.len(),
        "lowered_entries": runtime_package.lowered_logic.entries.len(),
        "sprites": runtime_package.resources.sprites.len(),
        "backgrounds": runtime_package.resources.backgrounds.len(),
        "sounds": runtime_package.resources.sounds.len()
    });
    if !validation.valid {
        report["stages"]["validate"] = json!({"status":"failed"});
        write_audit_report(report_output, &report);
        std::process::exit(2);
    }
    report["stages"]["validate"] = json!({"status":"passed"});
    let output = std::process::Command::new(std::env::current_exe().unwrap())
        .arg("runtime-diagnostics")
        .arg("--input")
        .arg(package_output)
        .arg("--ticks")
        .arg(ticks.to_string())
        .output();
    match output {
        Ok(output) if output.status.success() => {
            match serde_json::from_slice::<serde_json::Value>(&output.stdout) {
                Ok(diagnostics) => {
                    report["stages"]["runtime"] = json!({"status":"passed"});
                    report["runtime"] = diagnostics;
                }
                Err(err) => {
                    report["stages"]["runtime"] = json!({"status":"failed","error":err.to_string()})
                }
            }
        }
        Ok(output) => {
            report["stages"]["runtime"] =
                json!({"status":"failed","error":String::from_utf8_lossy(&output.stderr)})
        }
        Err(err) => {
            report["stages"]["runtime"] = json!({"status":"failed","error":err.to_string()})
        }
    }
    let runtime_passed = report["stages"]["runtime"]["status"] == "passed";
    write_audit_report(report_output, &report);
    println!("{}", serde_json::to_string_pretty(&report).unwrap());
    if !runtime_passed {
        std::process::exit(2);
    }
}

fn write_audit_report(path: &std::path::Path, report: &serde_json::Value) {
    if let Some(parent) = path.parent() {
        if let Err(err) = fs::create_dir_all(parent) {
            eprintln!(
                "failed to create audit report directory {}: {err}",
                parent.display()
            );
            std::process::exit(1);
        }
    }
    let serialized = serde_json::to_string_pretty(report).unwrap();
    if let Err(err) = fs::write(path, serialized) {
        eprintln!("failed to write audit report {}: {err}", path.display());
        std::process::exit(1);
    }
}

fn run_runtime_scenario_command(
    input: &std::path::Path,
    scenario: &std::path::Path,
    ticks: u32,
    select_room: Option<usize>,
    preselect_ticks: u32,
    trace_player: bool,
    trace_every: u32,
) {
    let scenario_value: serde_json::Value = match fs::read(scenario)
        .map_err(|err| err.to_string())
        .and_then(|bytes| serde_json::from_slice(&bytes).map_err(|err| err.to_string()))
    {
        Ok(value) => value,
        Err(err) => {
            eprintln!("failed to read scenario {}: {err}", scenario.display());
            std::process::exit(1);
        }
    };
    let executable = match std::env::current_exe() {
        Ok(path) => path,
        Err(err) => {
            eprintln!("failed to locate current executable: {err}");
            std::process::exit(1);
        }
    };
    let mut command = std::process::Command::new(executable);
    command
        .arg("runtime-diagnostics")
        .arg("--input")
        .arg(input)
        .arg("--ticks")
        .arg(ticks.to_string())
        .arg("--input-script")
        .arg(scenario)
        .arg("--preselect-ticks")
        .arg(preselect_ticks.to_string())
        .arg("--trace-every")
        .arg(trace_every.to_string());
    if let Some(room_id) = select_room {
        command.arg("--select-room").arg(room_id.to_string());
    }
    if scenario_value
        .pointer("/assertions/no_player_death")
        .and_then(serde_json::Value::as_bool)
        == Some(true)
    {
        command.arg("--trace-on-death");
    }
    if trace_player
        || scenario_value
            .get("assertions")
            .and_then(|value| value.get("final_player"))
            .is_some()
    {
        command.arg("--trace-player");
    }
    let output = match command.output() {
        Ok(output) => output,
        Err(err) => {
            eprintln!("failed to execute runtime scenario: {err}");
            std::process::exit(1);
        }
    };
    if !output.status.success() {
        eprint!("{}", String::from_utf8_lossy(&output.stderr));
        std::process::exit(output.status.code().unwrap_or(1));
    }
    let diagnostics: serde_json::Value = match serde_json::from_slice(&output.stdout) {
        Ok(value) => value,
        Err(err) => {
            eprintln!("runtime scenario produced invalid diagnostics JSON: {err}");
            std::process::exit(1);
        }
    };
    let assertion_results = evaluate_scenario_assertions(
        &diagnostics,
        scenario_value
            .get("assertions")
            .unwrap_or(&serde_json::Value::Null),
    );
    let passed = assertion_results
        .iter()
        .all(|result| result["passed"] == true);
    let result = json!({
        "passed": passed,
        "assertions": assertion_results,
        "diagnostics": diagnostics,
    });
    println!("{}", serde_json::to_string_pretty(&result).unwrap());
    if !passed {
        std::process::exit(2);
    }
}

fn evaluate_scenario_assertions(
    diagnostics: &serde_json::Value,
    assertions: &serde_json::Value,
) -> Vec<serde_json::Value> {
    let mut results = Vec::new();
    if assertions
        .get("no_runtime_blockers")
        .and_then(serde_json::Value::as_bool)
        == Some(true)
    {
        let actual = diagnostics["runtime_blockers"]
            .as_array()
            .map_or(0, Vec::len);
        results.push(json!({"name":"no_runtime_blockers","passed":actual == 0,"actual":actual}));
    }
    if assertions
        .get("no_player_death")
        .and_then(serde_json::Value::as_bool)
        == Some(true)
    {
        let actual = diagnostics["runtime_events"]
            .as_array()
            .map_or(0, |events| {
                events
                    .iter()
                    .filter(|event| {
                        event.get("code").and_then(serde_json::Value::as_str)
                            == Some("runtime-player-died")
                    })
                    .count()
            });
        results.push(json!({"name":"no_player_death","passed":actual == 0,"actual":actual}));
    }
    if let Some(expected) = assertions
        .get("final_room_id")
        .and_then(serde_json::Value::as_u64)
    {
        let actual = diagnostics
            .get("current_room_id")
            .and_then(serde_json::Value::as_u64);
        results.push(json!({"name":"final_room_id","passed":actual == Some(expected),"expected":expected,"actual":actual}));
    }
    if let Some(expected_rooms) = assertions
        .get("visited_room_ids")
        .and_then(serde_json::Value::as_array)
    {
        let mut visited = HashSet::new();
        if let Some(room) = diagnostics
            .get("current_room_id")
            .and_then(serde_json::Value::as_u64)
        {
            visited.insert(room);
        }
        if let Some(events) = diagnostics
            .get("runtime_events")
            .and_then(serde_json::Value::as_array)
        {
            for event in events {
                for field in ["room", "from_room", "to_room"] {
                    if let Some(room) = event.get(field).and_then(serde_json::Value::as_u64) {
                        visited.insert(room);
                    }
                }
            }
        }
        for expected in expected_rooms.iter().filter_map(serde_json::Value::as_u64) {
            results.push(json!({"name":format!("visited_room_id:{expected}"),"passed":visited.contains(&expected),"expected":expected,"actual":visited}));
        }
    }
    if let Some(expected_events) = assertions
        .get("events")
        .and_then(serde_json::Value::as_array)
    {
        let actual_events = diagnostics["runtime_events"]
            .as_array()
            .map_or(&[][..], Vec::as_slice);
        for expected in expected_events {
            let minimum = expected
                .get("min_count")
                .and_then(serde_json::Value::as_u64)
                .unwrap_or(1);
            let count = actual_events
                .iter()
                .filter(|actual| {
                    ["code", "object", "reason"].iter().all(|field| {
                        expected.get(field).is_none() || expected.get(field) == actual.get(field)
                    })
                })
                .count() as u64;
            results.push(json!({"name":format!("event:{}", expected.get("code").and_then(serde_json::Value::as_str).unwrap_or("matching")),"passed":count >= minimum,"expected_min_count":minimum,"actual":count}));
        }
    }
    if let Some(death) = assertions.get("death") {
        let actual_events = diagnostics["runtime_events"]
            .as_array()
            .map_or(&[][..], Vec::as_slice);
        let passed = actual_events.iter().any(|actual| {
            actual.get("code").and_then(serde_json::Value::as_str) == Some("runtime-player-died")
                && ["object", "reason"].iter().all(|field| {
                    death.get(field).is_none() || death.get(field) == actual.get(field)
                })
        });
        results.push(json!({"name":"death","passed":passed,"expected":death}));
    }
    if let Some(expected) = assertions
        .get("final_player")
        .and_then(serde_json::Value::as_object)
    {
        let actual = diagnostics.pointer("/trace_summary/last");
        for (field, range) in expected {
            let value = actual
                .and_then(|player| player.get(field))
                .and_then(serde_json::Value::as_f64);
            let minimum = range.get("min").and_then(serde_json::Value::as_f64);
            let maximum = range.get("max").and_then(serde_json::Value::as_f64);
            let passed = value.is_some_and(|value| {
                minimum.is_none_or(|min| value >= min) && maximum.is_none_or(|max| value <= max)
            });
            results.push(json!({"name":format!("final_player:{field}"),"passed":passed,"expected":range,"actual":value}));
        }
    }
    results
}

fn apply_cli_input(
    host: &mut HeadlessHost,
    run_tick: u64,
    press_keys: &[u16],
    press_restart: bool,
    hold_keys: &[u16],
    input_script: Option<&RuntimeInputScript>,
    scripted_input_state: &mut RuntimeInputScriptState,
) {
    let mut states = HashMap::<RuntimeButton, ButtonState>::new();
    let script_frame = input_script.and_then(|script| script.ticks.get(&run_tick));
    let previous_script_holds = scripted_input_state.held_keys.clone();

    if let Some(frame) = script_frame {
        for key in &frame.release_keys {
            scripted_input_state.held_keys.remove(key);
        }
        for key in &frame.hold_keys {
            scripted_input_state.held_keys.insert(*key);
        }
    }

    for key in hold_keys {
        set_button_state(
            &mut states,
            *key,
            ButtonState {
                pressed: true,
                just_pressed: run_tick == 0,
                just_released: false,
            },
        );
    }

    for key in &scripted_input_state.held_keys {
        set_button_state(
            &mut states,
            *key,
            ButtonState {
                pressed: true,
                just_pressed: script_frame
                    .map(|frame| {
                        frame.hold_keys.contains(key) && !previous_script_holds.contains(key)
                    })
                    .unwrap_or(false),
                just_released: false,
            },
        );
    }

    if run_tick == 0 {
        if press_restart {
            states.insert(
                RuntimeButton::Restart,
                ButtonState {
                    pressed: true,
                    just_pressed: true,
                    just_released: false,
                },
            );
        }
        for key in press_keys {
            set_button_state(
                &mut states,
                *key,
                ButtonState {
                    pressed: true,
                    just_pressed: true,
                    just_released: false,
                },
            );
        }
    }

    if let Some(frame) = script_frame {
        for key in &frame.press_keys {
            set_button_state(
                &mut states,
                *key,
                ButtonState {
                    pressed: true,
                    just_pressed: true,
                    just_released: false,
                },
            );
        }
        for key in &frame.release_keys {
            set_button_state(
                &mut states,
                *key,
                ButtonState {
                    pressed: false,
                    just_pressed: false,
                    just_released: true,
                },
            );
        }
    }

    host.input.replace_button_states(states);
}

fn set_button_state(
    states: &mut HashMap<RuntimeButton, ButtonState>,
    key: u16,
    state: ButtonState,
) {
    states.insert(RuntimeButton::Keyboard(key), state);
}

#[derive(Debug, serde::Serialize)]
struct RuntimeBlockerSummary {
    key: String,
    code: String,
    count: usize,
    first: String,
}

#[derive(Debug, serde::Serialize)]
struct RuntimeEventEntry {
    code: String,
    message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    room: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    from_room: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    to_room: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    tick: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    block_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    object: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    event_tag: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    runtime_id: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    x: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    y: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    reason: Option<String>,
}

#[derive(Debug, serde::Deserialize)]
struct RuntimeInputScript {
    #[serde(default)]
    ticks: HashMap<u64, RuntimeInputScriptTick>,
}

#[derive(Debug, serde::Deserialize)]
struct RuntimeInputScriptFile {
    #[serde(default)]
    ticks: Vec<RuntimeInputScriptTickRow>,
}

#[derive(Debug, serde::Deserialize)]
struct RuntimeInputScriptTickRow {
    tick: u64,
    #[serde(default)]
    press_keys: Vec<u16>,
    #[serde(default)]
    hold_keys: Vec<u16>,
    #[serde(default)]
    release_keys: Vec<u16>,
}

#[derive(Debug, Default, serde::Deserialize)]
struct RuntimeInputScriptTick {
    #[serde(default)]
    press_keys: Vec<u16>,
    #[serde(default)]
    hold_keys: Vec<u16>,
    #[serde(default)]
    release_keys: Vec<u16>,
}

#[derive(Debug, Default)]
struct RuntimeInputScriptState {
    held_keys: HashSet<u16>,
}

#[derive(Debug, serde::Serialize)]
struct PlayerTraceEntry {
    tick: u64,
    room_id: Option<usize>,
    room: Option<String>,
    runtime_id: usize,
    instance_id: i32,
    object_id: usize,
    object: String,
    x: f64,
    y: f64,
    hspeed: f64,
    vspeed: f64,
    facing_left: bool,
    alive: bool,
    grounded: bool,
    jump_active: bool,
    jump_hold_frames: u32,
    jump_cut_applied: bool,
    jump_button_key: u16,
    jump_pressed: bool,
    jump_just_pressed: bool,
    jump_just_released: bool,
    active_keys: Vec<String>,
    diagnostic_count: usize,
}

#[derive(Debug, serde::Serialize)]
struct PlayerTraceSummary {
    sample_count: usize,
    first: Option<PlayerTraceComparableFrame>,
    last: Option<PlayerTraceComparableFrame>,
    min_x: Option<f64>,
    max_x: Option<f64>,
    min_y: Option<f64>,
    max_y: Option<f64>,
    max_abs_hspeed: f64,
    max_abs_vspeed: f64,
    rooms: Vec<PlayerTraceRoomSegment>,
}

#[derive(Debug, serde::Serialize)]
struct PlayerTraceComparableFrame {
    tick: u64,
    room_id: Option<usize>,
    room: Option<String>,
    runtime_id: usize,
    instance_id: i32,
    object_id: usize,
    object: String,
    x: f64,
    y: f64,
    hspeed: f64,
    vspeed: f64,
    alive: bool,
    grounded: bool,
    jump_active: bool,
    jump_hold_frames: u32,
    jump_cut_applied: bool,
    jump_pressed: bool,
    jump_just_pressed: bool,
    jump_just_released: bool,
    diagnostic_count: usize,
}

#[derive(Debug, serde::Serialize)]
struct PlayerTraceRoomSegment {
    room_id: Option<usize>,
    room: Option<String>,
    first_tick: u64,
    last_tick: u64,
    sample_count: usize,
}

fn maybe_collect_player_trace(
    core: &RuntimeCore,
    trace_every: u32,
    player_trace: &mut Vec<PlayerTraceEntry>,
) {
    let tick = core.tick_count();
    if !tick.is_multiple_of(u64::from(trace_every)) {
        return;
    }

    let snapshot = core.snapshot();
    let Some(player) = snapshot.player else {
        return;
    };
    player_trace.push(PlayerTraceEntry {
        tick,
        room_id: snapshot.room_id,
        room: snapshot.room_name,
        runtime_id: player.runtime_id,
        instance_id: player.instance_id,
        object_id: player.object_id,
        object: player.object_name,
        x: player.x,
        y: player.y,
        hspeed: player.hspeed,
        vspeed: player.vspeed,
        facing_left: player.facing_left,
        alive: player.alive,
        grounded: player.jump.grounded,
        jump_active: player.jump.active,
        jump_hold_frames: player.jump.hold_frames,
        jump_cut_applied: player.jump.cut_applied,
        jump_button_key: snapshot.input_trace.jump_button_key,
        jump_pressed: snapshot.input_trace.jump_pressed,
        jump_just_pressed: snapshot.input_trace.jump_just_pressed,
        jump_just_released: snapshot.input_trace.jump_just_released,
        active_keys: snapshot.input_trace.active_keys,
        diagnostic_count: snapshot.diagnostics.len(),
    });
}

fn summarize_player_trace(trace: &[PlayerTraceEntry]) -> PlayerTraceSummary {
    let first = trace.first().map(comparable_trace_frame);
    let last = trace.last().map(comparable_trace_frame);
    let mut min_x: Option<f64> = None;
    let mut max_x: Option<f64> = None;
    let mut min_y: Option<f64> = None;
    let mut max_y: Option<f64> = None;
    let mut max_abs_hspeed = 0.0_f64;
    let mut max_abs_vspeed = 0.0_f64;
    let mut rooms = Vec::<PlayerTraceRoomSegment>::new();

    for entry in trace {
        min_x = Some(min_x.map_or(entry.x, |value| value.min(entry.x)));
        max_x = Some(max_x.map_or(entry.x, |value| value.max(entry.x)));
        min_y = Some(min_y.map_or(entry.y, |value| value.min(entry.y)));
        max_y = Some(max_y.map_or(entry.y, |value| value.max(entry.y)));
        max_abs_hspeed = max_abs_hspeed.max(entry.hspeed.abs());
        max_abs_vspeed = max_abs_vspeed.max(entry.vspeed.abs());

        match rooms.last_mut() {
            Some(segment) if segment.room_id == entry.room_id && segment.room == entry.room => {
                segment.last_tick = entry.tick;
                segment.sample_count += 1;
            }
            _ => rooms.push(PlayerTraceRoomSegment {
                room_id: entry.room_id,
                room: entry.room.clone(),
                first_tick: entry.tick,
                last_tick: entry.tick,
                sample_count: 1,
            }),
        }
    }

    PlayerTraceSummary {
        sample_count: trace.len(),
        first,
        last,
        min_x,
        max_x,
        min_y,
        max_y,
        max_abs_hspeed,
        max_abs_vspeed,
        rooms,
    }
}

fn comparable_trace_frame(entry: &PlayerTraceEntry) -> PlayerTraceComparableFrame {
    PlayerTraceComparableFrame {
        tick: entry.tick,
        room_id: entry.room_id,
        room: entry.room.clone(),
        runtime_id: entry.runtime_id,
        instance_id: entry.instance_id,
        object_id: entry.object_id,
        object: entry.object.clone(),
        x: entry.x,
        y: entry.y,
        hspeed: entry.hspeed,
        vspeed: entry.vspeed,
        alive: entry.alive,
        grounded: entry.grounded,
        jump_active: entry.jump_active,
        jump_hold_frames: entry.jump_hold_frames,
        jump_cut_applied: entry.jump_cut_applied,
        jump_pressed: entry.jump_pressed,
        jump_just_pressed: entry.jump_just_pressed,
        jump_just_released: entry.jump_just_released,
        diagnostic_count: entry.diagnostic_count,
    }
}

fn collect_runtime_blockers(
    diagnostics: &[RuntimeDiagnostic],
    seen_messages: &mut HashSet<String>,
    blockers: &mut HashMap<String, RuntimeBlockerSummary>,
) {
    for diagnostic in diagnostics {
        if !diagnostic.code.starts_with("runtime-unsupported-") {
            continue;
        }
        let message_key = format!("{}:{}", diagnostic.code, diagnostic.message);
        if !seen_messages.insert(message_key) {
            continue;
        }
        let key = runtime_blocker_key(diagnostic);
        let entry = blockers
            .entry(key.clone())
            .or_insert_with(|| RuntimeBlockerSummary {
                key,
                code: diagnostic.code.clone(),
                count: 0,
                first: diagnostic.message.clone(),
            });
        entry.count += 1;
    }
}

fn collect_runtime_events(
    diagnostics: &[RuntimeDiagnostic],
    seen_messages: &mut HashSet<String>,
    events: &mut Vec<RuntimeEventEntry>,
) {
    for diagnostic in diagnostics {
        if !is_runtime_event_code(&diagnostic.code) {
            continue;
        }
        let message_key = format!("{}:{}", diagnostic.code, diagnostic.message);
        if !seen_messages.insert(message_key) {
            continue;
        }
        events.push(runtime_event_entry(diagnostic));
    }
}

fn runtime_event_entry(diagnostic: &RuntimeDiagnostic) -> RuntimeEventEntry {
    RuntimeEventEntry {
        code: diagnostic.code.clone(),
        message: diagnostic.message.clone(),
        room: message_field(&diagnostic.message, "room").and_then(parse_usize_field),
        from_room: message_field(&diagnostic.message, "from_room").and_then(parse_usize_field),
        to_room: message_field(&diagnostic.message, "to_room").and_then(parse_usize_field),
        tick: message_field(&diagnostic.message, "tick").and_then(parse_u64_field),
        block_id: message_field(&diagnostic.message, "block_id").map(str::to_owned),
        object: message_field(&diagnostic.message, "object").map(str::to_owned),
        event_tag: message_field(&diagnostic.message, "event_tag").map(str::to_owned),
        runtime_id: message_field(&diagnostic.message, "runtime_id").and_then(parse_usize_field),
        x: message_field(&diagnostic.message, "x").and_then(parse_f64_field),
        y: message_field(&diagnostic.message, "y").and_then(parse_f64_field),
        reason: message_field(&diagnostic.message, "reason").map(str::to_owned),
    }
}

fn is_runtime_event_code(code: &str) -> bool {
    matches!(
        code,
        "runtime-room-changed"
            | "runtime-room-restart-requested"
            | "runtime-player-died"
            | "runtime-instance-created"
            | "runtime-instance-destroyed"
    )
}

fn read_runtime_input_script(
    path: &PathBuf,
) -> Result<RuntimeInputScript, Box<dyn std::error::Error>> {
    let parsed: RuntimeInputScriptFile = serde_json::from_slice(&fs::read(path)?)?;
    let mut ticks = HashMap::<u64, RuntimeInputScriptTick>::new();
    for row in parsed.ticks {
        let entry = ticks.entry(row.tick).or_default();
        entry.press_keys.extend(row.press_keys);
        entry.hold_keys.extend(row.hold_keys);
        entry.release_keys.extend(row.release_keys);
    }
    Ok(RuntimeInputScript { ticks })
}

fn runtime_blocker_key(diagnostic: &RuntimeDiagnostic) -> String {
    if let Some(function) = message_field(&diagnostic.message, "function") {
        return format!("{}:{}", diagnostic.code, function);
    }
    if let Some(statement_kind) = message_field(&diagnostic.message, "statement_kind") {
        return format!("{}:{}", diagnostic.code, statement_kind);
    }
    diagnostic.code.clone()
}

fn message_field<'a>(message: &'a str, field: &str) -> Option<&'a str> {
    let prefix = format!("{field}=");
    message
        .split_whitespace()
        .find_map(|part| part.strip_prefix(&prefix))
}

fn parse_usize_field(value: &str) -> Option<usize> {
    value.parse().ok()
}

fn parse_u64_field(value: &str) -> Option<u64> {
    value.parse().ok()
}

fn parse_f64_field(value: &str) -> Option<f64> {
    value.parse().ok()
}
