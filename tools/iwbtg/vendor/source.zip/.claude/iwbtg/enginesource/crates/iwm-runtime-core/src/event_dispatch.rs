use std::collections::HashMap;

use crate::helpers::bounds_at;
use iwm_runtime_model::ObjectDefinition;

use crate::{RuntimeInstance, RuntimePackage, RuntimeRoomState};

const COLLISION_SPATIAL_CELL_SIZE: i32 = 64;

#[derive(Clone)]
pub(crate) enum RuntimeEventSelector {
    Create,
    StepBegin,
    Step,
    StepEnd,
    Draw,
    Destroy,
    Alarm(u32),
    KeyboardHeld(u16),
    KeyboardPressed(u16),
    KeyboardReleased(u16),
    MouseHeld {
        button: u8,
        global: bool,
    },
    MousePressed {
        button: u8,
        global: bool,
    },
    MouseReleased {
        button: u8,
        global: bool,
    },
    OtherAnimationEnd,
    OtherRoomStart,
    OtherOutside,
    OtherBoundary,
    OtherEndOfPath,
    Timeline,
    #[cfg_attr(not(test), allow(dead_code))]
    Collision {
        target_object_id: usize,
    },
}

#[derive(Debug, Default)]
pub(crate) struct RuntimeEventDispatchTables {
    pub(crate) entry_indices_by_event_tag_and_object_id:
        HashMap<String, HashMap<usize, Vec<usize>>>,
    pub(crate) step_entry_indices_by_object_id: HashMap<usize, Vec<usize>>,
    pub(crate) create_entry_indices_by_object_id: HashMap<usize, Vec<usize>>,
    pub(crate) destroy_entry_indices_by_object_id: HashMap<usize, Vec<usize>>,
    pub(crate) collision_entry_indices_by_owner_and_target: HashMap<(usize, usize), Vec<usize>>,
}

pub(crate) fn runtime_event_dispatch_tables(
    package: &RuntimePackage,
    lowered_logic_index: &HashMap<String, usize>,
) -> RuntimeEventDispatchTables {
    let mut tables = RuntimeEventDispatchTables::default();
    let event_specs = runtime_event_specs(package);

    for object in &package.objects {
        for (event_type, sub_event, event_tag) in &event_specs {
            let block_ids = object_event_block_ids_by_parts(
                &package.objects,
                object.id,
                *event_type,
                *sub_event,
                event_tag,
            );
            let entry_indices = block_ids
                .iter()
                .filter_map(|block_id| lowered_logic_index.get(block_id).copied())
                .collect::<Vec<_>>();
            if entry_indices.is_empty() {
                continue;
            }

            tables
                .entry_indices_by_event_tag_and_object_id
                .entry(event_tag.clone())
                .or_default()
                .insert(object.id, entry_indices.clone());

            match (*event_type, *sub_event, event_tag.as_str()) {
                (3, 0, "step") => {
                    tables
                        .step_entry_indices_by_object_id
                        .insert(object.id, entry_indices);
                }
                (0, 0, "create") => {
                    tables
                        .create_entry_indices_by_object_id
                        .insert(object.id, entry_indices);
                }
                (1, 0, "destroy") => {
                    tables
                        .destroy_entry_indices_by_object_id
                        .insert(object.id, entry_indices);
                }
                (4, target_object_id, "collision") => {
                    tables
                        .collision_entry_indices_by_owner_and_target
                        .insert((object.id, target_object_id as usize), entry_indices);
                }
                _ => {}
            }
        }
    }

    tables
}

pub(crate) fn object_event_block_ids(
    package: &RuntimePackage,
    object_id: usize,
    selector: RuntimeEventSelector,
) -> Vec<String> {
    let (event_type, sub_event, wanted) = event_selector_parts(&selector);
    object_event_block_ids_by_parts(&package.objects, object_id, event_type, sub_event, &wanted)
}

fn object_event_block_ids_by_parts(
    objects: &[ObjectDefinition],
    object_id: usize,
    event_type: usize,
    sub_event: u32,
    wanted: &str,
) -> Vec<String> {
    let mut current_object_id = Some(object_id);
    let mut block_ids = Vec::new();
    while let Some(id) = current_object_id {
        let Some(object) = objects.iter().find(|object| object.id == id) else {
            break;
        };

        for event in &object.events {
            if event.event_type == event_type
                && event.sub_event == sub_event
                && event.event_tag == wanted
            {
                block_ids.push(event.block_id.clone());
            }
        }

        if !block_ids.is_empty() {
            break;
        }

        current_object_id = object_parent_id(objects, id);
    }

    block_ids
}

fn runtime_event_specs(package: &RuntimePackage) -> Vec<(usize, u32, String)> {
    let mut specs = Vec::new();
    for object in &package.objects {
        for event in &object.events {
            let spec = (event.event_type, event.sub_event, event.event_tag.clone());
            if !specs.contains(&spec) {
                specs.push(spec);
            }
        }
    }
    specs
}

pub(crate) fn event_owner_id_for_block_id(
    objects: &[ObjectDefinition],
    block_id: &str,
) -> Option<usize> {
    objects.iter().find_map(|object| {
        object
            .events
            .iter()
            .any(|event| event.block_id == block_id)
            .then_some(object.id)
    })
}

pub(crate) fn inherited_event_block_id(
    objects: &[ObjectDefinition],
    owner_object_id: usize,
    selector: &RuntimeEventSelector,
) -> Option<(usize, String)> {
    let (event_type, sub_event, wanted) = event_selector_parts(selector);
    let mut current_object_id = object_parent_id(objects, owner_object_id);
    while let Some(id) = current_object_id {
        let object = objects.iter().find(|object| object.id == id)?;
        if let Some(event) = object.events.iter().find(|event| {
            event.event_type == event_type
                && event.sub_event == sub_event
                && event.event_tag == wanted
        }) {
            return Some((object.id, event.block_id.clone()));
        }
        current_object_id = object_parent_id(objects, object.id);
    }

    None
}

pub(crate) fn event_selector_parts(selector: &RuntimeEventSelector) -> (usize, u32, String) {
    match selector {
        RuntimeEventSelector::Create => (0usize, 0u32, "create".to_string()),
        RuntimeEventSelector::StepBegin => (3usize, 1u32, "step:begin".to_string()),
        RuntimeEventSelector::Step => (3usize, 0u32, "step".to_string()),
        RuntimeEventSelector::StepEnd => (3usize, 2u32, "step:end".to_string()),
        RuntimeEventSelector::Draw => (8usize, 0u32, "draw".to_string()),
        RuntimeEventSelector::Destroy => (1usize, 0u32, "destroy".to_string()),
        RuntimeEventSelector::Alarm(slot) => (2usize, *slot, format!("alarm:{slot}")),
        RuntimeEventSelector::KeyboardHeld(key) => (
            5usize,
            *key as u32,
            format!("keyboard:{}", format_key_name(*key)),
        ),
        RuntimeEventSelector::KeyboardPressed(key) => (
            9usize,
            *key as u32,
            format!("keypress:{}", format_key_name(*key)),
        ),
        RuntimeEventSelector::KeyboardReleased(key) => (
            10usize,
            *key as u32,
            format!("keyrelease:{}", format_key_name(*key)),
        ),
        RuntimeEventSelector::MouseHeld { button, global } => {
            mouse_event_parts(*button, *global, 0, 50, "")
        }
        RuntimeEventSelector::MousePressed { button, global } => {
            mouse_event_parts(*button, *global, 4, 53, "-pressed")
        }
        RuntimeEventSelector::MouseReleased { button, global } => {
            mouse_event_parts(*button, *global, 7, 56, "-released")
        }
        RuntimeEventSelector::OtherAnimationEnd => {
            (7usize, 7u32, "other:animation-end".to_string())
        }
        RuntimeEventSelector::OtherRoomStart => (7usize, 4u32, "other:room-start".to_string()),
        RuntimeEventSelector::OtherOutside => (7usize, 0u32, "other:outside".to_string()),
        RuntimeEventSelector::OtherBoundary => (7usize, 1u32, "other:boundary".to_string()),
        RuntimeEventSelector::OtherEndOfPath => (7usize, 8u32, "other:end-of-path".to_string()),
        RuntimeEventSelector::Timeline => (usize::MAX, 0u32, "timeline".to_string()),
        RuntimeEventSelector::Collision { target_object_id } => {
            (4usize, *target_object_id as u32, "collision".to_string())
        }
    }
}

fn mouse_event_parts(
    button: u8,
    global: bool,
    local_base: u32,
    global_base: u32,
    suffix: &str,
) -> (usize, u32, String) {
    let button_name = ["left", "right", "middle"]
        .get(button as usize)
        .copied()
        .unwrap_or("unknown");
    let scope = if global { "global-" } else { "" };
    let sub_event = if global { global_base } else { local_base } + button as u32;
    (
        6usize,
        sub_event,
        format!("mouse:{scope}{button_name}{suffix}"),
    )
}

fn object_parent_id(objects: &[ObjectDefinition], object_id: usize) -> Option<usize> {
    objects
        .iter()
        .find(|object| object.id == object_id)
        .and_then(|object| object.parent_index.try_into().ok())
}

#[cfg(test)]
pub(crate) fn runtime_instance_indices_by_object_id(
    room: &RuntimeRoomState,
) -> HashMap<usize, Vec<usize>> {
    runtime_instance_indices_by_object_id_from_instances(&room.instances)
}

pub(crate) fn runtime_instance_indices_by_object_id_from_instances(
    instances: &[RuntimeInstance],
) -> HashMap<usize, Vec<usize>> {
    let mut indices = HashMap::new();
    for (index, instance) in instances.iter().enumerate() {
        if instance.is_active() {
            indices
                .entry(instance.object_id)
                .or_insert_with(Vec::new)
                .push(index);
        }
    }
    indices
}

#[derive(Debug, Default)]
pub(crate) struct RuntimeCollisionSpatialIndex {
    cells_by_object_id: HashMap<usize, HashMap<i64, Vec<usize>>>,
    solid_cells: HashMap<i64, Vec<usize>>,
}

#[derive(Debug, Default)]
pub(crate) struct RuntimeCollisionScratch {
    candidates: Vec<usize>,
    candidate_marks: Vec<u32>,
    mark_epoch: u32,
}

impl RuntimeCollisionSpatialIndex {
    pub(crate) fn rebuild(&mut self, room: &RuntimeRoomState) {
        self.clear_cells();
        for (instance_index, instance) in room.instances.iter().enumerate() {
            if !instance.is_active() {
                continue;
            }
            let (left, top, right, bottom) = bounds_at(instance, instance.x, instance.y);
            let object_cells = self
                .cells_by_object_id
                .entry(instance.object_id)
                .or_default();
            for_each_cell_for_bounds(left, top, right, bottom, |cell| {
                object_cells.entry(cell).or_default().push(instance_index);
                if instance.solid {
                    self.solid_cells
                        .entry(cell)
                        .or_default()
                        .push(instance_index);
                }
            });
        }
    }

    pub(crate) fn candidate_indices(
        &self,
        object_id: usize,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
    ) -> Vec<usize> {
        let mut scratch = RuntimeCollisionScratch::default();
        self.candidate_indices_into(object_id, instance, x, y, &mut scratch);
        scratch.candidates().to_vec()
    }

    pub(crate) fn candidate_indices_into(
        &self,
        object_id: usize,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
        scratch: &mut RuntimeCollisionScratch,
    ) {
        let Some(cells) = self.cells_by_object_id.get(&object_id) else {
            scratch.clear_candidates();
            return;
        };
        candidate_indices_from_cells(cells, instance, x, y, scratch);
    }

    pub(crate) fn motion_candidate_indices_into(
        &self,
        object_id: usize,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
        scratch: &mut RuntimeCollisionScratch,
    ) {
        let Some(cells) = self.cells_by_object_id.get(&object_id) else {
            scratch.clear_candidates();
            return;
        };
        candidate_indices_from_motion_cells(cells, instance, x, y, scratch);
    }

    pub(crate) fn solid_candidate_indices(
        &self,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
    ) -> Vec<usize> {
        let mut scratch = RuntimeCollisionScratch::default();
        self.solid_candidate_indices_into(instance, x, y, &mut scratch);
        scratch.candidates().to_vec()
    }

    pub(crate) fn solid_candidate_indices_into(
        &self,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
        scratch: &mut RuntimeCollisionScratch,
    ) {
        candidate_indices_from_cells(&self.solid_cells, instance, x, y, scratch);
    }

    fn clear_cells(&mut self) {
        for object_cells in self.cells_by_object_id.values_mut() {
            for indices in object_cells.values_mut() {
                indices.clear();
            }
        }
        for indices in self.solid_cells.values_mut() {
            indices.clear();
        }
    }
}

impl RuntimeCollisionScratch {
    pub(crate) fn candidates(&self) -> &[usize] {
        &self.candidates
    }

    fn clear_candidates(&mut self) {
        self.candidates.clear();
    }

    fn begin_query(&mut self) {
        self.candidates.clear();
        self.mark_epoch = self.mark_epoch.wrapping_add(1);
        if self.mark_epoch == 0 {
            self.candidate_marks.fill(0);
            self.mark_epoch = 1;
        }
    }

    fn mark_candidate(&mut self, index: usize) -> bool {
        if index >= self.candidate_marks.len() {
            self.candidate_marks.resize(index + 1, 0);
        }
        if self.candidate_marks[index] == self.mark_epoch {
            return false;
        }
        self.candidate_marks[index] = self.mark_epoch;
        true
    }
}

fn candidate_indices_from_cells(
    cells: &HashMap<i64, Vec<usize>>,
    instance: &RuntimeInstance,
    x: f64,
    y: f64,
    scratch: &mut RuntimeCollisionScratch,
) {
    scratch.begin_query();
    let (left, top, right, bottom) = bounds_at(instance, x, y);
    for_each_cell_for_bounds(left, top, right, bottom, |cell| {
        let Some(indices) = cells.get(&cell) else {
            return;
        };
        for index in indices {
            if scratch.mark_candidate(*index) {
                scratch.candidates.push(*index);
            }
        }
    });
}

fn candidate_indices_from_motion_cells(
    cells: &HashMap<i64, Vec<usize>>,
    instance: &RuntimeInstance,
    x: f64,
    y: f64,
    scratch: &mut RuntimeCollisionScratch,
) {
    scratch.begin_query();
    let (left, top, right, bottom) = bounds_at(instance, x, y);
    let (previous_left, previous_top, previous_right, previous_bottom) =
        bounds_at(instance, instance.previous_x, instance.previous_y);
    for_each_cell_for_bounds(
        left.min(previous_left),
        top.min(previous_top),
        right.max(previous_right),
        bottom.max(previous_bottom),
        |cell| {
            let Some(indices) = cells.get(&cell) else {
                return;
            };
            for index in indices {
                if scratch.mark_candidate(*index) {
                    scratch.candidates.push(*index);
                }
            }
        },
    );
}

fn for_each_cell_for_bounds(
    left: i32,
    top: i32,
    right: i32,
    bottom: i32,
    mut visit: impl FnMut(i64),
) {
    let right = (right - 1).max(left);
    let bottom = (bottom - 1).max(top);
    let left_cell = left.div_euclid(COLLISION_SPATIAL_CELL_SIZE);
    let right_cell = right.div_euclid(COLLISION_SPATIAL_CELL_SIZE);
    let top_cell = top.div_euclid(COLLISION_SPATIAL_CELL_SIZE);
    let bottom_cell = bottom.div_euclid(COLLISION_SPATIAL_CELL_SIZE);

    for y in top_cell..=bottom_cell {
        for x in left_cell..=right_cell {
            visit(pack_cell_key(x, y));
        }
    }
}

fn pack_cell_key(x: i32, y: i32) -> i64 {
    ((x as i64) << 32) | (y as u32 as i64)
}

pub(crate) fn collision_event_target_object_ids(
    package: &RuntimePackage,
    object_id: usize,
) -> Vec<usize> {
    // GM8 inherits each (event_type, sub_event) pair independently: a child's
    // collision event only overrides the parent's event with the same target,
    // so the active target set is the union across the whole parent chain.
    let mut current_object_id = Some(object_id);
    let mut target_ids = Vec::new();
    while let Some(id) = current_object_id {
        let Some(object) = package.objects.iter().find(|object| object.id == id) else {
            break;
        };

        for event in &object.events {
            if event.event_type == 4 && event.event_tag == "collision" {
                let target_id = event.sub_event as usize;
                if !target_ids.contains(&target_id) {
                    target_ids.push(target_id);
                }
            }
        }

        current_object_id = object.parent_index.try_into().ok();
    }

    target_ids
}

pub(crate) fn object_ids_matching_or_inheriting_from(
    package: &RuntimePackage,
    wanted_object_id: usize,
) -> Vec<usize> {
    package
        .objects
        .iter()
        .filter(|object| object_matches_or_inherits_from(package, object.id, wanted_object_id))
        .map(|object| object.id)
        .collect()
}

fn object_matches_or_inherits_from(
    package: &RuntimePackage,
    object_id: usize,
    wanted_object_id: usize,
) -> bool {
    let mut current_id = Some(object_id);
    while let Some(id) = current_id {
        if id == wanted_object_id {
            return true;
        }
        current_id = package
            .objects
            .iter()
            .find(|object| object.id == id)
            .and_then(|object| object.parent_index.try_into().ok());
    }
    false
}

fn format_key_name(sub_event: u16) -> String {
    let key = sub_event as u8 as char;
    if key.is_ascii_alphanumeric() {
        key.to_ascii_lowercase().to_string()
    } else {
        format!("0x{:02x}", sub_event as u8)
    }
}
