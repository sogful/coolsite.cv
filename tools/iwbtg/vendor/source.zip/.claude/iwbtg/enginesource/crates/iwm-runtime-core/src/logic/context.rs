use std::cell::Cell;
use std::collections::HashMap;
use std::path::Path;

use iwm_runtime_host::{RuntimeButton, RuntimeHost, RuntimeHostError};

use super::overlay::RuntimeSparseInstanceOverlay;
use crate::event_dispatch::RuntimeCollisionSpatialIndex;
use crate::tick_context::{RuntimeObjectIndex, RuntimeObjectQueryScratch};
use crate::{RuntimeInstance, RuntimeRoomState, RuntimeValue};

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub(crate) struct StepExecutionResult {
    pub interrupted: bool,
    pub player_motion_changed: bool,
    pub player_jump_owned_by_script: bool,
    pub player_motion_script_managed: bool,
    pub player_position_script_managed: bool,
}

#[derive(Debug, Default)]
pub(crate) struct RuntimeExecutionScope {
    locals: HashMap<String, Option<RuntimeValue>>,
}

#[derive(Debug, Clone)]
pub(crate) struct RuntimeInstanceCreateRequest {
    pub(super) object_id: usize,
    pub(super) runtime_id: usize,
    pub(super) instance_id: i32,
    pub(super) x: f64,
    pub(super) y: f64,
    pub(super) post_create_vars: HashMap<String, RuntimeValue>,
}

#[derive(Debug, Default)]
pub(crate) struct RuntimeBinaryFileState {
    next_handle: i32,
    handles: HashMap<i32, RuntimeBinaryFileHandle>,
}

#[derive(Debug)]
struct RuntimeBinaryFileHandle {
    path: String,
    bytes: Vec<u8>,
    cursor: usize,
    readable: bool,
    writable: bool,
}

impl RuntimeBinaryFileState {
    pub(crate) fn open<H: RuntimeHost>(&mut self, host: &H, path: String, mode: i32) -> i32 {
        let handle = self.next_handle.max(1);
        self.next_handle = handle.saturating_add(1);
        let (readable, writable) = match mode {
            0 => (true, false),
            2 => (true, true),
            _ => (false, true),
        };
        let bytes = if readable {
            host.read(Path::new(&path)).unwrap_or_default()
        } else {
            Vec::new()
        };
        self.handles.insert(
            handle,
            RuntimeBinaryFileHandle {
                path,
                bytes,
                cursor: 0,
                readable,
                writable,
            },
        );
        handle
    }

    pub(crate) fn read_byte(&mut self, handle: i32) -> u8 {
        let Some(file) = self.handles.get_mut(&handle) else {
            return 0;
        };
        if !file.readable {
            return 0;
        }
        let byte = file.bytes.get(file.cursor).copied().unwrap_or(0);
        file.cursor = file.cursor.saturating_add(1);
        byte
    }

    pub(crate) fn write_byte(&mut self, handle: i32, byte: u8) {
        let Some(file) = self.handles.get_mut(&handle) else {
            return;
        };
        if !file.writable {
            return;
        }
        if file.cursor >= file.bytes.len() {
            file.bytes.resize(file.cursor.saturating_add(1), 0);
        }
        file.bytes[file.cursor] = byte;
        file.cursor = file.cursor.saturating_add(1);
    }

    pub(crate) fn seek(&mut self, handle: i32, cursor: usize) {
        if let Some(file) = self.handles.get_mut(&handle) {
            file.cursor = cursor;
        }
    }

    pub(crate) fn close<H: RuntimeHost>(
        &mut self,
        host: &mut H,
        handle: i32,
    ) -> Result<(), RuntimeHostError> {
        let Some(file) = self.handles.remove(&handle) else {
            return Ok(());
        };
        if file.writable {
            host.write_temp(Path::new(&file.path), &file.bytes)?;
        }
        Ok(())
    }
}

/// GM8 text-file handles.
///
/// Mirrors [`RuntimeBinaryFileState`]: the whole file lives in memory while the
/// handle is open and is flushed through the same [`RuntimeFileHost`] on close,
/// so browser saves land in the package-scoped `localStorage` store that the
/// binary slice already uses.
#[derive(Debug, Default)]
pub(crate) struct RuntimeTextFileState {
    next_handle: i32,
    handles: HashMap<i32, RuntimeTextFileHandle>,
}

#[derive(Debug)]
struct RuntimeTextFileHandle {
    path: String,
    text: String,
    /// Byte offset into `text`. Only ever moved to a UTF-8 boundary.
    cursor: usize,
    readable: bool,
    writable: bool,
}

impl RuntimeTextFileState {
    /// `mode` follows GM8: 0 = read, 1 = write (truncate), 2 = append.
    pub(crate) fn open<H: RuntimeHost>(&mut self, host: &H, path: String, mode: i32) -> i32 {
        let handle = self.next_handle.max(1);
        self.next_handle = handle.saturating_add(1);
        let (readable, writable) = match mode {
            0 => (true, false),
            _ => (false, true),
        };
        let text = if mode == 0 || mode == 2 {
            host.read(Path::new(&path))
                .map(|bytes| String::from_utf8_lossy(&bytes).into_owned())
                .unwrap_or_default()
        } else {
            String::new()
        };
        let cursor = if mode == 2 { text.len() } else { 0 };
        self.handles.insert(
            handle,
            RuntimeTextFileHandle {
                path,
                text,
                cursor,
                readable,
                writable,
            },
        );
        handle
    }

    pub(crate) fn write_string(&mut self, handle: i32, value: &str) {
        let Some(file) = self.handles.get_mut(&handle) else {
            return;
        };
        if !file.writable {
            return;
        }
        file.text.push_str(value);
        file.cursor = file.text.len();
    }

    pub(crate) fn writeln(&mut self, handle: i32) {
        self.write_string(handle, "\r\n");
    }

    /// Reads from the cursor to the end of the current line without consuming
    /// the line terminator, matching `file_text_read_string`.
    pub(crate) fn read_string(&mut self, handle: i32) -> String {
        let Some(file) = self.handles.get_mut(&handle) else {
            return String::new();
        };
        if !file.readable {
            return String::new();
        }
        let end = line_end(&file.text, file.cursor);
        let value = file.text[file.cursor..end].to_string();
        file.cursor = end;
        value
    }

    pub(crate) fn read_real(&mut self, handle: i32) -> f64 {
        let Some(file) = self.handles.get_mut(&handle) else {
            return 0.0;
        };
        if !file.readable {
            return 0.0;
        }
        let end = line_end(&file.text, file.cursor);
        let slice = &file.text[file.cursor..end];
        let leading_blanks = slice.len() - slice.trim_start_matches([' ', '\t']).len();
        let number_len = numeric_prefix_len(&slice[leading_blanks..]);
        let value = slice[leading_blanks..leading_blanks + number_len]
            .parse::<f64>()
            .unwrap_or(0.0);
        file.cursor += leading_blanks + number_len;
        value
    }

    /// Skips the remainder of the current line, including its terminator.
    pub(crate) fn readln(&mut self, handle: i32) {
        let Some(file) = self.handles.get_mut(&handle) else {
            return;
        };
        if !file.readable {
            return;
        }
        let end = line_end(&file.text, file.cursor);
        file.cursor = skip_line_terminator(&file.text, end);
    }

    pub(crate) fn eof(&self, handle: i32) -> bool {
        self.handles
            .get(&handle)
            .map(|file| file.cursor >= file.text.len())
            .unwrap_or(true)
    }

    pub(crate) fn eoln(&self, handle: i32) -> bool {
        self.handles
            .get(&handle)
            .map(|file| file.cursor >= line_end(&file.text, file.cursor))
            .unwrap_or(true)
    }

    pub(crate) fn close<H: RuntimeHost>(
        &mut self,
        host: &mut H,
        handle: i32,
    ) -> Result<(), RuntimeHostError> {
        let Some(file) = self.handles.remove(&handle) else {
            return Ok(());
        };
        if file.writable {
            host.write_temp(Path::new(&file.path), file.text.as_bytes())?;
        }
        Ok(())
    }
}

/// Byte offset of the next `\r` or `\n` at or after `from`, else the text length.
fn line_end(text: &str, from: usize) -> usize {
    if from >= text.len() {
        return text.len();
    }
    text[from..]
        .find(['\r', '\n'])
        .map(|offset| from + offset)
        .unwrap_or(text.len())
}

fn skip_line_terminator(text: &str, at: usize) -> usize {
    let rest = &text[at.min(text.len())..];
    if rest.starts_with("\r\n") {
        at + 2
    } else if rest.starts_with('\r') || rest.starts_with('\n') {
        at + 1
    } else {
        at
    }
}

/// Length of the leading `[+-]?digits[.digits]` run, which is as much numeric
/// syntax as GM8 save files ever contain.
fn numeric_prefix_len(slice: &str) -> usize {
    let mut len = 0;
    let mut seen_dot = false;
    for (index, ch) in slice.char_indices() {
        match ch {
            '+' | '-' if index == 0 => {}
            '.' if !seen_dot => seen_dot = true,
            ch if ch.is_ascii_digit() => {}
            _ => break,
        }
        len = index + ch.len_utf8();
    }
    len
}

pub(crate) struct RuntimeRoomInstanceOverlay<'a> {
    committed_updates: Option<&'a RuntimeSparseInstanceOverlay>,
    pending_updates: RuntimeSparseInstanceOverlay,
    current_instance: Option<(usize, RuntimeInstance)>,
}

impl<'a> RuntimeRoomInstanceOverlay<'a> {
    pub(crate) fn empty() -> Self {
        Self {
            committed_updates: None,
            pending_updates: RuntimeSparseInstanceOverlay::default(),
            current_instance: None,
        }
    }

    pub(crate) fn with_current(
        committed_updates: &'a RuntimeSparseInstanceOverlay,
        pending_updates: &RuntimeSparseInstanceOverlay,
        current_index: usize,
        current_instance: &RuntimeInstance,
    ) -> Self {
        Self {
            committed_updates: Some(committed_updates),
            pending_updates: pending_updates.snapshot(),
            current_instance: Some((current_index, current_instance.clone())),
        }
    }

    pub(super) fn merge_pending_current(
        &self,
        pending_updates: &RuntimeSparseInstanceOverlay,
        current_index: usize,
        current_instance: &RuntimeInstance,
    ) -> Self {
        let mut merged_pending = self.pending_updates.snapshot();
        merged_pending.extend_from_overlay(pending_updates);
        Self {
            committed_updates: self.committed_updates,
            pending_updates: merged_pending,
            current_instance: Some((current_index, current_instance.clone())),
        }
    }

    fn instance_at<'b>(&'b self, index: usize, fallback: &'b RuntimeInstance) -> &'b RuntimeInstance
    where
        'a: 'b,
    {
        if let Some((current_index, instance)) = &self.current_instance {
            if *current_index == index {
                return instance;
            }
        }
        if let Some(instance) = self.pending_updates.get(index) {
            return instance;
        }
        if let Some(instance) = self
            .committed_updates
            .and_then(|updates| updates.get(index))
        {
            return instance;
        }
        fallback
    }

    fn extra_current_instance<'b>(&'b self, base_len: usize) -> Option<(usize, &'b RuntimeInstance)>
    where
        'a: 'b,
    {
        match &self.current_instance {
            Some((index, instance)) if *index >= base_len => Some((*index, instance)),
            _ => None,
        }
    }
}

impl RuntimeExecutionScope {
    pub(super) fn bind(&mut self, name: impl Into<String>, value: RuntimeValue) {
        self.locals.insert(name.into(), Some(value));
    }

    pub(super) fn declare(&mut self, name: &str) {
        self.locals.entry(name.to_string()).or_insert(None);
    }

    pub(super) fn get(&self, key: &str) -> Option<RuntimeValue> {
        self.locals.get(key).and_then(Clone::clone)
    }

    pub(super) fn assign(&mut self, key: &str, value: RuntimeValue) -> bool {
        if self.is_local_key(key) {
            self.locals.insert(key.to_string(), Some(value));
            true
        } else {
            false
        }
    }

    pub(super) fn is_local_key(&self, key: &str) -> bool {
        self.locals.contains_key(key)
            || key
                .split_once('[')
                .map(|(base, _)| self.locals.contains_key(base))
                .unwrap_or(false)
    }
}

pub(crate) struct RuntimeEvalContext<'a> {
    pub current_room_id: usize,
    pub room_speed: u32,
    pub room_width: u32,
    pub room_height: u32,
    pub random_state: &'a Cell<u64>,
    pub button_states: &'a HashMap<RuntimeButton, iwm_runtime_host::ButtonState>,
    pub room_instances: &'a [RuntimeInstance],
    pub room_instance_indices_by_object_id: &'a HashMap<usize, Vec<usize>>,
    pub object_index: Option<&'a RuntimeObjectIndex>,
    pub collision_spatial_index: Option<&'a RuntimeCollisionSpatialIndex>,
    pub room_instance_overlay: RuntimeRoomInstanceOverlay<'a>,
    pub room_order: &'a [usize],
    pub other_instance: Option<&'a RuntimeInstance>,
    pub other_runtime_id: Option<usize>,
    pub place_target_ids_by_name: &'a HashMap<String, Vec<usize>>,
    pub room_ids_by_name: &'a HashMap<String, usize>,
    pub view_zero: Option<RuntimeViewValues>,
    pub zero_uninitialized_vars: bool,
}

#[derive(Debug, Clone, Copy)]
pub(crate) struct RuntimeViewValues {
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
}

impl RuntimeViewValues {
    pub(crate) fn from_room(room: &RuntimeRoomState) -> Option<Self> {
        room.views
            .iter()
            .find(|view| view.visible)
            .map(|view| Self {
                x: view.source_x,
                y: view.source_y,
                width: view.source_w,
                height: view.source_h,
            })
    }
}

impl<'a> RuntimeEvalContext<'a> {
    pub(super) fn with_other_and_overlay<'b>(
        &'b self,
        other_instance: &'b RuntimeInstance,
        room_instance_overlay: RuntimeRoomInstanceOverlay<'b>,
    ) -> RuntimeEvalContext<'b>
    where
        'a: 'b,
    {
        RuntimeEvalContext {
            current_room_id: self.current_room_id,
            room_speed: self.room_speed,
            room_width: self.room_width,
            room_height: self.room_height,
            random_state: self.random_state,
            button_states: self.button_states,
            room_instances: self.room_instances,
            room_instance_indices_by_object_id: self.room_instance_indices_by_object_id,
            object_index: self.object_index,
            collision_spatial_index: self.collision_spatial_index,
            room_instance_overlay,
            room_order: self.room_order,
            other_instance: Some(other_instance),
            other_runtime_id: Some(other_instance.runtime_id),
            place_target_ids_by_name: self.place_target_ids_by_name,
            room_ids_by_name: self.room_ids_by_name,
            view_zero: self.view_zero,
            zero_uninitialized_vars: self.zero_uninitialized_vars,
        }
    }

    pub(crate) fn other_instance(&self) -> Option<&RuntimeInstance> {
        let runtime_id = self
            .other_runtime_id
            .or_else(|| self.other_instance.map(|instance| instance.runtime_id))?;
        self.room_instances_iter()
            .find(|(_, instance)| instance.runtime_id == runtime_id)
            .map(|(_, instance)| instance)
    }

    pub(crate) fn room_instance(&self, index: usize) -> Option<&RuntimeInstance> {
        if let Some(fallback) = self.room_instances.get(index) {
            return Some(self.room_instance_overlay.instance_at(index, fallback));
        }
        self.room_instance_overlay
            .extra_current_instance(self.room_instances.len())
            .and_then(|(extra_index, instance)| (extra_index == index).then_some(instance))
    }

    pub(crate) fn room_instances_iter(
        &self,
    ) -> impl Iterator<Item = (usize, &RuntimeInstance)> + '_ {
        self.room_instances
            .iter()
            .enumerate()
            .map(|(index, instance)| {
                (
                    index,
                    self.room_instance_overlay.instance_at(index, instance),
                )
            })
            .chain(
                self.room_instance_overlay
                    .extra_current_instance(self.room_instances.len()),
            )
    }

    pub(crate) fn room_instances_matching_object_ids<'b>(
        &'b self,
        target_object_ids: &[usize],
    ) -> impl Iterator<Item = (usize, &'b RuntimeInstance)> + 'b {
        self.room_instance_indices_matching_object_ids(target_object_ids)
            .into_iter()
            .filter_map(|index| self.room_instance(index).map(|instance| (index, instance)))
    }

    pub(crate) fn write_room_instance_indices_matching_object_ids(
        &self,
        target_object_ids: &[usize],
        scratch: &mut RuntimeObjectQueryScratch,
    ) {
        scratch.begin_query(self.room_instances.len());

        if let Some(object_index) = self.object_index {
            for object_id in target_object_ids {
                for &index in object_index.indices_for_object_id(*object_id) {
                    scratch.push_candidate(index);
                }
            }
            return;
        }

        if self.room_instance_indices_by_object_id.is_empty() {
            for (index, instance) in self.room_instances.iter().enumerate() {
                if target_object_ids.contains(&instance.object_id) {
                    scratch.push_candidate(index);
                }
            }
            return;
        }

        for object_id in target_object_ids {
            if let Some(indices) = self.room_instance_indices_by_object_id.get(object_id) {
                for &index in indices {
                    scratch.push_candidate(index);
                }
            }
        }
    }

    pub(crate) fn room_instances_matching_object_ids_near<'b>(
        &'b self,
        target_object_ids: &[usize],
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
    ) -> impl Iterator<Item = (usize, &'b RuntimeInstance)> + 'b {
        self.room_instance_indices_matching_object_ids_near(target_object_ids, instance, x, y)
            .into_iter()
            .filter_map(|index| self.room_instance(index).map(|instance| (index, instance)))
    }

    pub(crate) fn solid_room_instances_near<'b>(
        &'b self,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
    ) -> impl Iterator<Item = (usize, &'b RuntimeInstance)> + 'b {
        self.solid_room_instance_indices_near(instance, x, y)
            .into_iter()
            .filter_map(|index| self.room_instance(index).map(|instance| (index, instance)))
    }

    fn room_instance_indices_matching_object_ids_near(
        &self,
        target_object_ids: &[usize],
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
    ) -> Vec<usize> {
        if let Some(spatial_index) = self.collision_spatial_index {
            let mut indices = Vec::new();
            for object_id in target_object_ids {
                for index in spatial_index.candidate_indices(*object_id, instance, x, y) {
                    if !indices.contains(&index) {
                        indices.push(index);
                    }
                }
            }
            return indices;
        }

        self.room_instance_indices_matching_object_ids(target_object_ids)
    }

    fn solid_room_instance_indices_near(
        &self,
        instance: &RuntimeInstance,
        x: f64,
        y: f64,
    ) -> Vec<usize> {
        if let Some(spatial_index) = self.collision_spatial_index {
            return spatial_index.solid_candidate_indices(instance, x, y);
        }

        self.room_instances
            .iter()
            .enumerate()
            .filter(|(_, candidate)| candidate.solid)
            .map(|(index, _)| index)
            .collect()
    }

    fn room_instance_indices_matching_object_ids(&self, target_object_ids: &[usize]) -> Vec<usize> {
        if let Some(object_index) = self.object_index {
            return target_object_ids
                .iter()
                .flat_map(|object_id| object_index.indices_for_object_id(*object_id).iter())
                .copied()
                .collect();
        }

        if self.room_instance_indices_by_object_id.is_empty() {
            return self
                .room_instances
                .iter()
                .enumerate()
                .filter(|(_, instance)| target_object_ids.contains(&instance.object_id))
                .map(|(index, _)| index)
                .collect();
        }

        target_object_ids
            .iter()
            .filter_map(|object_id| self.room_instance_indices_by_object_id.get(object_id))
            .flat_map(|indices| indices.iter().copied())
            .collect()
    }
}
