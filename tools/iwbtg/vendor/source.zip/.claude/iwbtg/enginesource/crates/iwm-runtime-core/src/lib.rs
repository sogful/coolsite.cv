mod core;
mod debug_input;
mod diagnostics;
mod event_dispatch;
mod helpers;
mod logic;
mod movement;
mod path;
mod render;
mod room_builder;
mod room_transitions;
mod tick_context;
mod types;

#[cfg(test)]
mod tests;

pub use core::RuntimeCore;
pub use iwm_runtime_host::{RuntimeDialogAnswer, RuntimeDialogKind, RuntimeDialogRequest};
pub use types::{
    LoweredLogicConditionalBranch, LoweredLogicEntry, LoweredLogicExpr, LoweredLogicFile,
    LoweredLogicStatement, LoweredLogicSwitchCase, RuntimeCollisionMask,
    RuntimeCollisionParticipantTrace, RuntimeCollisionTraceEntry, RuntimeCoreError,
    RuntimeDeathTraceEntry, RuntimeInputTraceSnapshot, RuntimeInstance, RuntimeJumpSnapshot,
    RuntimeJumpState, RuntimePackage, RuntimePlayerSnapshot, RuntimeRoomState,
    RuntimeScaledBoundsParticipant, RuntimeScaledBoundsTraceEntry, RuntimeSnapshot, RuntimeStatus,
    RuntimeTickPhaseSnapshot, RuntimeValue,
};
