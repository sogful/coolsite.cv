use crate::helpers::{bounds_at, collides_with_instance_at, scaled_bounds_at};
use crate::{RuntimeCollisionMask, RuntimeInstance, RuntimeJumpState, RuntimeValue};

fn make_test_instance() -> RuntimeInstance {
    RuntimeInstance {
        runtime_id: 0,
        instance_id: 0,
        object_id: 0,
        object_name: "test".into(),
        x: 0.0,
        y: 0.0,
        previous_x: 0.0,
        previous_y: 0.0,
        hspeed: 0.0,
        vspeed: 0.0,
        width: 32,
        height: 32,
        origin_x: 0,
        origin_y: 0,
        image_xscale: 1.0,
        image_yscale: 1.0,
        bbox_left: 0,
        bbox_right: 31,
        bbox_top: 0,
        bbox_bottom: 31,
        collision_masks: vec![],
        per_frame_collision_masks: false,
        facing_left: false,
        visible: true,
        alive: true,
        active: true,
        persistent: false,
        solid: false,
        hazard: false,
        checkpoint: false,
        player_candidate: false,
        jump: RuntimeJumpState::default(),
        vars: std::collections::HashMap::new(),
    }
}

fn as_number(value: &RuntimeValue) -> Option<f64> {
    match value {
        RuntimeValue::Number(number) => Some(*number),
        _ => None,
    }
}

fn filled_mask(width: u32, height: u32) -> RuntimeCollisionMask {
    RuntimeCollisionMask {
        width,
        height,
        bbox_left: 0,
        bbox_top: 0,
        bbox_right: width as i32 - 1,
        bbox_bottom: height as i32 - 1,
        data: vec![true; (width * height) as usize],
    }
}

#[test]
fn unscaled_bounds_match_bounds_at() {
    let instance = make_test_instance();
    let bounds = bounds_at(&instance, instance.x, instance.y);
    let scaled = scaled_bounds_at(&instance, instance.x, instance.y);
    assert_eq!(scaled, [bounds.0, bounds.1, bounds.2, bounds.3]);
}

#[test]
fn yscale_extends_bounds_around_origin() {
    // maskTrigger-style sprite: origin (0,0), 32x32 bbox. yscale=4 extends the
    // collider to 128px tall per GM8 (OpenGMK Instance::update_bbox).
    let mut instance = make_test_instance();
    instance.image_yscale = 4.0;
    let scaled = scaled_bounds_at(&instance, 192.0, 224.0);
    assert_eq!(scaled, [192, 224, 224, 224 + 32 * 4]);
    // bounds_at itself is scale-aware: same edges as scaled_bounds_at.
    let bounds = bounds_at(&instance, 192.0, 224.0);
    assert_eq!([bounds.0, bounds.1, bounds.2, bounds.3], scaled);
}

#[test]
fn xscale_extends_bounds_around_origin() {
    let mut instance = make_test_instance();
    instance.image_xscale = 5.0;
    let scaled = scaled_bounds_at(&instance, 1024.0, 224.0);
    assert_eq!(scaled, [1024, 224, 1024 + 32 * 5, 256]);
}

#[test]
fn scaled_zone_collides_where_unscaled_zone_would_not() {
    // Trigger at (192,224) with yscale=4; player inside the scaled zone but
    // below where a scale-1 trigger would reach. Filled masks end to end:
    // the scaled trigger must collide, the unscaled one must not.
    let mut trigger = make_test_instance();
    trigger.object_name = "freetrigger".into();
    trigger.x = 192.0;
    trigger.y = 224.0;
    trigger.collision_masks = vec![filled_mask(32, 32)];
    trigger.image_yscale = 4.0;

    let mut player = make_test_instance();
    player.object_name = "player".into();
    player.x = 200.0;
    player.y = 300.0;
    player.collision_masks = vec![filled_mask(16, 16)];
    player.bbox_right = 15;
    player.bbox_bottom = 15;

    assert!(collides_with_instance_at(
        &trigger,
        trigger.x,
        trigger.y,
        &player,
        None,
        |_| true
    ));

    trigger.image_yscale = 1.0;
    assert!(
        !collides_with_instance_at(&trigger, trigger.x, trigger.y, &player, None, |_| true),
        "a scale-1 trigger must not reach the player at y=300"
    );
}

#[test]
fn scaled_mask_sampling_maps_inverse_scale() {
    // Mask true only in the source bottom half (y 16..31); yscale=4 stretches
    // it to world y 240..352. A world pixel in the stretched top half maps
    // back to a false source row and must not collide.
    let mut trigger = make_test_instance();
    trigger.x = 192.0;
    trigger.y = 224.0;
    trigger.image_yscale = 4.0;
    let mut mask = filled_mask(32, 32);
    for y in 0..16 {
        for x in 0..32 {
            mask.data[y * 32 + x] = false;
        }
    }
    trigger.collision_masks = vec![mask];

    let mut player = make_test_instance();
    player.object_name = "player".into();
    player.x = 200.0;
    player.y = 330.0;
    player.collision_masks = vec![filled_mask(16, 16)];
    player.bbox_right = 15;
    player.bbox_bottom = 15;
    assert!(collides_with_instance_at(
        &trigger,
        trigger.x,
        trigger.y,
        &player,
        None,
        |_| true
    ));

    player.y = 232.0;
    assert!(
        !collides_with_instance_at(&trigger, trigger.x, trigger.y, &player, None, |_| true),
        "world rows inside the scaled AABB but mapping to empty source rows must not collide"
    );
}

#[test]
fn negative_scale_flips_bounds_like_gm8() {
    let mut instance = make_test_instance();
    instance.image_xscale = -1.0;
    let scaled = scaled_bounds_at(&instance, 100.0, 100.0);
    // Mirrored around origin x=0: spans [-32, 100) horizontally.
    assert_eq!(scaled, [100 - 32, 100, 100, 132]);
}

#[test]
fn filled_mask_scaled_geometry_still_boots() {
    // Sanity: scaled bounds computation does not depend on collision masks,
    // but ensure a masked instance still produces consistent bounds.
    let mut instance = make_test_instance();
    instance.collision_masks = vec![RuntimeCollisionMask {
        width: 32,
        height: 32,
        bbox_left: 0,
        bbox_top: 0,
        bbox_right: 31,
        bbox_bottom: 31,
        data: vec![true; 32 * 32],
    }];
    instance.image_yscale = 2.0;
    let scaled = scaled_bounds_at(&instance, 0.0, 0.0);
    assert_eq!(scaled, [0, 0, 32, 64]);
}
