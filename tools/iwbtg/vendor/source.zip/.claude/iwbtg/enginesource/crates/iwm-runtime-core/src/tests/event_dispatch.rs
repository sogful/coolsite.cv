use crate::{LoweredLogicExpr, LoweredLogicStatement, RuntimeCore, RuntimePackage, RuntimeValue};
use iwm_runtime_host::{ButtonState, RuntimeButton};
use iwm_runtime_model::{
    ObjectDefinition, ObjectEventEntry, RoomInstancePlacement, SpriteCollisionMask,
};

use super::support::{
    add_alarm_block, add_collision_block, add_create_block, add_keyboard_block,
    add_keyboard_press_block, add_keyboard_release_block, add_script_block, add_step_block,
    append_lowered_entry, host, player, sample_package,
};
use crate::event_dispatch::{
    collision_event_target_object_ids, object_event_block_ids,
    runtime_instance_indices_by_object_id, RuntimeCollisionScratch, RuntimeCollisionSpatialIndex,
    RuntimeEventSelector,
};
use crate::tick_context::{RuntimeObjectIndex, RuntimeObjectQueryScratch};

#[test]
fn core_dispatches_begin_step_collision_and_end_step_in_order() {
    let mut package = sample_package();
    package.rooms[0].instances[1].x = 12;
    package.rooms[0].instances[1].y = 24;
    add_player_event_block(&mut package, 3, 1, "step:begin", vec![phase_digit(1.0)]);
    add_step_block(&mut package, vec![phase_digit(2.0)]);
    add_collision_block(&mut package, 1, vec![phase_digit(3.0)]);
    add_player_event_block(&mut package, 3, 2, "step:end", vec![phase_digit(4.0)]);

    let mut core = RuntimeCore::load(package).unwrap();
    core.tick(&mut host()).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("event_order"),
        Some(&RuntimeValue::Number(1234.0))
    );
}

#[test]
fn core_dispatches_boundary_event_when_bbox_crosses_room_edge() {
    let mut package = sample_package();
    add_player_event_block(
        &mut package,
        7,
        1,
        "other:boundary",
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("boundary_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    core.current_room.as_mut().unwrap().instances[0].x = -1.0;
    core.tick(&mut host()).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("boundary_hit"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn local_mouse_press_requires_hit_but_global_press_does_not() {
    let mut package = sample_package();
    add_player_event_block(
        &mut package,
        6,
        4,
        "mouse:left-pressed",
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("local_mouse_press".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );
    add_player_event_block(
        &mut package,
        6,
        53,
        "mouse:global-left-pressed",
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("global_mouse_press".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_mouse_position((300, 200));
    host.input.set_button_state(
        RuntimeButton::Mouse(0),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(player.vars.get("local_mouse_press"), None);
    assert_eq!(
        player.vars.get("global_mouse_press"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn key_release_dispatches_before_mouse_events() {
    let mut package = sample_package();
    add_keyboard_release_block(&mut package, 65, vec![phase_digit(1.0)]);
    add_player_event_block(
        &mut package,
        6,
        53,
        "mouse:global-left-pressed",
        vec![phase_digit(2.0)],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(65),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: true,
        },
    );
    host.input.set_button_state(
        RuntimeButton::Mouse(0),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
    core.tick(&mut host).unwrap();

    assert_eq!(
        player(&core).vars.get("event_order"),
        Some(&RuntimeValue::Number(12.0))
    );
}

#[test]
fn local_mouse_events_dispatch_before_global_events_for_other_buttons() {
    let mut package = sample_package();
    add_player_event_block(&mut package, 6, 1, "mouse:right", vec![phase_digit(1.0)]);
    add_player_event_block(
        &mut package,
        6,
        50,
        "mouse:global-left",
        vec![phase_digit(2.0)],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    let (x, y) = {
        let player = player(&core);
        (player.x.round() as i32, player.y.round() as i32)
    };
    host.input.set_mouse_position((x, y));
    for button in [0, 1] {
        host.input.set_button_state(
            RuntimeButton::Mouse(button),
            ButtonState {
                pressed: true,
                just_pressed: false,
                just_released: false,
            },
        );
    }
    core.tick(&mut host).unwrap();

    assert_eq!(
        player(&core).vars.get("event_order"),
        Some(&RuntimeValue::Number(12.0))
    );
}

#[test]
fn local_mouse_press_and_release_use_precise_edge_states() {
    let mut package = sample_package();
    add_player_event_block(
        &mut package,
        6,
        4,
        "mouse:left-pressed",
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("mouse_press".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );
    add_player_event_block(
        &mut package,
        6,
        7,
        "mouse:left-released",
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("mouse_release".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_mouse_position((12, 24));
    host.input.set_button_state(
        RuntimeButton::Mouse(0),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: true,
        },
    );
    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(player.vars.get("mouse_press"), None);
    assert_eq!(
        player.vars.get("mouse_release"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn step_event_reads_mouse_position_globals() {
    let mut package = sample_package();
    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("seen_mouse_x".into()),
                value: LoweredLogicExpr::Identifier("mouse_x".into()),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("seen_mouse_y".into()),
                value: LoweredLogicExpr::Identifier("mouse_y".into()),
            },
        ],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_mouse_position((91, 37));
    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("seen_mouse_x"),
        Some(&RuntimeValue::Number(91.0))
    );
    assert_eq!(
        player.vars.get("seen_mouse_y"),
        Some(&RuntimeValue::Number(37.0))
    );
}

#[test]
fn core_dispatches_held_keyboard_event_blocks() {
    let mut package = sample_package();
    add_keyboard_block(
        &mut package,
        0x41,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("held_key".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: true,
            just_pressed: false,
            just_released: false,
        },
    );

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(player.vars.get("held_key"), Some(&RuntimeValue::Bool(true)));
}

#[test]
fn event_block_locals_do_not_leak_between_lowered_entries() {
    let mut package = sample_package();
    package.objects[0]
        .events
        .push(iwm_runtime_model::ObjectEventEntry {
            event_type: 5,
            sub_event: 0x41,
            event_tag: "keyboard:a".into(),
            block_id: "object:0:event:5:65:a".into(),
            action_count: 0,
        });
    package.objects[0]
        .events
        .push(iwm_runtime_model::ObjectEventEntry {
            event_type: 5,
            sub_event: 0x41,
            event_tag: "keyboard:a".into(),
            block_id: "object:0:event:5:65:b".into(),
            action_count: 0,
        });
    super::support::append_lowered_entry(
        &mut package,
        "object:0:event:5:65:a".into(),
        vec![
            LoweredLogicStatement::VariableDeclaration {
                names: vec!["tmp_key".into()],
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("tmp_key".into()),
                value: LoweredLogicExpr::LiteralNumber(7.0),
            },
        ],
    );
    super::support::append_lowered_entry(
        &mut package,
        "object:0:event:5:65:b".into(),
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("leaked_key".into()),
            value: LoweredLogicExpr::Identifier("tmp_key".into()),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: true,
            just_pressed: false,
            just_released: false,
        },
    );

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(player.vars.get("tmp_key"), None);
    assert_eq!(player.vars.get("leaked_key"), None);
}

#[test]
fn event_dispatch_with_executes_against_matching_instances() {
    let mut package = sample_package();
    add_keyboard_block(
        &mut package,
        0x41,
        vec![LoweredLogicStatement::With {
            target: LoweredLogicExpr::Identifier("obj_block".into()),
            body: vec![LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("event_with_hit".into()),
                value: LoweredLogicExpr::LiteralBool(true),
            }],
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: true,
            just_pressed: false,
            just_released: false,
        },
    );

    core.tick(&mut host).unwrap();

    let room = core.current_room().unwrap();
    let player = room
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    let block = room
        .instances
        .iter()
        .find(|instance| instance.object_name == "obj_block")
        .unwrap();
    assert_eq!(player.vars.get("event_with_hit"), None);
    assert_eq!(
        block.vars.get("event_with_hit"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn core_dispatches_keyboard_press_event_blocks() {
    let mut package = sample_package();
    add_keyboard_press_block(
        &mut package,
        0x41,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("press_edge".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("press_edge"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn core_does_not_retrigger_keyboard_press_events_for_held_input() {
    let mut package = sample_package();
    add_create_block(
        &mut package,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("press_count".into()),
            value: LoweredLogicExpr::LiteralNumber(0.0),
        }],
    );
    add_keyboard_press_block(
        &mut package,
        0x41,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("press_count".into()),
            value: LoweredLogicExpr::BinaryExpr {
                op: "+".into(),
                left: Box::new(LoweredLogicExpr::Identifier("press_count".into())),
                right: Box::new(LoweredLogicExpr::LiteralNumber(1.0)),
            },
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );

    core.tick(&mut host).unwrap();
    host.input.clear_transitions();
    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("press_count"),
        Some(&RuntimeValue::Number(1.0))
    );
}

#[test]
fn core_dispatches_keyboard_release_event_blocks() {
    let mut package = sample_package();
    add_keyboard_release_block(
        &mut package,
        0x41,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("release_edge".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: true,
        },
    );

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("release_edge"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn core_dispatches_alarm_event_blocks() {
    let mut package = sample_package();
    add_create_block(
        &mut package,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::IndexAccess {
                target: Box::new(LoweredLogicExpr::Identifier("alarm".into())),
                index: Box::new(LoweredLogicExpr::LiteralNumber(2.0)),
            },
            value: LoweredLogicExpr::LiteralNumber(1.0),
        }],
    );
    add_alarm_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("alarm_edge".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.tick(&mut host).unwrap();
    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("alarm_edge"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn core_falls_back_through_parent_index_for_event_lookup() {
    let mut package = sample_package();
    package.objects[1].parent_index = 0;
    add_keyboard_block(
        &mut package,
        0x41,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("parent_armed".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.input.set_button_state(
        RuntimeButton::Keyboard(0x41),
        ButtonState {
            pressed: true,
            just_pressed: false,
            just_released: false,
        },
    );

    core.tick(&mut host).unwrap();

    let child_instance = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_id == 1)
        .unwrap();
    assert_eq!(
        child_instance.vars.get("parent_armed"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn collision_selector_uses_sub_event_target_object_id() {
    let mut package = sample_package();
    add_collision_block(
        &mut package,
        1,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let block_ids = object_event_block_ids(
        &package,
        0,
        RuntimeEventSelector::Collision {
            target_object_id: 1,
        },
    );

    assert_eq!(block_ids, vec!["object:0:event:4:1".to_string()]);
}

#[test]
fn collision_target_object_ids_return_declared_targets() {
    let mut package = sample_package();
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let target_ids = collision_event_target_object_ids(&package, 0);

    assert_eq!(target_ids, vec![2]);
}

#[test]
fn collision_target_object_ids_fall_back_through_parent_inheritance() {
    let mut package = sample_package();
    package.objects[1].parent_index = 0;
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let target_ids = collision_event_target_object_ids(&package, 1);

    assert_eq!(target_ids, vec![2]);
}

#[test]
fn collision_target_object_ids_union_own_and_inherited_targets() {
    let mut package = sample_package();
    package.objects[1].parent_index = 0;
    // Parent (object 0) declares a collision event with object 2.
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("parent_collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );
    // Child (object 1) declares its own collision event with object 3; the
    // parent's collision event with object 2 must stay active alongside it.
    package.objects[1].events.push(ObjectEventEntry {
        event_type: 4,
        sub_event: 3,
        event_tag: "collision".into(),
        block_id: "object:1:event:4:3".into(),
        action_count: 0,
    });
    append_lowered_entry(
        &mut package,
        "object:1:event:4:3".into(),
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("child_collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let target_ids = collision_event_target_object_ids(&package, 1);

    assert_eq!(target_ids, vec![3, 2]);
}

#[test]
fn inherited_collision_event_fires_when_child_declares_other_collision_target() {
    // Mirrors Crimson's room001 lift: the parent object starts moving when the
    // player touches it, and the child only adds an unrelated collision event
    // of its own. The child's extra event must not shadow the inherited one.
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects.push(ObjectDefinition {
        id: 30,
        name: "lift_parent".into(),
        sprite_index: 1,
        parent_index: -1,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: Some(false),
        is_checkpoint: Some(false),
        is_player: false,
        events: vec![ObjectEventEntry {
            event_type: 4,
            sub_event: 0,
            event_tag: "collision".into(),
            block_id: "object:30:event:4:0".into(),
            action_count: 0,
        }],
    });
    package.objects.push(ObjectDefinition {
        id: 31,
        name: "lift".into(),
        sprite_index: 1,
        parent_index: 30,
        depth: 0,
        persistent: false,
        visible: true,
        solid: false,
        mask_index: -1,
        is_hazard: Some(false),
        is_checkpoint: Some(false),
        is_player: false,
        events: vec![ObjectEventEntry {
            event_type: 4,
            sub_event: 1,
            event_tag: "collision".into(),
            block_id: "object:31:event:4:1".into(),
            action_count: 0,
        }],
    });
    package.rooms[0].instances.push(RoomInstancePlacement {
        instance_id: 91,
        object_id: 31,
        x: 12,
        y: 24,
        xscale: 1.0,
        yscale: 1.0,
        angle: 0.0,
        blend: 0x00ff_ffff,
        creation_block_id: None,
        is_solid: false,
        is_hazard: false,
        is_checkpoint: false,
    });
    append_lowered_entry(
        &mut package,
        "object:30:event:4:0".into(),
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("vspeed".into()),
            value: LoweredLogicExpr::LiteralNumber(-2.5),
        }],
    );
    append_lowered_entry(
        &mut package,
        "object:31:event:4:1".into(),
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("own_collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.tick(&mut host).unwrap();

    let lift = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_id == 31)
        .unwrap();
    assert_eq!(lift.vspeed, -2.5);
}

#[test]
fn collision_dispatch_can_index_runtime_instances_by_object_id() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    {
        let room = core.current_room.as_mut().unwrap();
        let block = room
            .instances
            .iter()
            .find(|instance| instance.solid)
            .unwrap()
            .clone();
        for offset in 0..128 {
            let mut clone = block.clone();
            clone.runtime_id = room.instances.len();
            clone.instance_id = 10_000 + offset;
            clone.x = 10_000.0 + f64::from(offset);
            room.instances.push(clone);
        }
    }

    let room = core.current_room().unwrap();
    let indexed = runtime_instance_indices_by_object_id(room);

    assert_eq!(
        indexed.get(&0).map(Vec::len),
        Some(1),
        "player target lookup should not include unrelated room instances"
    );
    assert_eq!(indexed.get(&2).map(Vec::len), Some(129));
}

#[test]
fn collision_spatial_index_excludes_far_instances_for_same_object_id() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    {
        let room = core.current_room.as_mut().unwrap();
        let block = room
            .instances
            .iter()
            .find(|instance| instance.solid)
            .unwrap()
            .clone();
        for offset in 0..128 {
            let mut clone = block.clone();
            clone.runtime_id = room.instances.len();
            clone.instance_id = 10_000 + offset;
            clone.x = 10_000.0 + f64::from(offset);
            room.instances.push(clone);
        }
    }

    let room = core.current_room().unwrap();
    let player = room
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    let mut index = RuntimeCollisionSpatialIndex::default();
    index.rebuild(room);
    let candidates = index.candidate_indices(2, player, player.x, player.y);

    assert_eq!(candidates, vec![2]);
}

#[test]
fn collision_spatial_index_finds_near_solid_instances_only() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    {
        let room = core.current_room.as_mut().unwrap();
        let block = room
            .instances
            .iter()
            .find(|instance| instance.solid)
            .unwrap()
            .clone();
        let mut far_block = block.clone();
        far_block.runtime_id = room.instances.len();
        far_block.instance_id = 10_000;
        far_block.x = 10_000.0;
        room.instances.push(far_block);

        let mut nonsolid_block = block.clone();
        nonsolid_block.runtime_id = room.instances.len();
        nonsolid_block.instance_id = 10_001;
        nonsolid_block.solid = false;
        nonsolid_block.x = block.x;
        nonsolid_block.y = block.y;
        room.instances.push(nonsolid_block);
    }

    let room = core.current_room().unwrap();
    let player = room
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    let mut index = RuntimeCollisionSpatialIndex::default();
    index.rebuild(room);
    let candidates = index.solid_candidate_indices(player, player.x, player.y);

    assert_eq!(candidates, vec![2]);
}

#[test]
fn collision_spatial_index_rebuild_clears_stale_candidates_with_reused_scratch() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    let mut index = RuntimeCollisionSpatialIndex::default();
    let mut scratch = RuntimeCollisionScratch::default();
    let (player, block_index) = {
        let room = core.current_room().unwrap();
        let player = room
            .instances
            .iter()
            .find(|instance| instance.player_candidate)
            .unwrap()
            .clone();
        let block_index = room
            .instances
            .iter()
            .position(|instance| instance.solid)
            .unwrap();
        (player, block_index)
    };

    index.rebuild(core.current_room().unwrap());
    index.candidate_indices_into(2, &player, player.x, player.y, &mut scratch);
    assert_eq!(scratch.candidates(), &[2]);

    {
        let room = core.current_room.as_mut().unwrap();
        let block = &mut room.instances[block_index];
        block.x = 10_000.0;
        block.y = 10_000.0;
    }

    index.rebuild(core.current_room().unwrap());
    index.candidate_indices_into(2, &player, player.x, player.y, &mut scratch);
    assert!(scratch.candidates().is_empty());
}

#[test]
fn runtime_object_index_rebuild_clears_stale_object_membership() {
    let mut core = RuntimeCore::load(sample_package()).unwrap();
    let mut index = RuntimeObjectIndex::default();

    index.rebuild(core.current_room().unwrap());
    assert_eq!(index.indices_for_object_id(0), &[0]);

    {
        let room = core.current_room.as_mut().unwrap();
        room.instances.retain(|instance| instance.object_id != 0);
    }

    index.rebuild(core.current_room().unwrap());
    assert!(index.indices_for_object_id(0).is_empty());
    assert_eq!(index.indices_for_object_id(2), &[1]);
}

#[test]
fn object_query_scratch_dedupes_candidate_indices() {
    let mut scratch = RuntimeObjectQueryScratch::default();

    scratch.begin_query(4);
    scratch.push_candidate(2);
    scratch.push_candidate(2);
    scratch.push_candidate(3);

    assert_eq!(scratch.candidates(), &[2, 3]);
}

#[test]
fn core_dispatches_collision_event_blocks_when_player_overlaps_target() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[2].name = "block".into();
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        player.y = 48.0;
        player.previous_y = 48.0;
        player.vspeed = 8.0;
    }

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("collision_hit"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn solid_collision_resolves_before_same_frame_hazard_hit() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[1].name = "playerKiller".into();
    package.objects[1].is_hazard = Some(true);
    package.objects[2].name = "block".into();
    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_y".into()),
                value: LoweredLogicExpr::LiteralNumber(24.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("y".into()),
                value: LoweredLogicExpr::LiteralNumber(40.0),
            },
        ],
    );
    add_collision_block(
        &mut package,
        1,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("hazard_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("solid_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        player.previous_y = 24.0;

        let hazard = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "playerKiller")
            .unwrap();
        hazard.x = 12.0;
        hazard.y = 40.0;

        let block = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "block")
            .unwrap();
        block.x = 12.0;
        block.y = 40.0;
    }

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(player.y, 24.0);
    assert_eq!(player.vars.get("hazard_hit"), None);
    assert_eq!(
        player.vars.get("solid_hit"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn resolved_block_spike_seam_contact_does_not_leave_player_in_frozen_death_state() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[1].name = "spikeRight".into();
    package.objects[1].sprite_index = 1;
    package.objects[1].solid = false;
    package.objects[1].is_hazard = Some(true);
    package.objects[2].name = "block".into();
    package.resources.sprites[0].width = 32;
    package.resources.sprites[0].height = 32;
    package.resources.sprites[0].origin_x = 17;
    package.resources.sprites[0].origin_y = 23;
    package.resources.sprites[0].bbox_left = 12;
    package.resources.sprites[0].bbox_right = 22;
    package.resources.sprites[0].bbox_top = 11;
    package.resources.sprites[0].bbox_bottom = 31;
    package.resources.sprites[0].collision_masks = vec![rect_mask(32, 32, 12, 22, 11, 31)];
    package.resources.sprites[1].width = 32;
    package.resources.sprites[1].height = 32;
    package.resources.sprites[1].bbox_right = 31;
    package.resources.sprites[1].bbox_bottom = 31;
    package.resources.sprites[1].collision_masks = vec![right_spike_mask(32)];
    let mut block_sprite = package.resources.sprites[1].clone();
    block_sprite.id = 2;
    block_sprite.width = 32;
    block_sprite.height = 32;
    block_sprite.bbox_right = 31;
    block_sprite.bbox_bottom = 31;
    block_sprite.collision_masks = vec![filled_mask(32, 32)];
    package.resources.sprites.push(block_sprite);
    package.objects[2].sprite_index = 2;
    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_x".into()),
                value: LoweredLogicExpr::LiteralNumber(888.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_y".into()),
                value: LoweredLogicExpr::LiteralNumber(919.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("x".into()),
                value: LoweredLogicExpr::LiteralNumber(891.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("y".into()),
                value: LoweredLogicExpr::LiteralNumber(919.81),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("hspeed".into()),
                value: LoweredLogicExpr::LiteralNumber(3.0),
            },
        ],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("hspeed".into()),
            value: LoweredLogicExpr::LiteralNumber(0.0),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let spike = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "spikeRight")
            .unwrap();
        spike.x = 896.0;
        spike.y = 928.0;
        let block = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "block")
            .unwrap();
        block.x = 864.0;
        block.y = 928.0;
    }

    core.tick(&mut host).unwrap();

    assert!(core.diagnostics().iter().all(|entry| {
        entry.code != "runtime-player-died"
    }), "solid resolution separated the spike seam, so movement must not remain frozen; diagnostics={:?}", core.diagnostics());
}

#[test]
fn scripted_kill_player_is_shadowed_at_block_spike_side_seam() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[1].name = "spikeLeft".into();
    package.objects[1].sprite_index = 1;
    package.objects[1].solid = false;
    package.objects[1].is_hazard = Some(true);
    package.objects[2].name = "block".into();
    package.resources.sprites[0].width = 32;
    package.resources.sprites[0].height = 32;
    package.resources.sprites[0].origin_x = 17;
    package.resources.sprites[0].origin_y = 23;
    package.resources.sprites[0].bbox_left = 12;
    package.resources.sprites[0].bbox_right = 22;
    package.resources.sprites[0].bbox_top = 11;
    package.resources.sprites[0].bbox_bottom = 31;
    package.resources.sprites[0].collision_masks = vec![rect_mask(32, 32, 12, 22, 11, 31)];
    package.resources.sprites[1].width = 32;
    package.resources.sprites[1].height = 32;
    package.resources.sprites[1].bbox_right = 31;
    package.resources.sprites[1].bbox_bottom = 31;
    package.resources.sprites[1].collision_masks = vec![left_spike_mask(32)];
    let mut block_sprite = package.resources.sprites[1].clone();
    block_sprite.id = 2;
    block_sprite.collision_masks = vec![filled_mask(32, 32)];
    package.resources.sprites.push(block_sprite);
    package.objects[2].sprite_index = 2;

    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_x".into()),
                value: LoweredLogicExpr::LiteralNumber(420.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_y".into()),
                value: LoweredLogicExpr::LiteralNumber(473.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("x".into()),
                value: LoweredLogicExpr::LiteralNumber(420.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("y".into()),
                value: LoweredLogicExpr::LiteralNumber(474.0),
            },
        ],
    );
    add_collision_block(
        &mut package,
        1,
        vec![LoweredLogicStatement::FunctionCall {
            name: "killPlayer".into(),
            args: vec![],
        }],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("solid_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );
    add_script_block(
        &mut package,
        1,
        "killPlayer",
        vec![LoweredLogicStatement::With {
            target: LoweredLogicExpr::Identifier("player".into()),
            body: vec![LoweredLogicStatement::FunctionCall {
                name: "instance_destroy".into(),
                args: vec![],
            }],
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let spike = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "spikeLeft")
            .unwrap();
        spike.x = 384.0;
        spike.y = 480.0;
        let block = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "block")
            .unwrap();
        block.x = 416.0;
        block.y = 480.0;
    }

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name == "player")
        .unwrap();
    assert_eq!(
        player.vars.get("solid_hit"),
        Some(&RuntimeValue::Bool(true))
    );
    assert!(!core
        .diagnostics()
        .iter()
        .any(|entry| entry.code == "runtime-player-died"));
}

#[test]
fn script_owned_floor_contact_preserves_safe_horizontal_motion_at_block_spike_boundary() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[1].name = "spike".into();
    package.objects[1].sprite_index = 1;
    package.objects[1].solid = false;
    package.objects[1].is_hazard = Some(true);
    package.objects[2].name = "block".into();
    package.resources.sprites[0].width = 32;
    package.resources.sprites[0].height = 32;
    package.resources.sprites[0].origin_x = 17;
    package.resources.sprites[0].origin_y = 23;
    package.resources.sprites[0].bbox_left = 12;
    package.resources.sprites[0].bbox_right = 22;
    package.resources.sprites[0].bbox_top = 11;
    package.resources.sprites[0].bbox_bottom = 31;
    package.resources.sprites[0].collision_masks = vec![rect_mask(32, 32, 12, 22, 11, 31)];
    package.resources.sprites[1].collision_masks = vec![filled_mask(16, 16)];
    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_x".into()),
                value: LoweredLogicExpr::LiteralNumber(856.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_y".into()),
                value: LoweredLogicExpr::LiteralNumber(920.4),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("x".into()),
                value: LoweredLogicExpr::LiteralNumber(859.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("y".into()),
                value: LoweredLogicExpr::LiteralNumber(919.53),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("hspeed".into()),
                value: LoweredLogicExpr::LiteralNumber(3.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("vspeed".into()),
                value: LoweredLogicExpr::LiteralNumber(-0.87),
            },
        ],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Conditional {
            condition: LoweredLogicExpr::BinaryExpr {
                op: "==".into(),
                left: Box::new(LoweredLogicExpr::Call {
                    name: "place_free".into(),
                    args: vec![
                        LoweredLogicExpr::BinaryExpr {
                            op: "+".into(),
                            left: Box::new(LoweredLogicExpr::Identifier("x".into())),
                            right: Box::new(LoweredLogicExpr::Identifier("hspeed".into())),
                        },
                        LoweredLogicExpr::Identifier("y".into()),
                    ],
                }),
                right: Box::new(LoweredLogicExpr::LiteralBool(false)),
            },
            then_branch: vec![
                LoweredLogicStatement::FunctionCall {
                    name: "move_contact_solid".into(),
                    args: vec![
                        LoweredLogicExpr::LiteralNumber(0.0),
                        LoweredLogicExpr::Call {
                            name: "abs".into(),
                            args: vec![LoweredLogicExpr::Identifier("hspeed".into())],
                        },
                    ],
                },
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("hspeed".into()),
                    value: LoweredLogicExpr::LiteralNumber(0.0),
                },
            ],
            else_branch: vec![],
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        player.x = 856.0;
        player.y = 920.4;
        player.previous_x = 856.0;
        player.previous_y = 920.4;

        let spike = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "spike")
            .unwrap();
        spike.x = 896.0;
        spike.y = 928.0;

        let block = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "block")
            .unwrap();
        block.x = 864.0;
        block.y = 928.0;
    }

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.x,
        859.0,
        "safe horizontal motion should survive floor resolution; player={player:?}, diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn script_owned_jump_preserves_safe_vertical_motion_at_block_spike_boundary() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[1].name = "spike".into();
    package.objects[1].sprite_index = 1;
    package.objects[1].solid = false;
    package.objects[1].is_hazard = Some(true);
    package.objects[2].name = "block".into();
    package.resources.sprites[0].collision_masks = vec![filled_mask(16, 16)];
    package.resources.sprites[1].collision_masks = vec![filled_mask(16, 16)];
    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_x".into()),
                value: LoweredLogicExpr::LiteralNumber(16.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_y".into()),
                value: LoweredLogicExpr::LiteralNumber(24.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("x".into()),
                value: LoweredLogicExpr::LiteralNumber(15.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("y".into()),
                value: LoweredLogicExpr::LiteralNumber(20.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("hspeed".into()),
                value: LoweredLogicExpr::LiteralNumber(-1.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("vspeed".into()),
                value: LoweredLogicExpr::LiteralNumber(-4.0),
            },
        ],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("edge_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        player.x = 16.0;
        player.y = 24.0;
        player.previous_x = 16.0;
        player.previous_y = 24.0;

        let spike = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "spike")
            .unwrap();
        spike.x = 16.0;
        spike.y = 40.0;

        let block = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "block")
            .unwrap();
        block.x = 0.0;
        block.y = 24.0;
    }

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.y,
        20.0,
        "safe jump motion should survive edge resolution; player={player:?}, diagnostics={:?}",
        core.diagnostics().iter().rev().take(12).collect::<Vec<_>>()
    );
}

#[test]
fn solid_ceiling_collision_event_clears_upward_speed_before_reapply() {
    let mut package = sample_package();
    package.objects[0].name = "mover".into();
    package.objects[2].name = "solid".into();
    add_step_block(
        &mut package,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("vspeed".into()),
            value: LoweredLogicExpr::LiteralNumber(-17.0),
        }],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Conditional {
            condition: LoweredLogicExpr::BinaryExpr {
                op: "==".into(),
                left: Box::new(LoweredLogicExpr::Call {
                    name: "place_free".into(),
                    args: vec![
                        LoweredLogicExpr::Identifier("x".into()),
                        LoweredLogicExpr::BinaryExpr {
                            op: "+".into(),
                            left: Box::new(LoweredLogicExpr::Identifier("y".into())),
                            right: Box::new(LoweredLogicExpr::Identifier("vspeed".into())),
                        },
                    ],
                }),
                right: Box::new(LoweredLogicExpr::LiteralBool(false)),
            },
            then_branch: vec![
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("y_before_contact".into()),
                    value: LoweredLogicExpr::Identifier("y".into()),
                },
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("other_object_seen".into()),
                    value: LoweredLogicExpr::MemberAccess {
                        target: Box::new(LoweredLogicExpr::Identifier("other".into())),
                        member: "object_index".into(),
                    },
                },
                LoweredLogicStatement::FunctionCall {
                    name: "move_contact_solid".into(),
                    args: vec![
                        LoweredLogicExpr::LiteralNumber(90.0),
                        LoweredLogicExpr::Call {
                            name: "abs".into(),
                            args: vec![LoweredLogicExpr::Identifier("vspeed".into())],
                        },
                    ],
                },
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("y_after_contact".into()),
                    value: LoweredLogicExpr::Identifier("y".into()),
                },
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("vspeed".into()),
                    value: LoweredLogicExpr::LiteralNumber(0.0),
                },
                LoweredLogicStatement::Assignment {
                    target: LoweredLogicExpr::Identifier("ceiling_hit".into()),
                    value: LoweredLogicExpr::LiteralBool(true),
                },
            ],
            else_branch: vec![],
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    core.set_debug_trace_limits(32, 0);
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let mover = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        mover.x = 12.0;
        mover.y = 56.0;
        mover.previous_x = 12.0;
        mover.previous_y = 56.0;

        let solid = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "solid")
            .unwrap();
        assert!(solid.solid);
        solid.x = 12.0;
        solid.y = 24.0;
        solid.previous_x = 12.0;
        solid.previous_y = 24.0;
    }

    core.tick(&mut host).unwrap();

    let mover = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        mover.vars.get("ceiling_hit"),
        Some(&RuntimeValue::Bool(true))
    );
    assert_eq!(
        mover.vars.get("other_object_seen"),
        Some(&RuntimeValue::Number(2.0))
    );
    assert_eq!(
        mover.vars.get("y_before_contact"),
        Some(&RuntimeValue::Number(56.0))
    );
    assert_eq!(
        mover.vars.get("y_after_contact"),
        Some(&RuntimeValue::Number(40.0))
    );
    assert_eq!(mover.vspeed, 0.0);
    assert_eq!(mover.y, 40.0);
    let collision_traces = core
        .diagnostics()
        .iter()
        .filter(|entry| entry.code == "runtime-collision-trace")
        .map(|entry| entry.message.as_str())
        .collect::<Vec<_>>();
    assert!(collision_traces
        .iter()
        .any(|message| message.contains("phase=pre")));
    assert!(collision_traces
        .iter()
        .any(|message| message.contains("phase=after-rollback")));
    assert!(collision_traces
        .iter()
        .any(|message| message.contains("phase=after-event")));
    let structured_trace = core.snapshot().collision_trace;
    assert!(structured_trace.iter().any(|entry| {
        entry.phase == "after-event"
            && entry.owner.object_name == "mover"
            && entry.other.object_name == "solid"
            && entry
                .event_blocks
                .iter()
                .any(|block| block.contains("event:4:2"))
            && entry.owner.bounds[1] <= entry.owner.bounds[3]
    }));
}

#[test]
fn hazard_collision_event_does_not_fire_when_swept_bbox_top_misses_precise_mask() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[2].name = "spike".into();
    package.objects[2].solid = false;
    package.objects[2].sprite_index = 1;
    package.objects[2].is_hazard = Some(true);
    package.resources.sprites[0].width = 4;
    package.resources.sprites[0].height = 4;
    package.resources.sprites[0].bbox_right = 3;
    package.resources.sprites[0].bbox_bottom = 3;
    package.resources.sprites[0].collision_masks = vec![filled_mask(4, 4)];
    package.resources.sprites[1].width = 16;
    package.resources.sprites[1].height = 16;
    package.resources.sprites[1].bbox_right = 15;
    package.resources.sprites[1].bbox_bottom = 15;
    package.resources.sprites[1].collision_masks = vec![top_spike_mask(16)];
    package.rooms[0].instances[2].x = 100;
    package.rooms[0].instances[2].y = 100;
    package.rooms[0].instances[2].is_solid = false;
    package.rooms[0].instances[2].is_hazard = true;
    add_step_block(
        &mut package,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_x".into()),
                value: LoweredLogicExpr::LiteralNumber(97.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("previous_y".into()),
                value: LoweredLogicExpr::LiteralNumber(93.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("x".into()),
                value: LoweredLogicExpr::LiteralNumber(97.0),
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("y".into()),
                value: LoweredLogicExpr::LiteralNumber(97.0),
            },
        ],
    );
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(player.vars.get("collision_hit"), None);
}

#[test]
fn collision_event_execution_does_not_emit_hot_path_trace_diagnostics() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[2].name = "block".into();
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        player.y = 48.0;
    }

    core.tick(&mut host).unwrap();

    assert!(core.diagnostics().iter().all(|entry| {
        entry.code != "runtime-exec-block-trace" || !entry.message.contains("event_tag=collision")
    }));
}

fn filled_mask(width: u32, height: u32) -> SpriteCollisionMask {
    SpriteCollisionMask {
        width,
        height,
        bbox_left: 0,
        bbox_right: width - 1,
        bbox_top: 0,
        bbox_bottom: height - 1,
        data: vec![true; (width * height) as usize],
    }
}

fn rect_mask(
    width: u32,
    height: u32,
    bbox_left: u32,
    bbox_right: u32,
    bbox_top: u32,
    bbox_bottom: u32,
) -> SpriteCollisionMask {
    let mut data = vec![false; (width * height) as usize];
    for y in bbox_top..=bbox_bottom {
        for x in bbox_left..=bbox_right {
            data[(y * width + x) as usize] = true;
        }
    }
    SpriteCollisionMask {
        width,
        height,
        bbox_left,
        bbox_right,
        bbox_top,
        bbox_bottom,
        data,
    }
}

fn top_spike_mask(size: u32) -> SpriteCollisionMask {
    let mut data = vec![false; (size * size) as usize];
    for y in 0..size {
        let half_width = (y / 2) + 1;
        let center_left = size / 2 - 1;
        let left = center_left.saturating_sub(half_width - 1);
        let right = (center_left + half_width).min(size - 1);
        for x in left..=right {
            data[(y * size + x) as usize] = true;
        }
    }

    SpriteCollisionMask {
        width: size,
        height: size,
        bbox_left: 0,
        bbox_right: size - 1,
        bbox_top: 0,
        bbox_bottom: size - 1,
        data,
    }
}

fn left_spike_mask(size: u32) -> SpriteCollisionMask {
    let mut data = vec![false; (size * size) as usize];
    for y in 0..size {
        let width = if y < size / 2 {
            (y + 1) * 2
        } else {
            (size - y) * 2
        };
        for x in size.saturating_sub(width)..size {
            data[(y * size + x) as usize] = true;
        }
    }
    SpriteCollisionMask {
        width: size,
        height: size,
        bbox_left: 0,
        bbox_right: size - 1,
        bbox_top: 0,
        bbox_bottom: size - 1,
        data,
    }
}

fn right_spike_mask(size: u32) -> SpriteCollisionMask {
    let mut data = vec![false; (size * size) as usize];
    for y in 0..size {
        let width = if y < size / 2 {
            (y + 1) * 2
        } else {
            (size - y) * 2
        };
        for x in 0..width.min(size) {
            data[(y * size + x) as usize] = true;
        }
    }
    SpriteCollisionMask {
        width: size,
        height: size,
        bbox_left: 0,
        bbox_right: size - 1,
        bbox_top: 0,
        bbox_bottom: size - 1,
        data,
    }
}

fn add_player_event_block(
    package: &mut RuntimePackage,
    event_type: usize,
    sub_event: u32,
    event_tag: &str,
    statements: Vec<LoweredLogicStatement>,
) {
    let block_id = format!("test:object:0:event:{event_type}:{sub_event}");
    package.objects[0].events.push(ObjectEventEntry {
        event_type,
        sub_event,
        event_tag: event_tag.into(),
        block_id: block_id.clone(),
        action_count: 0,
    });
    append_lowered_entry(package, block_id, statements);
}

fn phase_digit(digit: f64) -> LoweredLogicStatement {
    LoweredLogicStatement::Assignment {
        target: LoweredLogicExpr::Identifier("event_order".into()),
        value: LoweredLogicExpr::BinaryExpr {
            op: "+".into(),
            left: Box::new(LoweredLogicExpr::BinaryExpr {
                op: "*".into(),
                left: Box::new(LoweredLogicExpr::Identifier("event_order".into())),
                right: Box::new(LoweredLogicExpr::LiteralNumber(10.0)),
            }),
            right: Box::new(LoweredLogicExpr::LiteralNumber(digit)),
        },
    }
}

#[test]
fn core_dispatches_collision_event_blocks_when_target_child_overlaps_player() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[1].name = "spike_child".into();
    package.objects[1].parent_index = 2;
    package.objects[2].name = "playerKiller".into();
    package.rooms[0].instances[1].x = 12;
    package.rooms[0].instances[1].y = 24;
    add_collision_block(
        &mut package,
        2,
        vec![LoweredLogicStatement::Assignment {
            target: LoweredLogicExpr::Identifier("parent_collision_hit".into()),
            value: LoweredLogicExpr::LiteralBool(true),
        }],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("parent_collision_hit"),
        Some(&RuntimeValue::Bool(true))
    );
}

#[test]
fn collision_event_can_read_other_member_values() {
    let mut package = sample_package();
    package.objects[0].name = "player".into();
    package.objects[2].name = "block".into();
    add_collision_block(
        &mut package,
        2,
        vec![
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("other_y_seen".into()),
                value: LoweredLogicExpr::MemberAccess {
                    target: Box::new(LoweredLogicExpr::Identifier("other".into())),
                    member: "y".into(),
                },
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("other_vspeed_seen".into()),
                value: LoweredLogicExpr::MemberAccess {
                    target: Box::new(LoweredLogicExpr::Identifier("other".into())),
                    member: "vspeed".into(),
                },
            },
        ],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();

    {
        let room = core.current_room.as_mut().unwrap();
        let player = room
            .instances
            .iter_mut()
            .find(|instance| instance.player_candidate)
            .unwrap();
        player.y = 48.0;
        player.previous_y = 48.0;
        player.vspeed = 8.0;
    }

    core.tick(&mut host).unwrap();

    let player = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.player_candidate)
        .unwrap();
    assert_eq!(
        player.vars.get("other_y_seen"),
        Some(&RuntimeValue::Number(40.0))
    );
    assert_eq!(
        player.vars.get("other_vspeed_seen"),
        Some(&RuntimeValue::Number(0.0))
    );
}

#[test]
fn solid_collision_rolls_back_before_move_contact_solid_event() {
    let mut package = sample_package();
    package.objects[1].name = "blood2".into();
    package.objects[2].name = "block".into();
    package.objects[1].events.push(ObjectEventEntry {
        event_type: 4,
        sub_event: 2,
        event_tag: "collision".into(),
        block_id: "object:1:event:4:2".into(),
        action_count: 0,
    });
    append_lowered_entry(
        &mut package,
        "object:1:event:4:2".into(),
        vec![
            LoweredLogicStatement::FunctionCall {
                name: "move_contact_solid".into(),
                args: vec![
                    LoweredLogicExpr::LiteralNumber(0.0),
                    LoweredLogicExpr::LiteralNumber(16.0),
                ],
            },
            LoweredLogicStatement::Assignment {
                target: LoweredLogicExpr::Identifier("hspeed".into()),
                value: LoweredLogicExpr::LiteralNumber(0.0),
            },
        ],
    );

    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    {
        let room = core.current_room.as_mut().unwrap();
        let blood = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "blood2")
            .unwrap();
        blood.x = 24.0;
        blood.y = 40.0;
        blood.previous_x = 24.0;
        blood.previous_y = 40.0;
        blood.hspeed = 16.0;

        let block = room
            .instances
            .iter_mut()
            .find(|instance| instance.object_name == "block")
            .unwrap();
        block.x = 40.0;
        block.y = 40.0;
        block.previous_x = 40.0;
        block.previous_y = 40.0;
    }

    core.tick(&mut host).unwrap();

    let blood = core
        .current_room()
        .unwrap()
        .instances
        .iter()
        .find(|instance| instance.object_name == "blood2")
        .unwrap();
    assert_eq!(blood.x, 24.0);
    assert_eq!(blood.hspeed, 0.0);
}
