use std::collections::HashMap;

use iwm_runtime_host::RuntimeHost;

use super::assignment::assign_instance_field_or_var;
use super::context::{RuntimeEvalContext, RuntimeExecutionScope, RuntimeInstanceCreateRequest};
use super::control_flow::write_with_target_indices;
use super::eval::evaluate_expr;
use super::eval_variables::instance_member_access;
use super::statement::{evaluate_with_diagnostics, RuntimeStatementEnvironment};
use crate::helpers::as_number;
use crate::room_builder::next_runtime_instance_id;
use crate::{LoweredLogicExpr, RuntimeInstance, RuntimeValue};

pub(super) fn assign_runtime_member_reference<H: RuntimeHost>(
    target: &LoweredLogicExpr,
    value: RuntimeValue,
    instance: &mut RuntimeInstance,
    instance_index: usize,
    scope: &RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> bool {
    let Some((receiver, member)) = instance_member_access(
        target,
        Some(instance),
        env.globals,
        Some(scope),
        eval_context,
    ) else {
        return false;
    };

    if matches!(receiver, LoweredLogicExpr::Identifier(name) if name == "global") {
        return false;
    }

    let object_receiver = matches!(receiver, LoweredLogicExpr::Identifier(name)
    if !scope.is_local_key(name)
        && eval_context.is_some_and(|context| {
            context
                .place_target_ids_by_name
                .contains_key(&name.to_ascii_lowercase())
        }));

    if let Some(context) = eval_context {
        write_with_target_indices(
            receiver,
            instance_index,
            instance,
            scope,
            context,
            env.globals,
            env.with_target_indices,
        );
        let target_indices = std::mem::take(env.with_target_indices);
        let mut assigned = false;
        for target_index in target_indices.iter().copied() {
            assigned |= assign_runtime_member_by_index(
                target_index,
                &member,
                value.clone(),
                instance,
                instance_index,
                Some(context),
                env,
            );
        }
        *env.with_target_indices = target_indices;
        if assigned {
            return true;
        }
    }

    if assign_pending_create_member_by_object_target(
        receiver,
        &member,
        value.clone(),
        scope,
        eval_context,
        env.room_instance_creates,
    ) {
        return true;
    }
    if object_receiver {
        return true;
    }

    let Some(RuntimeValue::Number(instance_ref)) = evaluate_with_diagnostics(
        receiver,
        Some(instance),
        Some(scope),
        eval_context,
        env,
        instance,
    ) else {
        return false;
    };

    assign_runtime_member_by_ref(
        instance_ref,
        &member,
        value,
        instance,
        instance_index,
        eval_context,
        env,
    )
}

pub(super) fn pending_create_member_value(
    creates: &[RuntimeInstanceCreateRequest],
    instance_ref: f64,
    member: &str,
) -> Option<RuntimeValue> {
    creates
        .iter()
        .find(|create| create_request_ref_matches(instance_ref, create))
        .and_then(|create| create_member_value(create, member))
}

pub(super) fn pending_create_member_value_by_object_target(
    creates: &[RuntimeInstanceCreateRequest],
    target: &LoweredLogicExpr,
    member: &str,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    let LoweredLogicExpr::Identifier(name) = target else {
        return None;
    };
    if name == "global" || scope.map(|scope| scope.is_local_key(name)).unwrap_or(false) {
        return None;
    }
    let object_ids = eval_context.and_then(|context| {
        context
            .place_target_ids_by_name
            .get(&name.to_ascii_lowercase())
    })?;
    creates
        .iter()
        .find(|create| object_ids.contains(&create.object_id))
        .and_then(|create| create_member_value(create, member))
}

pub(super) fn runtime_instance_create_request(
    args: &[LoweredLogicExpr],
    instance: &RuntimeInstance,
    globals: &HashMap<String, RuntimeValue>,
    scope: &RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    pending_create_count: usize,
) -> Option<RuntimeInstanceCreateRequest> {
    let context = eval_context?;
    let x = args
        .first()
        .and_then(|arg| evaluate_expr(arg, Some(instance), globals, Some(scope), eval_context))
        .and_then(|value| as_number(&value))
        .unwrap_or(0.0);
    let y = args
        .get(1)
        .and_then(|arg| evaluate_expr(arg, Some(instance), globals, Some(scope), eval_context))
        .and_then(|value| as_number(&value))
        .unwrap_or(0.0);
    let object_id = args.get(2).and_then(|arg| {
        runtime_instance_create_object_id(arg, instance, globals, scope, context)
    })?;
    let runtime_id = context
        .room_instances
        .len()
        .saturating_add(pending_create_count);
    let pending_instance_count = pending_create_count.min(i32::MAX as usize) as i32;
    let instance_id =
        next_runtime_instance_id(context.room_instances).saturating_add(pending_instance_count);
    Some(RuntimeInstanceCreateRequest {
        object_id,
        runtime_id,
        instance_id,
        x,
        y,
        post_create_vars: HashMap::new(),
    })
}

fn assign_runtime_member_by_ref<H: RuntimeHost>(
    instance_ref: f64,
    member: &str,
    value: RuntimeValue,
    instance: &mut RuntimeInstance,
    instance_index: usize,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> bool {
    if assign_pending_create_member(
        env.room_instance_creates,
        instance_ref,
        member,
        value.clone(),
    ) {
        return true;
    }

    let Some(context) = eval_context else {
        return false;
    };
    let Some((target_index, _)) = context
        .room_instances_iter()
        .find(|(_, candidate)| runtime_instance_ref_matches(instance_ref, candidate))
    else {
        return false;
    };

    assign_runtime_member_by_index(
        target_index,
        member,
        value,
        instance,
        instance_index,
        Some(context),
        env,
    )
}

fn assign_runtime_member_by_index<H: RuntimeHost>(
    target_index: usize,
    member: &str,
    value: RuntimeValue,
    instance: &mut RuntimeInstance,
    instance_index: usize,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    env: &mut RuntimeStatementEnvironment<'_, H>,
) -> bool {
    if target_index == instance_index {
        assign_instance_field_or_var(
            member.to_string(),
            value,
            instance,
            env.sprites,
            env.sprite_index,
        );
        return true;
    }

    let Some(mut target_instance) = env
        .room_instance_updates
        .get(target_index)
        .cloned()
        .or_else(|| eval_context.and_then(|context| context.room_instance(target_index).cloned()))
    else {
        return false;
    };
    assign_instance_field_or_var(
        member.to_string(),
        value,
        &mut target_instance,
        env.sprites,
        env.sprite_index,
    );
    env.room_instance_updates.set(target_index, target_instance);
    true
}

fn assign_pending_create_member(
    creates: &mut [RuntimeInstanceCreateRequest],
    instance_ref: f64,
    member: &str,
    value: RuntimeValue,
) -> bool {
    let Some(create) = creates
        .iter_mut()
        .find(|create| create_request_ref_matches(instance_ref, create))
    else {
        return false;
    };
    create.post_create_vars.insert(member.to_string(), value);
    true
}

fn assign_pending_create_member_by_object_target(
    target: &LoweredLogicExpr,
    member: &str,
    value: RuntimeValue,
    scope: &RuntimeExecutionScope,
    eval_context: Option<&RuntimeEvalContext<'_>>,
    creates: &mut [RuntimeInstanceCreateRequest],
) -> bool {
    let LoweredLogicExpr::Identifier(name) = target else {
        return false;
    };
    if scope.is_local_key(name) {
        return false;
    }
    let Some(object_ids) = eval_context.and_then(|context| {
        context
            .place_target_ids_by_name
            .get(&name.to_ascii_lowercase())
    }) else {
        return false;
    };
    let Some(create) = creates
        .iter_mut()
        .find(|create| object_ids.contains(&create.object_id))
    else {
        return false;
    };
    create.post_create_vars.insert(member.to_string(), value);
    true
}

fn create_member_value(
    create: &RuntimeInstanceCreateRequest,
    member: &str,
) -> Option<RuntimeValue> {
    create
        .post_create_vars
        .get(member)
        .cloned()
        .or(match member {
            "x" => Some(RuntimeValue::Number(create.x)),
            "y" => Some(RuntimeValue::Number(create.y)),
            _ => None,
        })
}

fn create_request_ref_matches(instance_ref: f64, create: &RuntimeInstanceCreateRequest) -> bool {
    if !instance_ref.is_finite() {
        return false;
    }
    let rounded = instance_ref.round();
    create.instance_id as f64 == rounded || create.runtime_id as f64 == rounded
}

fn runtime_instance_ref_matches(instance_ref: f64, instance: &RuntimeInstance) -> bool {
    if !instance_ref.is_finite() {
        return false;
    }
    let rounded = instance_ref.round();
    instance.instance_id as f64 == rounded || instance.runtime_id as f64 == rounded
}

fn runtime_instance_create_object_id(
    expr: &LoweredLogicExpr,
    instance: &RuntimeInstance,
    globals: &HashMap<String, RuntimeValue>,
    scope: &RuntimeExecutionScope,
    context: &RuntimeEvalContext<'_>,
) -> Option<usize> {
    if let LoweredLogicExpr::Identifier(name) = expr {
        if let Some(object_id) = context
            .place_target_ids_by_name
            .get(&name.to_ascii_lowercase())
            .and_then(|ids| ids.first().copied())
        {
            return Some(object_id);
        }
    }

    evaluate_expr(expr, Some(instance), globals, Some(scope), Some(context))
        .and_then(|value| as_number(&value))
        .and_then(non_negative_integer_usize)
}

fn non_negative_integer_usize(value: f64) -> Option<usize> {
    if value.is_finite() && value >= 0.0 && value.fract() == 0.0 {
        Some(value as usize)
    } else {
        None
    }
}
