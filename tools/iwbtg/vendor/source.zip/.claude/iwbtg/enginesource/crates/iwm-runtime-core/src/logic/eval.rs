use std::collections::HashMap;

use super::context::{RuntimeEvalContext, RuntimeExecutionScope};
use super::eval_functions::{
    evaluate_choose_call, evaluate_collision_line, evaluate_collision_rectangle,
    evaluate_distance_to_object, evaluate_instance_exists, evaluate_instance_find,
    evaluate_instance_number, evaluate_instance_place, evaluate_instance_position,
    evaluate_irandom_call, evaluate_irandom_range_call, evaluate_keyboard_query,
    evaluate_lengthdir, evaluate_ord_call, evaluate_place_query, evaluate_point_direction,
    evaluate_point_distance, evaluate_random_call, evaluate_random_range_call,
};
pub(super) use super::eval_values::is_truthy;
use super::eval_values::{eval_binary_expr, runtime_value_to_string_text};
pub(crate) use super::eval_variables::assignable_key;
use super::eval_variables::{evaluate_identifier, evaluate_index_access, evaluate_member_access};
use crate::helpers::{as_number, parse_runtime_value};
use crate::{LoweredLogicExpr, RuntimeInstance, RuntimeValue};

pub(super) fn evaluate_expr(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    match expr {
        LoweredLogicExpr::Identifier(name) => {
            evaluate_identifier(name, instance, globals, scope, eval_context)
        }
        LoweredLogicExpr::LiteralNumber(number) => Some(RuntimeValue::Number(*number)),
        LoweredLogicExpr::LiteralBool(flag) => Some(RuntimeValue::Bool(*flag)),
        LoweredLogicExpr::LiteralText(text) => Some(RuntimeValue::Text(text.clone())),
        LoweredLogicExpr::UnaryExpr { op, child } => {
            let value = evaluate_expr(child, instance, globals, scope, eval_context)?;
            match op.as_str() {
                "-" => Some(RuntimeValue::Number(-as_number(&value)?)),
                "+" => Some(RuntimeValue::Number(as_number(&value)?)),
                "!" => Some(RuntimeValue::Bool(!is_truthy(Some(value)))),
                _ => None,
            }
        }
        LoweredLogicExpr::Call { name, args } => match name.as_str() {
            "room_goto" => args
                .first()
                .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context)),
            "ord" => evaluate_ord_call(args),
            "abs" => args
                .first()
                .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
                .and_then(|value| as_number(&value))
                .map(|value| RuntimeValue::Number(value.abs())),
            "floor" => args
                .first()
                .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
                .and_then(|value| as_number(&value))
                .map(|value| RuntimeValue::Number(value.floor())),
            "round" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(gm_round(value))),
            "ceil" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.ceil())),
            "sqrt" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.sqrt())),
            "sqr" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value * value)),
            "sign" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(gm_sign(value))),
            "sin" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.sin())),
            "cos" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.cos())),
            "tan" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.tan())),
            "arctan" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.atan())),
            "degtorad" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.to_radians())),
            "radtodeg" => eval_number_arg(args.first(), instance, globals, scope, eval_context)
                .map(|value| RuntimeValue::Number(value.to_degrees())),
            "power" => {
                let base = eval_number_arg(args.first(), instance, globals, scope, eval_context)?;
                let exponent =
                    eval_number_arg(args.get(1), instance, globals, scope, eval_context)?;
                Some(RuntimeValue::Number(base.powf(exponent)))
            }
            "arctan2" => {
                let y = eval_number_arg(args.first(), instance, globals, scope, eval_context)?;
                let x = eval_number_arg(args.get(1), instance, globals, scope, eval_context)?;
                Some(RuntimeValue::Number(y.atan2(x)))
            }
            "min" | "max" => {
                let mut accumulator: Option<f64> = None;
                for arg in args {
                    let value = eval_number_arg(Some(arg), instance, globals, scope, eval_context)?;
                    accumulator = Some(match accumulator {
                        None => value,
                        Some(current) if name == "min" => current.min(value),
                        Some(current) => current.max(value),
                    });
                }
                Some(RuntimeValue::Number(accumulator.unwrap_or(0.0)))
            }
            "random" => evaluate_random_call(args, instance, globals, scope, eval_context),
            "irandom" => evaluate_irandom_call(args, instance, globals, scope, eval_context),
            "irandom_range" => {
                evaluate_irandom_range_call(args, instance, globals, scope, eval_context)
            }
            "random_range" => {
                evaluate_random_range_call(args, instance, globals, scope, eval_context)
            }
            "choose" => evaluate_choose_call(args, instance, globals, scope, eval_context),
            "point_direction" => {
                evaluate_point_direction(args, instance, globals, scope, eval_context)
            }
            "point_distance" => {
                evaluate_point_distance(args, instance, globals, scope, eval_context)
            }
            "lengthdir_x" => {
                evaluate_lengthdir(args, instance, globals, scope, eval_context, false)
            }
            "lengthdir_y" => evaluate_lengthdir(args, instance, globals, scope, eval_context, true),
            "string" => args
                .first()
                .and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
                .map(runtime_value_to_string_text)
                .map(RuntimeValue::Text),
            "instance_exists" => evaluate_instance_exists(args, eval_context),
            "instance_number" => evaluate_instance_number(args, eval_context),
            "instance_find" => evaluate_instance_find(args, instance, globals, scope, eval_context),
            "instance_place" => {
                evaluate_instance_place(args, instance, globals, scope, eval_context)
            }
            "instance_position" => {
                evaluate_instance_position(args, instance, globals, scope, eval_context)
            }
            "distance_to_object" => {
                evaluate_distance_to_object(args, instance, globals, scope, eval_context)
            }
            "collision_line" => {
                evaluate_collision_line(args, instance, globals, scope, eval_context)
            }
            "collision_rectangle" => {
                evaluate_collision_rectangle(args, instance, globals, scope, eval_context)
            }
            "keyboard_check"
            | "keyboard_check_direct"
            | "keyboard_check_pressed"
            | "keyboard_check_released" => {
                evaluate_keyboard_query(name, args, instance, globals, scope, eval_context)
            }
            "place_meeting" => {
                evaluate_place_query(args, instance, globals, scope, eval_context, true)
            }
            "place_free" => {
                evaluate_place_query(args, instance, globals, scope, eval_context, false)
            }
            _ => None,
        },
        LoweredLogicExpr::MemberAccess { target, member } => {
            evaluate_member_access(target, member, instance, globals, scope, eval_context)
        }
        LoweredLogicExpr::IndexAccess { target, index } => {
            evaluate_index_access(target, index, instance, globals, scope, eval_context)
        }
        LoweredLogicExpr::BinaryExpr { op, left, right } => {
            if op == "&&" {
                let left = evaluate_expr(left, instance, globals, scope, eval_context)?;
                if !is_truthy(Some(left)) {
                    return Some(RuntimeValue::Bool(false));
                }
                let right = evaluate_expr(right, instance, globals, scope, eval_context)?;
                return Some(RuntimeValue::Bool(is_truthy(Some(right))));
            }

            if op == "||" {
                let left = evaluate_expr(left, instance, globals, scope, eval_context)?;
                if is_truthy(Some(left)) {
                    return Some(RuntimeValue::Bool(true));
                }
                let right = evaluate_expr(right, instance, globals, scope, eval_context)?;
                return Some(RuntimeValue::Bool(is_truthy(Some(right))));
            }

            let left = evaluate_binary_operand(left, instance, globals, scope, eval_context)?;
            let right = evaluate_binary_operand(right, instance, globals, scope, eval_context)?;
            eval_binary_expr(op, &left, &right)
        }
        LoweredLogicExpr::Raw { source } => parse_runtime_value(source),
    }
}

fn evaluate_binary_operand(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<RuntimeValue> {
    evaluate_expr(expr, instance, globals, scope, eval_context)
        .or_else(|| uninitialized_instance_operand(expr, instance, scope))
}

fn eval_number_arg(
    arg: Option<&LoweredLogicExpr>,
    instance: Option<&RuntimeInstance>,
    globals: &HashMap<String, RuntimeValue>,
    scope: Option<&RuntimeExecutionScope>,
    eval_context: Option<&RuntimeEvalContext<'_>>,
) -> Option<f64> {
    arg.and_then(|arg| evaluate_expr(arg, instance, globals, scope, eval_context))
        .and_then(|value| as_number(&value))
}

/// GM8 `sign` uses the engine comparison epsilon (`1e-13`), so values in the
/// dead zone around zero return `0` rather than `±1`.
fn gm_sign(value: f64) -> f64 {
    const CMP_EPSILON: f64 = 1e-13;
    if value >= CMP_EPSILON {
        1.0
    } else if value <= -CMP_EPSILON {
        -1.0
    } else {
        0.0
    }
}

/// GM8 `round` uses banker's rounding (round half to even), matching OpenGMK's
/// `Real::round`.
fn gm_round(value: f64) -> f64 {
    let rounded = value.round();
    if (value - value.trunc()).abs() == 0.5 {
        // `f64::round` rounds half away from zero; GM rounds half to even.
        let floor = value.floor();
        if (floor as i64) % 2 == 0 {
            floor
        } else {
            floor + 1.0
        }
    } else {
        rounded
    }
}

fn uninitialized_instance_operand(
    expr: &LoweredLogicExpr,
    instance: Option<&RuntimeInstance>,
    scope: Option<&RuntimeExecutionScope>,
) -> Option<RuntimeValue> {
    let LoweredLogicExpr::Identifier(name) = expr else {
        return None;
    };
    if instance.is_some()
        && !name.eq_ignore_ascii_case("global")
        && !scope.map(|scope| scope.is_local_key(name)).unwrap_or(false)
    {
        Some(RuntimeValue::Number(0.0))
    } else {
        None
    }
}
