use iwm_runtime_host::RuntimeDialogAnswer;

use super::*;
use crate::tests::support::add_keyboard_press_block;

fn call(name: &str, args: Vec<LoweredLogicExpr>) -> LoweredLogicStatement {
    LoweredLogicStatement::FunctionCall {
        name: name.into(),
        args,
    }
}

fn text_arg(text: &str) -> LoweredLogicExpr {
    LoweredLogicExpr::LiteralText(text.into())
}

fn assign(var: &str, value: f64) -> LoweredLogicStatement {
    LoweredLogicStatement::Assignment {
        target: LoweredLogicExpr::Identifier(var.into()),
        value: LoweredLogicExpr::LiteralNumber(value),
    }
}

fn bool_call_answer(name: &str, text: &str) -> LoweredLogicExpr {
    LoweredLogicExpr::Call {
        name: name.into(),
        args: vec![text_arg(text)],
    }
}

fn press_key(host: &mut iwm_runtime_host::HeadlessHost, key: u16) {
    host.input.set_button_state(
        RuntimeButton::Keyboard(key),
        ButtonState {
            pressed: true,
            just_pressed: true,
            just_released: false,
        },
    );
}

fn release_key(host: &mut iwm_runtime_host::HeadlessHost, key: u16) {
    host.input.set_button_state(
        RuntimeButton::Keyboard(key),
        ButtonState {
            pressed: false,
            just_pressed: false,
            just_released: false,
        },
    );
}

#[test]
fn dialog_suspends_until_answer_then_consumes_it() {
    let mut package = sample_package();
    add_step_block(
        &mut package,
        vec![
            call("show_message", vec![text_arg("hello")]),
            assign("after_dialog", 1.0),
        ],
    );
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.set_auto_answer_dialogs(false);

    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_some());
    assert_eq!(player_var(&core, "after_dialog"), None);

    // Waiting ticks neither advance nor execute the tail of the block.
    core.tick(&mut host).unwrap();
    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_some());
    assert_eq!(player_var(&core, "after_dialog"), None);

    core.resolve_dialog(RuntimeDialogAnswer::Accepted).unwrap();
    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_none());
    assert_eq!(
        player_var(&core, "after_dialog"),
        Some(&RuntimeValue::Number(1.0))
    );
}

#[test]
fn dialog_answer_survives_sequential_dialogs_until_both_answered() {
    let mut package = sample_package();
    add_step_block(
        &mut package,
        vec![
            call("show_message", vec![text_arg("first")]),
            call("show_message", vec![text_arg("second")]),
            assign("after_dialog", 1.0),
        ],
    );
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.set_auto_answer_dialogs(false);

    core.tick(&mut host).unwrap();
    assert_eq!(core.pending_dialog().unwrap().text, "first");

    // The second dialog mismatches while replaying the same block; the first
    // dialog must still consume the stored answer on the replay tick.
    core.resolve_dialog(RuntimeDialogAnswer::Accepted).unwrap();
    core.tick(&mut host).unwrap();
    assert_eq!(core.pending_dialog().unwrap().text, "second");
    assert_eq!(player_var(&core, "after_dialog"), None);

    core.resolve_dialog(RuntimeDialogAnswer::Accepted).unwrap();
    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_none());
    assert_eq!(
        player_var(&core, "after_dialog"),
        Some(&RuntimeValue::Number(1.0))
    );
}

#[test]
fn dialog_response_can_be_replaced_while_unconsumed() {
    let mut package = sample_package();
    add_step_block(
        &mut package,
        vec![LoweredLogicStatement::Conditional {
            condition: bool_call_answer("show_question", "overwrite?"),
            then_branch: vec![assign("on_yes", 1.0)],
            else_branch: vec![assign("on_no", 1.0)],
        }],
    );
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.set_auto_answer_dialogs(false);

    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_some());

    // A double-submitted answer must not wedge the modal with an error.
    core.resolve_dialog(RuntimeDialogAnswer::Yes).unwrap();
    core.resolve_dialog(RuntimeDialogAnswer::No).unwrap();

    core.tick(&mut host).unwrap();
    assert_eq!(player_var(&core, "on_no"), Some(&RuntimeValue::Number(1.0)));
}

#[test]
fn unconsumed_dialog_response_drops_after_grace_period() {
    let mut package = sample_package();
    add_keyboard_press_block(
        &mut package,
        0x42,
        vec![
            call("show_message", vec![text_arg("gone soon")]),
            assign("after_dialog", 1.0),
        ],
    );
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.set_auto_answer_dialogs(false);

    press_key(&mut host, 0x42);
    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_some());

    // The key is released, so the suspended call site will never replay; the
    // queued answer ages out and the dropped state is diagnosed.
    release_key(&mut host, 0x42);
    core.resolve_dialog(RuntimeDialogAnswer::Accepted).unwrap();

    for _ in 0..59 {
        core.tick(&mut host).unwrap();
    }
    assert!(core.pending_dialog().is_some());

    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_none());
    assert!(core
        .diagnostics()
        .iter()
        .any(|entry| entry.code == "runtime-dialog-response-dropped"));
}

#[test]
fn manual_room_reload_clears_a_pending_dialog() {
    let mut package = sample_package();
    add_step_block(
        &mut package,
        vec![call("show_message", vec![text_arg("room scoped")])],
    );
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.set_auto_answer_dialogs(false);

    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_some());

    core.reload_room(core.current_room().unwrap().room_id)
        .unwrap();
    assert!(core.pending_dialog().is_none());
    assert!(core.dialog_response.is_none());

    // The runtime must run again without freezing on the dropped dialog.
    core.tick(&mut host).unwrap();
}

#[test]
fn conditional_chain_dialog_in_else_if_condition_suspends_branch_selection() {
    let mut package = sample_package();
    add_step_block(
        &mut package,
        vec![
            assign("first", 0.0),
            LoweredLogicStatement::ConditionalChain {
                branches: vec![
                    LoweredLogicConditionalBranch {
                        condition: LoweredLogicExpr::LiteralBool(false),
                        body: vec![assign("picked_first", 1.0)],
                    },
                    LoweredLogicConditionalBranch {
                        condition: bool_call_answer("show_question", "else if?"),
                        body: vec![assign("picked_second", 1.0)],
                    },
                ],
                else_branch: vec![assign("picked_else", 1.0)],
            },
        ],
    );
    let mut core = RuntimeCore::load(package).unwrap();
    let mut host = host();
    host.set_auto_answer_dialogs(false);

    core.tick(&mut host).unwrap();
    assert!(core.pending_dialog().is_some());
    // No branch body may run while the dialog is unanswered.
    assert_eq!(player_var(&core, "picked_first"), None);
    assert_eq!(player_var(&core, "picked_second"), None);
    assert_eq!(player_var(&core, "picked_else"), None);

    core.resolve_dialog(RuntimeDialogAnswer::Yes).unwrap();
    core.tick(&mut host).unwrap();
    assert_eq!(
        player_var(&core, "picked_second"),
        Some(&RuntimeValue::Number(1.0))
    );
    assert_eq!(player_var(&core, "picked_else"), None);
}
