use serde::{Deserialize, Serialize};

mod raw_logic;
mod validation;

pub use raw_logic::*;
pub use validation::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum CompatibilityLevel {
    Supported,
    Partial,
    Blocked,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum RuntimeDisplaySource {
    ExeResolution,
    DefaultRoom,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuntimeManifest {
    pub format_version: u32,
    pub package_kind: String,
    pub source_name: String,
    pub source_hash: String,
    pub engine_family: String,
    pub compatibility: CompatibilityLevel,
    pub default_room_id: Option<usize>,
    #[serde(default)]
    pub room_order: Vec<usize>,
    pub room_count: usize,
    pub object_count: usize,
    pub script_block_count: usize,
    pub sprite_count: usize,
    pub background_count: usize,
    pub sound_count: usize,
    pub resource_index_path: String,
    pub warnings: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub display_source: Option<RuntimeDisplaySource>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub display_width: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub display_height: Option<u32>,
    #[serde(default)]
    pub zero_uninitialized_vars: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceIndex {
    pub sprites: Vec<SpriteResource>,
    pub backgrounds: Vec<BackgroundResource>,
    pub sounds: Vec<SoundResource>,
    #[serde(default)]
    pub fonts: Vec<FontResource>,
    #[serde(default)]
    pub paths: Vec<PathResource>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PathResource {
    pub id: usize,
    pub name: String,
    pub smooth: bool,
    pub precision: u32,
    pub closed: bool,
    pub points: Vec<PathPointResource>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct PathPointResource {
    pub x: f64,
    pub y: f64,
    pub speed: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpriteResource {
    pub id: usize,
    pub name: String,
    pub origin_x: i32,
    pub origin_y: i32,
    pub frame_paths: Vec<String>,
    pub width: u32,
    pub height: u32,
    pub bbox_left: u32,
    pub bbox_right: u32,
    pub bbox_top: u32,
    pub bbox_bottom: u32,
    #[serde(default)]
    pub collision_masks: Vec<SpriteCollisionMask>,
    #[serde(default)]
    pub per_frame_collision_masks: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpriteCollisionMask {
    pub width: u32,
    pub height: u32,
    pub bbox_left: u32,
    pub bbox_right: u32,
    pub bbox_top: u32,
    pub bbox_bottom: u32,
    pub data: Vec<bool>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackgroundResource {
    pub id: usize,
    pub name: String,
    pub width: u32,
    pub height: u32,
    pub image_path: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SoundResource {
    pub id: usize,
    pub name: String,
    pub file_path: String,
    pub extension: String,
    pub preload: bool,
    #[serde(default = "default_sound_kind")]
    pub kind: String,
}

fn default_sound_kind() -> String {
    "normal".into()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FontResource {
    pub id: usize,
    pub name: String,
    pub system_name: String,
    pub size: u32,
    pub bold: bool,
    pub italic: bool,
    #[serde(default)]
    pub range_start: u32,
    #[serde(default)]
    pub range_end: u32,
    #[serde(default)]
    pub map_width: u32,
    #[serde(default)]
    pub map_height: u32,
    #[serde(default)]
    pub image_path: String,
    #[serde(default)]
    pub glyphs: Vec<FontGlyphResource>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FontGlyphResource {
    pub code: u32,
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
    pub offset: i32,
    pub advance: i32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomDefinition {
    pub id: usize,
    pub name: String,
    pub width: u32,
    pub height: u32,
    pub speed: u32,
    pub persistent: bool,
    #[serde(default)]
    pub background_colour: u32,
    #[serde(default = "default_true")]
    pub clear_screen: bool,
    pub backgrounds: Vec<RoomBackgroundLayer>,
    pub views_enabled: bool,
    pub views: Vec<RoomView>,
    pub tiles: Vec<RoomTilePlacement>,
    pub instances: Vec<RoomInstancePlacement>,
    pub creation_block_id: Option<String>,
    pub playable: bool,
    pub transition_targets: Vec<usize>,
}

fn default_true() -> bool {
    true
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomBackgroundLayer {
    pub visible_on_start: bool,
    pub is_foreground: bool,
    pub source_bg: i32,
    pub xoffset: i32,
    pub yoffset: i32,
    pub tile_horz: bool,
    pub tile_vert: bool,
    pub hspeed: i32,
    pub vspeed: i32,
    pub stretch: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomView {
    pub visible: bool,
    pub source_x: i32,
    pub source_y: i32,
    pub source_w: u32,
    pub source_h: u32,
    pub port_x: i32,
    pub port_y: i32,
    pub port_w: u32,
    pub port_h: u32,
    pub target: i32,
    #[serde(default)]
    pub hborder: i32,
    #[serde(default)]
    pub vborder: i32,
    #[serde(default)]
    pub hspeed: i32,
    #[serde(default)]
    pub vspeed: i32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomTilePlacement {
    pub tile_id: i32,
    pub source_bg: i32,
    pub x: i32,
    pub y: i32,
    pub tile_x: u32,
    pub tile_y: u32,
    pub width: u32,
    pub height: u32,
    pub depth: i32,
    pub xscale: f64,
    pub yscale: f64,
    pub blend: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomInstancePlacement {
    pub instance_id: i32,
    pub object_id: i32,
    pub x: i32,
    pub y: i32,
    pub xscale: f64,
    pub yscale: f64,
    pub angle: f64,
    pub blend: u32,
    pub creation_block_id: Option<String>,
    pub is_solid: bool,
    pub is_hazard: bool,
    pub is_checkpoint: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectDefinition {
    pub id: usize,
    pub name: String,
    pub sprite_index: i32,
    pub parent_index: i32,
    pub depth: i32,
    pub persistent: bool,
    pub visible: bool,
    pub solid: bool,
    pub mask_index: i32,
    pub is_hazard: Option<bool>,
    pub is_checkpoint: Option<bool>,
    pub is_player: bool,
    pub events: Vec<ObjectEventEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectEventEntry {
    pub event_type: usize,
    pub sub_event: u32,
    pub event_tag: String,
    pub block_id: String,
    pub action_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScriptIrFile {
    pub format: String,
    pub blocks: Vec<LogicBlock>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogicBlock {
    pub id: String,
    pub name: String,
    pub kind: String,
    pub support: String,
    pub executable_action_count: usize,
    pub ops: Vec<LogicOp>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "op", rename_all = "kebab-case")]
pub enum LogicOp {
    ActionCall {
        action_id: u32,
        lib_id: u32,
        applies_to: i32,
        is_condition: bool,
        invert_condition: bool,
        is_relative: bool,
        fn_name: String,
        fn_code: String,
        args: Vec<String>,
    },
    SourceSnippet {
        code: String,
    },
    Unsupported {
        reason: String,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisReport {
    pub dlls: Vec<String>,
    pub included_files: Vec<String>,
    pub warnings: Vec<String>,
    pub unsupported_features: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoweredLogicFile {
    pub format: String,
    pub entries: Vec<LoweredLogicEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoweredLogicEntry {
    pub block_id: String,
    pub statements: Vec<LoweredLogicStatement>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", content = "value", rename_all = "kebab-case")]
pub enum LoweredLogicExpr {
    Identifier(String),
    LiteralNumber(f64),
    LiteralBool(bool),
    LiteralText(String),
    UnaryExpr {
        op: String,
        child: Box<LoweredLogicExpr>,
    },
    Call {
        name: String,
        args: Vec<LoweredLogicExpr>,
    },
    MemberAccess {
        target: Box<LoweredLogicExpr>,
        member: String,
    },
    IndexAccess {
        target: Box<LoweredLogicExpr>,
        index: Box<LoweredLogicExpr>,
    },
    BinaryExpr {
        op: String,
        left: Box<LoweredLogicExpr>,
        right: Box<LoweredLogicExpr>,
    },
    Raw {
        source: String,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoweredLogicConditionalBranch {
    pub condition: LoweredLogicExpr,
    pub body: Vec<LoweredLogicStatement>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoweredLogicSwitchCase {
    pub value: Option<LoweredLogicExpr>,
    pub body: Vec<LoweredLogicStatement>,
    pub break_after: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "kebab-case")]
pub enum LoweredLogicStatement {
    Assignment {
        target: LoweredLogicExpr,
        value: LoweredLogicExpr,
    },
    VariableDeclaration {
        names: Vec<String>,
    },
    Return {
        value: Option<LoweredLogicExpr>,
    },
    FunctionCall {
        name: String,
        args: Vec<LoweredLogicExpr>,
    },
    Conditional {
        condition: LoweredLogicExpr,
        then_branch: Vec<LoweredLogicStatement>,
        else_branch: Vec<LoweredLogicStatement>,
    },
    ConditionalChain {
        branches: Vec<LoweredLogicConditionalBranch>,
        else_branch: Vec<LoweredLogicStatement>,
    },
    Switch {
        expression: LoweredLogicExpr,
        cases: Vec<LoweredLogicSwitchCase>,
    },
    With {
        target: LoweredLogicExpr,
        body: Vec<LoweredLogicStatement>,
    },
    Repeat {
        count: LoweredLogicExpr,
        body: Vec<LoweredLogicStatement>,
    },
    While {
        condition: LoweredLogicExpr,
        body: Vec<LoweredLogicStatement>,
    },
    For {
        init: LoweredLogicExpr,
        condition: LoweredLogicExpr,
        step: LoweredLogicExpr,
        body: Vec<LoweredLogicStatement>,
    },
    Raw {
        source: String,
    },
}
