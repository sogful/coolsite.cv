use crate::helpers::{adjusted_spawn_for_player, is_player_instance};
use crate::types::RuntimeJumpState;
use crate::{RuntimeCore, RuntimeCoreError, RuntimeInstance, RuntimeRoomState, RuntimeStatus};
use iwm_runtime_host::RuntimeHost;

impl RuntimeCore {
    pub(crate) fn apply_pending_room_change<H: RuntimeHost>(
        &mut self,
        host: &mut H,
    ) -> Result<(), RuntimeCoreError> {
        if self.pending_game_restart {
            let from_room_id = self
                .current_room
                .as_ref()
                .map(|room| room.room_id)
                .ok_or(RuntimeCoreError::NoRooms)?;
            let room_id = self
                .cached_room_order
                .first()
                .copied()
                .or_else(|| self.package.rooms.first().map(|room| room.id))
                .ok_or(RuntimeCoreError::NoRooms)?;
            self.pending_game_restart = false;
            self.pending_room_reset = false;
            self.pending_room_transition = None;
            // A dialog prompt from the room being left cannot resume across a
            // game restart: its call site belongs to the old room.
            self.clear_dialog_state();
            self.stop_one_shot_sounds_for_scene_change(host, "game_restart");
            self.globals.clear();
            self.host_bootstrap_scripts_applied = false;
            self.current_room = Some(self.build_room(room_id)?);
            self.room_needs_first_render_settle = true;
            self.death_waiting_for_restart = false;
            self.status = RuntimeStatus::Ready;
            self.record_diagnostic(
                host,
                iwm_runtime_host::RuntimeDiagnosticLevel::Info,
                "runtime-room-changed",
                format!(
                    "from_room={} to_room={} reason=game_restart tick={}",
                    from_room_id, room_id, self.tick
                ),
            );
        }

        if self.pending_room_reset {
            let from_room_id = self
                .current_room
                .as_ref()
                .map(|room| room.room_id)
                .ok_or(RuntimeCoreError::NoRooms)?;
            let room_id = self
                .current_room
                .as_ref()
                .map(|room| room.room_id)
                .ok_or(RuntimeCoreError::NoRooms)?;
            self.pending_room_reset = false;
            self.clear_dialog_state();
            self.stop_one_shot_sounds_for_scene_change(host, "restart");
            self.current_room = Some(self.build_room(room_id)?);
            self.room_needs_first_render_settle = true;
            self.death_waiting_for_restart = false;
            self.reset_player_to_spawn();
            self.status = RuntimeStatus::Ready;
            self.record_diagnostic(
                host,
                iwm_runtime_host::RuntimeDiagnosticLevel::Info,
                "runtime-room-changed",
                format!(
                    "from_room={} to_room={} reason=restart tick={}",
                    from_room_id, room_id, self.tick
                ),
            );
        }

        if let Some(room_id) = self.pending_room_transition.take() {
            let from_room_id = self.current_room.as_ref().map(|room| room.room_id);
            // The suspended dialog site belongs to the room being left.
            self.clear_dialog_state();
            let persistent_instances = self.persistent_instances_for_room_transition();
            let carried_player = persistent_instances
                .iter()
                .find(|instance| is_player_instance(instance))
                .map(|instance| {
                    format!(
                        "runtime_id={} pos=({},{}) alive={}",
                        instance.runtime_id, instance.x, instance.y, instance.alive
                    )
                })
                .unwrap_or_else(|| "none".into());
            let (mut room, source_room) = self.build_room_layout(room_id)?;
            let target_spawn = format!("{:?}", room.spawn_point);
            add_persistent_instances(&mut room, persistent_instances);
            self.current_room = Some(room);
            self.apply_current_room_startup_events(host, &source_room)?;
            let final_player = self
                .current_room
                .as_ref()
                .and_then(|room| {
                    room.instances
                        .iter()
                        .find(|instance| is_player_instance(instance))
                })
                .map(|instance| {
                    format!(
                        "runtime_id={} pos=({},{}) alive={}",
                        instance.runtime_id, instance.x, instance.y, instance.alive
                    )
                })
                .unwrap_or_else(|| "none".into());
            self.room_needs_first_render_settle = true;
            self.death_waiting_for_restart = false;
            self.status = RuntimeStatus::Ready;
            self.record_diagnostic(
                host,
                iwm_runtime_host::RuntimeDiagnosticLevel::Info,
                "runtime-room-changed",
                format!(
                    "from_room={} to_room={} reason=transition tick={} carried_player={} target_spawn={} final_player={}",
                    from_room_id.unwrap_or(room_id),
                    room_id,
                    self.tick,
                    carried_player,
                    target_spawn,
                    final_player,
                ),
            );
        }

        Ok(())
    }

    // GM8's game_restart/room reset keeps every sound playing (OpenGMK
    // Game::restart never touches audio). Fangame BGM continuity depends on
    // that: playMusic objects guard with `if (!sound_isplaying(stageBGM))`
    // before sound_loop, so a natively-stopped BGM would be restarted from
    // zero by the game's own GML. Looping sounds therefore MUST survive the
    // reset. We deviate from GM8 only for one-shots (the death jingle) so
    // pressing R cuts them instead of letting them ring over the rebuilt room.
    fn stop_one_shot_sounds_for_scene_change<H: RuntimeHost>(
        &mut self,
        host: &mut H,
        reason: &str,
    ) {
        for sound_id in std::mem::take(&mut self.active_one_shot_sounds) {
            if let Err(error) = host.stop_sound(sound_id) {
                self.record_diagnostic(
                    host,
                    iwm_runtime_host::RuntimeDiagnosticLevel::Warning,
                    "runtime-audio-host-error",
                    format!(
                        "function=sound_stop sound_id={sound_id} reason={reason} error={error}"
                    ),
                );
            }
        }
    }

    pub(crate) fn persistent_instances_for_room_transition(&self) -> Vec<RuntimeInstance> {
        self.current_room
            .as_ref()
            .map(|room| {
                room.instances
                    .iter()
                    .filter(|instance| instance.alive && instance.persistent)
                    .cloned()
                    .collect()
            })
            .unwrap_or_default()
    }

    pub(crate) fn reset_player_to_spawn(&mut self) {
        let Some(room) = self.current_room.as_mut() else {
            return;
        };

        let Some((spawn_x, spawn_y)) = room.spawn_point else {
            return;
        };

        if let Some(player_index) = room.instances.iter().position(is_player_instance) {
            let (x, y) =
                adjusted_spawn_for_player(&room.instances[player_index], spawn_x, spawn_y, room);
            let player = &mut room.instances[player_index];
            player.x = x as f64;
            player.y = y as f64;
            player.previous_x = x as f64;
            player.previous_y = y as f64;
            player.set_hvspeed(0.0, 0.0);
            player.jump = RuntimeJumpState::default();
        }
    }
}

pub(crate) fn add_persistent_instances(
    room: &mut RuntimeRoomState,
    instances: Vec<RuntimeInstance>,
) {
    for mut instance in instances {
        if let Some(candidate) = room
            .instances
            .iter()
            .find(|candidate| persistent_instance_replaces_room_instance(&instance, candidate))
        {
            merge_missing_player_vars(&mut instance, candidate);
        }
        room.instances
            .retain(|candidate| !persistent_instance_replaces_room_instance(&instance, candidate));
        renumber_runtime_ids(room);
        instance.runtime_id = room.instances.len();
        room.instances.push(instance);
    }
}

/// Whether a carried persistent instance is the *same* instance as one the room
/// placed, and should therefore take its slot.
///
/// Identity requires the same object. `instance_id` alone is not enough: ids for
/// instances created by `instance_create()` are allocated from the room's current
/// maximum, and a nested create (the `bow` a `player`'s Create event spawns) is
/// allocated before its parent has been pushed into the room, so parent and child
/// can share an id. Without the object check, carrying both would make the child
/// evict the parent and a save-restored player would lose its position.
fn persistent_instance_replaces_room_instance(
    incoming: &RuntimeInstance,
    candidate: &RuntimeInstance,
) -> bool {
    if incoming.object_id != candidate.object_id {
        return false;
    }

    incoming.instance_id == candidate.instance_id
        || (is_player_instance(incoming) && is_player_instance(candidate))
}

fn merge_missing_player_vars(incoming: &mut RuntimeInstance, candidate: &RuntimeInstance) {
    if !is_player_instance(incoming)
        || !is_player_instance(candidate)
        || incoming.object_id != candidate.object_id
    {
        return;
    }

    for (key, value) in &candidate.vars {
        incoming
            .vars
            .entry(key.clone())
            .or_insert_with(|| value.clone());
    }
}

fn renumber_runtime_ids(room: &mut RuntimeRoomState) {
    for (runtime_id, instance) in room.instances.iter_mut().enumerate() {
        instance.runtime_id = runtime_id;
    }
}
