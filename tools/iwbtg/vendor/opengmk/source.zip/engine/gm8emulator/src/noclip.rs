use crate::game::{Game, GetAsset};
use std::cell::RefCell;
use std::collections::HashSet;

////////////////////////////////////////////////////////////////////////

#[derive(Default)]
struct State {
    enabled: bool,
    held: bool,
    handle: Option<usize>,
    hazards: HashSet<i32>,
    built: bool,
    x: f64,
    y: f64,
}

thread_local! {static STATE: RefCell<State> = RefCell::new(State::default());}

pub fn enabled() -> bool {STATE.with(|state| state.borrow().enabled)}
pub fn reset() {STATE.with(|state| *state.borrow_mut() = State::default());}
pub fn room() {STATE.with(|state| state.borrow_mut().handle = None);}
pub fn clear() {STATE.with(|state| state.borrow_mut().held = false);}
pub fn details() -> String {STATE.with(|state| {let state = state.borrow(); format!("{} {:?} {} {}",state.enabled,state.handle,state.x,state.y)})}

pub fn key(code: u8, down: bool) {
    if code != 113 {return;}
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if down && !state.held {state.enabled = !state.enabled; state.handle = None;}
        state.held = down;
    });
}

fn hazard(name: &str) -> bool {
    if ["warp", "portal", "save", "select", "trigger"].iter().any(|part| name.contains(part)) {return false;}
    ["spike", "needle", "hazard", "lethal", "deadly", "danger", "killer", "killblock", "death", "enemy", "bullet", "projectile", "cherry", "apple", "laser", "beam", "boss"].iter().any(|part| name.contains(part))
}

pub fn ignored(game: &Game, first: usize, second: usize) -> bool {
    STATE.with(|state| {
        let state = state.borrow();
        if !state.enabled {return false;}
        let other = if state.handle == Some(first) {second} else if state.handle == Some(second) {first} else {return false;};
        state.hazards.contains(&game.room.instance_list.get(other).object_index.get())
    })
}

pub fn begin(game: &mut Game) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if !state.enabled {return;}
        if !state.built {
            state.built = true;
            for (index, object) in game.assets.objects.iter().enumerate() {
                if object.is_none() {continue;}
                let mut current = index as i32;
                for _ in 0..game.assets.objects.len() {
                    let Some(object) = game.assets.objects.get_asset(current) else {break;};
                    let name: String = object.name.decode_utf8().chars().filter(|c| c.is_ascii_alphanumeric()).flat_map(char::to_lowercase).collect();
                    if hazard(&name) {state.hazards.insert(index as i32); break;}
                    current = object.parent_index;
                    if current < 0 {break;}
                }
            }
        }
        if let Some(handle) = state.handle {
            let mut iter = game.room.instance_list.iter_by_drawing();
            if !std::iter::from_fn(|| iter.next(&game.room.instance_list)).any(|value| value == handle) {state.handle = None;}
        }
        if state.handle.is_none() {
            let mut best = 0;
            let mut iter = game.room.instance_list.iter_by_drawing();
            while let Some(handle) = iter.next(&game.room.instance_list) {
                let instance = game.room.instance_list.get(handle);
                if !instance.visible.get() || instance.sprite_index.get() < 0 {continue;}
                if let Some(object) = game.assets.objects.get_asset(instance.object_index.get()) {
                    let name: String = object.name.decode_utf8().chars().filter(|c| c.is_ascii_alphanumeric()).flat_map(char::to_lowercase).collect();
                    if ["bullet", "particle", "dead", "death", "effect", "camera", "controller", "parent"].iter().any(|part| name.contains(part)) {continue;}
                    let score = if ["player", "objplayer", "oplayer", "kid", "objkid", "okid"].contains(&name.as_str()) {100} else if name.contains("player") || name.ends_with("kid") {80} else if object.events[5].keys().chain(object.events[9].keys()).any(|key| [16,37,38,39,40].contains(key)) {50} else {0};
                    if score > best {best = score; state.handle = Some(handle);}
                }
            }
        }
        if let Some(handle) = state.handle {
            let instance = game.room.instance_list.get(handle);
            state.x = instance.x.get().into();
            state.y = instance.y.get().into();
        }
    });
}
