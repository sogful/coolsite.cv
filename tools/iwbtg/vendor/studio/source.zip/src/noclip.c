#include "runner.h"
#include "instance.h"
#include "stb_ds.h"
#include <ctype.h>
#include <string.h>

/*//////////////////////////////////////////////////////////////////////*/

static bool active = false;
static bool held = false;
static double rate = 0;
static Instance* player = nullptr;
static bool* hazards = nullptr;
static uint32_t count = 0;

int cheating(void) {return active;}
double framerate(void) {return rate;}
void nocliproom(void) {player = nullptr;}
void noclipreset(void) {
    player = nullptr;
    active = false;
    held = false;
    rate = 0;
    free(hazards);
    hazards = nullptr;
    count = 0;
}
void noclipkey(int code, bool down) {
    if (code != 113) {return;}
    if (down && !held) {active = !active; player = nullptr;}
    held = down;
}

static bool hazard(const char* name) {
    const char* excluded[] = {"warp", "portal", "save", "select", "trigger"};
    for (size_t index = 0; index < sizeof(excluded) / sizeof(*excluded); index++) {if (strstr(name, excluded[index])) {return false;}}
    const char* names[] = {"spike", "needle", "hazard", "lethal", "deadly", "danger", "killer", "killblock", "death", "enemy", "bullet", "projectile", "cherry", "apple", "laser", "beam", "boss"};
    for (size_t index = 0; index < sizeof(names) / sizeof(*names); index++) {if (strstr(name, names[index])) {return true;}}
    return false;
}

bool noclipignored(MAYBE_UNUSED Runner* runner, const Instance* first, const Instance* second) {
    if (!active || !player || !first || !second) {return false;}
    const Instance* other = first == player ? second : second == player ? first : nullptr;
    return other && other->objectIndex >= 0 && (uint32_t)other->objectIndex < count && hazards[other->objectIndex];
}

void noclipbegin(Runner* runner) {
    rate = runner->fps;
    if (!active) {return;}
    if (!hazards) {
        count = runner->dataWin->objt.count;
        hazards = safeCalloc(count, sizeof(bool));
        for (uint32_t index = 0; index < count; index++) {
            int32_t current = index;
            for (uint32_t depth = 0; depth < count && current >= 0 && (uint32_t)current < count; depth++) {
                GameObject* object = &runner->dataWin->objt.objects[current];
                char name[256];
                size_t length = 0;
                for (; object->name[length] && length < sizeof(name) - 1; length++) {name[length] = tolower((unsigned char)object->name[length]);}
                name[length] = 0;
                if (hazard(name)) {hazards[index] = true; break;}
                current = object->parentId;
            }
        }
    }
    if (player) {
        bool present = false;
        for (size_t index = 0; index < arrlenu(runner->instances); index++) {if (runner->instances[index] == player && player->active && !player->destroyed) {present = true; break;}}
        if (!present) {player = nullptr;}
    }
    if (!player) {
        int best = 0;
        for (size_t index = 0; index < arrlenu(runner->instances); index++) {
            Instance* instance = runner->instances[index];
            if (!instance->active || instance->destroyed || !instance->visible || instance->spriteIndex < 0 || instance->objectIndex < 0) {continue;}
            const char* original = runner->dataWin->objt.objects[instance->objectIndex].name;
            char name[128];
            size_t length = 0;
            for (size_t offset = 0; original[offset] && length < 127; offset++) {if (isalnum((unsigned char)original[offset])) {name[length++] = (char)tolower((unsigned char)original[offset]);}}
            name[length] = 0;
            if (strstr(name,"bullet") || strstr(name,"particle") || strstr(name,"dead") || strstr(name,"death") || strstr(name,"effect") || strstr(name,"camera") || strstr(name,"controller") || strstr(name,"parent")) {continue;}
            int score = !strcmp(name,"player") || !strcmp(name,"objplayer") || !strcmp(name,"oplayer") || !strcmp(name,"kid") || !strcmp(name,"objkid") || !strcmp(name,"okid") ? 100 : strstr(name,"player") || strstr(name,"kid") ? 80 : 0;
            if (score > best) {best = score; player = instance;}
        }
    }
}
